# 2026-11-21T16:51:07.541155771
import vitis

client = vitis.create_client()
client.set_workspace(path="Assignment_2")

