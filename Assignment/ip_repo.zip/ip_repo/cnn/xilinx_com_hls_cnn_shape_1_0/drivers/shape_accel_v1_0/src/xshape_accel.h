// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
// Tool Version Limit: 2026.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XSHAPE_ACCEL_H
#define XSHAPE_ACCEL_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xshape_accel_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Ctrl_BaseAddress;
} XShape_accel_Config;
#endif

typedef struct {
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XShape_accel;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XShape_accel_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XShape_accel_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XShape_accel_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XShape_accel_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XShape_accel_Initialize(XShape_accel *InstancePtr, UINTPTR BaseAddress);
XShape_accel_Config* XShape_accel_LookupConfig(UINTPTR BaseAddress);
#else
int XShape_accel_Initialize(XShape_accel *InstancePtr, u16 DeviceId);
XShape_accel_Config* XShape_accel_LookupConfig(u16 DeviceId);
#endif
int XShape_accel_CfgInitialize(XShape_accel *InstancePtr, XShape_accel_Config *ConfigPtr);
#else
int XShape_accel_Initialize(XShape_accel *InstancePtr, const char* InstanceName);
int XShape_accel_Release(XShape_accel *InstancePtr);
#endif

void XShape_accel_Start(XShape_accel *InstancePtr);
u32 XShape_accel_IsDone(XShape_accel *InstancePtr);
u32 XShape_accel_IsIdle(XShape_accel *InstancePtr);
u32 XShape_accel_IsReady(XShape_accel *InstancePtr);
void XShape_accel_EnableAutoRestart(XShape_accel *InstancePtr);
void XShape_accel_DisableAutoRestart(XShape_accel *InstancePtr);

u32 XShape_accel_Get_pred_class(XShape_accel *InstancePtr);
u32 XShape_accel_Get_pred_class_vld(XShape_accel *InstancePtr);
u32 XShape_accel_Get_scores_BaseAddress(XShape_accel *InstancePtr);
u32 XShape_accel_Get_scores_HighAddress(XShape_accel *InstancePtr);
u32 XShape_accel_Get_scores_TotalBytes(XShape_accel *InstancePtr);
u32 XShape_accel_Get_scores_BitWidth(XShape_accel *InstancePtr);
u32 XShape_accel_Get_scores_Depth(XShape_accel *InstancePtr);
u32 XShape_accel_Write_scores_Words(XShape_accel *InstancePtr, int offset, word_type *data, int length);
u32 XShape_accel_Read_scores_Words(XShape_accel *InstancePtr, int offset, word_type *data, int length);
u32 XShape_accel_Write_scores_Bytes(XShape_accel *InstancePtr, int offset, char *data, int length);
u32 XShape_accel_Read_scores_Bytes(XShape_accel *InstancePtr, int offset, char *data, int length);
u32 XShape_accel_Get_img_BaseAddress(XShape_accel *InstancePtr);
u32 XShape_accel_Get_img_HighAddress(XShape_accel *InstancePtr);
u32 XShape_accel_Get_img_TotalBytes(XShape_accel *InstancePtr);
u32 XShape_accel_Get_img_BitWidth(XShape_accel *InstancePtr);
u32 XShape_accel_Get_img_Depth(XShape_accel *InstancePtr);
u32 XShape_accel_Write_img_Words(XShape_accel *InstancePtr, int offset, word_type *data, int length);
u32 XShape_accel_Read_img_Words(XShape_accel *InstancePtr, int offset, word_type *data, int length);
u32 XShape_accel_Write_img_Bytes(XShape_accel *InstancePtr, int offset, char *data, int length);
u32 XShape_accel_Read_img_Bytes(XShape_accel *InstancePtr, int offset, char *data, int length);

void XShape_accel_InterruptGlobalEnable(XShape_accel *InstancePtr);
void XShape_accel_InterruptGlobalDisable(XShape_accel *InstancePtr);
void XShape_accel_InterruptEnable(XShape_accel *InstancePtr, u32 Mask);
void XShape_accel_InterruptDisable(XShape_accel *InstancePtr, u32 Mask);
void XShape_accel_InterruptClear(XShape_accel *InstancePtr, u32 Mask);
u32 XShape_accel_InterruptGetEnabled(XShape_accel *InstancePtr);
u32 XShape_accel_InterruptGetStatus(XShape_accel *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
