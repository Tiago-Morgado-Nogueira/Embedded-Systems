// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
// Tool Version Limit: 2026.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xshape_accel.h"

extern XShape_accel_Config XShape_accel_ConfigTable[];

#ifdef SDT
XShape_accel_Config *XShape_accel_LookupConfig(UINTPTR BaseAddress) {
	XShape_accel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XShape_accel_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XShape_accel_ConfigTable[Index].Ctrl_BaseAddress == BaseAddress) {
			ConfigPtr = &XShape_accel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XShape_accel_Initialize(XShape_accel *InstancePtr, UINTPTR BaseAddress) {
	XShape_accel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XShape_accel_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XShape_accel_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XShape_accel_Config *XShape_accel_LookupConfig(u16 DeviceId) {
	XShape_accel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSHAPE_ACCEL_NUM_INSTANCES; Index++) {
		if (XShape_accel_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XShape_accel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XShape_accel_Initialize(XShape_accel *InstancePtr, u16 DeviceId) {
	XShape_accel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XShape_accel_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XShape_accel_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

