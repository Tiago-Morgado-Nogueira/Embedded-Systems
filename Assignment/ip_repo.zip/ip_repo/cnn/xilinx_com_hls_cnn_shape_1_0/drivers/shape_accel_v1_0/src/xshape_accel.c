// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
// Tool Version Limit: 2026.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xshape_accel.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XShape_accel_CfgInitialize(XShape_accel *InstancePtr, XShape_accel_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XShape_accel_Start(XShape_accel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XShape_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_AP_CTRL) & 0x80;
    XShape_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XShape_accel_IsDone(XShape_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XShape_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XShape_accel_IsIdle(XShape_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XShape_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XShape_accel_IsReady(XShape_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XShape_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XShape_accel_EnableAutoRestart(XShape_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XShape_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_AP_CTRL, 0x80);
}

void XShape_accel_DisableAutoRestart(XShape_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XShape_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_AP_CTRL, 0);
}

u32 XShape_accel_Get_pred_class(XShape_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XShape_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_PRED_CLASS_DATA);
    return Data;
}

u32 XShape_accel_Get_pred_class_vld(XShape_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XShape_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_PRED_CLASS_CTRL);
    return Data & 0x1;
}

u32 XShape_accel_Get_scores_BaseAddress(XShape_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Ctrl_BaseAddress + XSHAPE_ACCEL_CTRL_ADDR_SCORES_BASE);
}

u32 XShape_accel_Get_scores_HighAddress(XShape_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Ctrl_BaseAddress + XSHAPE_ACCEL_CTRL_ADDR_SCORES_HIGH);
}

u32 XShape_accel_Get_scores_TotalBytes(XShape_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XSHAPE_ACCEL_CTRL_ADDR_SCORES_HIGH - XSHAPE_ACCEL_CTRL_ADDR_SCORES_BASE + 1);
}

u32 XShape_accel_Get_scores_BitWidth(XShape_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSHAPE_ACCEL_CTRL_WIDTH_SCORES;
}

u32 XShape_accel_Get_scores_Depth(XShape_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSHAPE_ACCEL_CTRL_DEPTH_SCORES;
}

u32 XShape_accel_Write_scores_Words(XShape_accel *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XSHAPE_ACCEL_CTRL_ADDR_SCORES_HIGH - XSHAPE_ACCEL_CTRL_ADDR_SCORES_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Ctrl_BaseAddress + XSHAPE_ACCEL_CTRL_ADDR_SCORES_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XShape_accel_Read_scores_Words(XShape_accel *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XSHAPE_ACCEL_CTRL_ADDR_SCORES_HIGH - XSHAPE_ACCEL_CTRL_ADDR_SCORES_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Ctrl_BaseAddress + XSHAPE_ACCEL_CTRL_ADDR_SCORES_BASE + (offset + i)*4);
    }
    return length;
}

u32 XShape_accel_Write_scores_Bytes(XShape_accel *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XSHAPE_ACCEL_CTRL_ADDR_SCORES_HIGH - XSHAPE_ACCEL_CTRL_ADDR_SCORES_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Ctrl_BaseAddress + XSHAPE_ACCEL_CTRL_ADDR_SCORES_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XShape_accel_Read_scores_Bytes(XShape_accel *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XSHAPE_ACCEL_CTRL_ADDR_SCORES_HIGH - XSHAPE_ACCEL_CTRL_ADDR_SCORES_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Ctrl_BaseAddress + XSHAPE_ACCEL_CTRL_ADDR_SCORES_BASE + offset + i);
    }
    return length;
}

u32 XShape_accel_Get_img_BaseAddress(XShape_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Ctrl_BaseAddress + XSHAPE_ACCEL_CTRL_ADDR_IMG_BASE);
}

u32 XShape_accel_Get_img_HighAddress(XShape_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Ctrl_BaseAddress + XSHAPE_ACCEL_CTRL_ADDR_IMG_HIGH);
}

u32 XShape_accel_Get_img_TotalBytes(XShape_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XSHAPE_ACCEL_CTRL_ADDR_IMG_HIGH - XSHAPE_ACCEL_CTRL_ADDR_IMG_BASE + 1);
}

u32 XShape_accel_Get_img_BitWidth(XShape_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSHAPE_ACCEL_CTRL_WIDTH_IMG;
}

u32 XShape_accel_Get_img_Depth(XShape_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSHAPE_ACCEL_CTRL_DEPTH_IMG;
}

u32 XShape_accel_Write_img_Words(XShape_accel *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XSHAPE_ACCEL_CTRL_ADDR_IMG_HIGH - XSHAPE_ACCEL_CTRL_ADDR_IMG_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Ctrl_BaseAddress + XSHAPE_ACCEL_CTRL_ADDR_IMG_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XShape_accel_Read_img_Words(XShape_accel *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XSHAPE_ACCEL_CTRL_ADDR_IMG_HIGH - XSHAPE_ACCEL_CTRL_ADDR_IMG_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Ctrl_BaseAddress + XSHAPE_ACCEL_CTRL_ADDR_IMG_BASE + (offset + i)*4);
    }
    return length;
}

u32 XShape_accel_Write_img_Bytes(XShape_accel *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XSHAPE_ACCEL_CTRL_ADDR_IMG_HIGH - XSHAPE_ACCEL_CTRL_ADDR_IMG_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Ctrl_BaseAddress + XSHAPE_ACCEL_CTRL_ADDR_IMG_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XShape_accel_Read_img_Bytes(XShape_accel *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XSHAPE_ACCEL_CTRL_ADDR_IMG_HIGH - XSHAPE_ACCEL_CTRL_ADDR_IMG_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Ctrl_BaseAddress + XSHAPE_ACCEL_CTRL_ADDR_IMG_BASE + offset + i);
    }
    return length;
}

void XShape_accel_InterruptGlobalEnable(XShape_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XShape_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_GIE, 1);
}

void XShape_accel_InterruptGlobalDisable(XShape_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XShape_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_GIE, 0);
}

void XShape_accel_InterruptEnable(XShape_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XShape_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_IER);
    XShape_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_IER, Register | Mask);
}

void XShape_accel_InterruptDisable(XShape_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XShape_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_IER);
    XShape_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_IER, Register & (~Mask));
}

void XShape_accel_InterruptClear(XShape_accel *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XShape_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_ISR, Mask);
}

u32 XShape_accel_InterruptGetEnabled(XShape_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XShape_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_IER);
}

u32 XShape_accel_InterruptGetStatus(XShape_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XShape_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XSHAPE_ACCEL_CTRL_ADDR_ISR);
}

