set(CMAKE_HOST_SYSTEM "Linux-7.0.0-34-generic")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "7.0.0-34-generic")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/home/diogo-azevedo/Robot_Systems_MSc/Embedded_Systems/Assignment_2/vitis_workspace/pynq_dfx_platfrom/ps7_cortexa9_0/standalone_ps7_cortexa9_0/bsp/cortexa9_toolchain.cmake")

set(CMAKE_SYSTEM "Generic")
set(CMAKE_SYSTEM_NAME "Generic")
set(CMAKE_SYSTEM_VERSION "")
set(CMAKE_SYSTEM_PROCESSOR "cortexa9")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
