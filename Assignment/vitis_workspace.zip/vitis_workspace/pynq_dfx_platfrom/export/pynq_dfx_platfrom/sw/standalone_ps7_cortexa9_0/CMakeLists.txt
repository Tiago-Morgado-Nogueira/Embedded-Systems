
cmake_minimum_required(VERSION 3.24.2)
project(bsp)
find_package(common)
find_package(commonmeta)
if(CMAKE_EXPORT_COMPILE_COMMANDS)
    set(CMAKE_CXX_STANDARD_INCLUDE_DIRECTORIES ${CMAKE_CXX_IMPLICIT_INCLUDE_DIRECTORIES})
    set(CMAKE_C_STANDARD_INCLUDE_DIRECTORIES ${CMAKE_C_IMPLICIT_INCLUDE_DIRECTORIES})
endif()

ADD_DEFINITIONS(-c ${proc_extra_compiler_flags})
include_directories(${CMAKE_BINARY_DIR}/include)
include_directories(${CMAKE_INCLUDE_PATH})

if("${CMAKE_SYSTEM_NAME}" STREQUAL "FreeRTOS")
add_compile_definitions(FREERTOS_BSP)
endif()
if (EXISTS ${metal_BINARY_DIR})
include_directories(${metal_BINARY_DIR}/lib/include)
endif()
set (BSP_LIBSRC_SUBDIRS standalone libsrc xiltimer xilffs)
if (SUBDIR_LIST STREQUAL "ALL")
    set (SUBDIR_LIST ${BSP_LIBSRC_SUBDIRS})
endif()

foreach(entry ${SUBDIR_LIST})
    if(entry STREQUAL "libsrc")
        set (path "${CMAKE_LIBRARY_PATH}/../libsrc")
    else()
        set (path "${CMAKE_LIBRARY_PATH}/../libsrc/${entry}/src")
    endif()
    if(EXISTS ${path})
        add_subdirectory(${path})
    endif()
endforeach()
cmake_language(DEFER DIRECTORY ${CMAKE_SOURCE_DIR} CALL _my_hook_end_of_configure())
function(_my_hook_end_of_configure)
    set(SUBDIR_LIST "ALL" CACHE STRING "sub dir list" FORCE)
endfunction(_my_hook_end_of_configure)

        if(COMMAND split_string_by_length)
            split_string_by_length("Compiler FLAGS: ${CMAKE_C_FLAGS} ${proc_extra_compiler_flags} ${CMAKE_C_FLAGS_RELEASE}" 100 CHUNKS)
        else()
            set(CHUNKS "Compiler FLAGS: ${CMAKE_C_FLAGS} ${proc_extra_compiler_flags} ${CMAKE_C_FLAGS_RELEASE}")
        endif()
        add_custom_target(print_compiler ALL
            COMMAND ${CMAKE_COMMAND} -E echo ""
            COMMAND ${CMAKE_COMMAND} -E echo "Compiler PATH: ${CMAKE_C_COMPILER}"
            COMMAND ${CMAKE_COMMAND} -E echo ""
            COMMAND ${CMAKE_COMMAND} -E cmake_echo_color ${CHUNKS}
            COMMAND ${CMAKE_COMMAND} -E echo ""
            COMMAND ${CMAKE_COMMAND} -E echo "==========================================="
            COMMAND ${CMAKE_COMMAND} -E echo "** The above flags are BSP level flags. Increase verbosity to see component specific flags **"
            COMMAND ${CMAKE_COMMAND} -E echo "==========================================="
            COMMENT "========== BSP Build Information =========="
        )
    