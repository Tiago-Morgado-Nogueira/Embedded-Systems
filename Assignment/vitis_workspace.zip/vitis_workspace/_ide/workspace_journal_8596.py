# 2026-11-23T14:32:02.321752722
import vitis

client = vitis.create_client()
client.set_workspace(path="vitis_workspace")

vitis.dispose()

