# 2026-11-21T19:33:40.391481026
import vitis

client = vitis.create_client()
client.set_workspace(path="vitis_workspace")

platform = client.get_component(name="pynq_dfx_platfrom")
status = platform.build()

comp = client.get_component(name="shape_dfx_app")
status = comp.clean()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

vitis.dispose()

