# 2026-11-21T16:54:59.139986787
import vitis

client = vitis.create_client()
client.set_workspace(path="vitis_workspace")

platform = client.create_platform_component(name = "pynq_dfx_platfrom",hw_design = "$COMPONENT_LOCATION/../../assignment_2/system_wrapper.xsa",os = "standalone",cpu = "ps7_cortexa9_0",domain_name = "standalone_ps7_cortexa9_0",compiler = "gcc")

platform = client.get_component(name="pynq_dfx_platfrom")
domain = platform.get_domain(name="standalone_ps7_cortexa9_0")

status = domain.set_lib(lib_name="xilffs", path="/tools/2026.1/Vitis/data/embeddedsw/lib/sw_services/xilffs_v5_6")

status = platform.build()

comp = client.create_app_component(name="shape_dfx_app",platform = "$COMPONENT_LOCATION/../pynq_dfx_platfrom/export/pynq_dfx_platfrom/pynq_dfx_platfrom.xpfm",domain = "standalone_ps7_cortexa9_0")

status = platform.build()

comp = client.get_component(name="shape_dfx_app")
comp.build()

vitis.dispose()

