# 2026-11-23T15:06:39.702293694
import vitis

client = vitis.create_client()
client.set_workspace(path="vitis_workspace")

platform = client.get_component(name="pynq_dfx_platfrom")
status = platform.build()

status = platform.build()

comp = client.get_component(name="shape_dfx_app")
comp.build()

vitis.dispose()

