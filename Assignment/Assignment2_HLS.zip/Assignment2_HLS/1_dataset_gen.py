from pathlib import Path
import shutil
import cv2
import numpy as np

CLASSES = ["Square", "Circle", "Figure-8", "Triangle"] # , "Rectangle", "Ellipse"]
IMG_SIZE = 32
SPLITS = {
    "train": 700,
    "val": 150,
    "test": 150,
}
SEED = 42
DATASET_DIR = Path("dataset")


def draw_shape(class_id: int, rng: np.random.Generator) -> np.ndarray:
    img = np.zeros((IMG_SIZE, IMG_SIZE), dtype=np.uint8)
    # 32x32-es kép közepe 15.5 -> 13..19 között ±3 px eltolás
    cx = int(rng.integers(13, 20))
    cy = int(rng.integers(13, 20))
    thickness = int(rng.integers(1, 3))  # 1 vagy 2 px vonalvastagság

    if class_id == 0:  # Square (Négyzet, max átló: 8.0 * sqrt(2) = 11.3 px)
        half_side = float(rng.uniform(5.5, 8.0))
        angle = np.deg2rad(rng.uniform(0, 90))
        corners = np.array([
            [-half_side, -half_side],
            [ half_side, -half_side],
            [ half_side,  half_side],
            [-half_side,  half_side],
        ])
        rot = np.array([[np.cos(angle), -np.sin(angle)],
                        [np.sin(angle),  np.cos(angle)]])
        pts = np.round(corners @ rot.T + np.array([cx, cy])).astype(np.int32)
        cv2.polylines(img, [pts], isClosed=True, color=255, thickness=thickness)

    elif class_id == 1:  # Circle (Kör, sugár: 6..10 px)
        radius = int(rng.integers(6, 11))
        cv2.circle(img, (cx, cy), radius, color=255, thickness=thickness)

    elif class_id == 2:  # Figure-8 (Nyolcas alakzat, két 4 vagy 5 px sugarú kör)
        r = int(rng.integers(4, 6))
        angle = np.deg2rad(rng.uniform(0, 180))
        offset = r - 0.5
        dx = int(round(offset * np.cos(angle)))
        dy = int(round(offset * np.sin(angle)))
        cv2.circle(img, (cx - dx, cy - dy), r, color=255, thickness=thickness)
        cv2.circle(img, (cx + dx, cy + dy), r, color=255, thickness=thickness)

    elif class_id == 3:  # Triangle (Háromszög, sugár: 7.0..10.5 px)
        radius = float(rng.uniform(7.0, 10.5))
        base_angle = np.deg2rad(rng.uniform(0, 360))
        angles = base_angle + np.deg2rad([0, 120, 240])
        pts = np.column_stack([
            cx + radius * np.cos(angles),
            cy + radius * np.sin(angles),
        ])
        pts = np.round(pts).astype(np.int32)
        cv2.polylines(img, [pts], isClosed=True, color=255, thickness=thickness)

    # elif class_id == 4:  # Rectangle (Téglalap, min. ~1.9x oldalarány, max átló ~11.2 px)
    #     short_half = float(rng.uniform(3.0, 4.5))
    #     long_half = float(rng.uniform(8.2, 10.2))
    #     angle = np.deg2rad(rng.uniform(0, 180))
    #     corners = np.array([
    #         [-long_half, -short_half],
    #         [ long_half, -short_half],
    #         [ long_half,  short_half],
    #         [-long_half,  short_half],
    #     ])
    #     rot = np.array([[np.cos(angle), -np.sin(angle)],
    #                     [np.sin(angle),  np.cos(angle)]])
    #     pts = np.round(corners @ rot.T + np.array([cx, cy])).astype(np.int32)
    #     cv2.polylines(img, [pts], isClosed=True, color=255, thickness=thickness)

    # elif class_id == 5:  # Ellipse (Ellipszis, min. 2x tengelyarány, fél nagytengely 8..11 px)
    #     minor_axis = int(rng.integers(3, 5))
    #     major_axis = int(rng.integers(8, 12))
    #     angle = float(rng.uniform(0, 180))
    #     cv2.ellipse(img, (cx, cy), (major_axis, minor_axis),
    #                 angle, 0, 360, color=255, thickness=thickness)

    return img


def main():
    if DATASET_DIR.exists():
        shutil.rmtree(DATASET_DIR)

    rng = np.random.default_rng(SEED)
    preview_grid = np.zeros((len(CLASSES) * IMG_SIZE, 8 * IMG_SIZE), dtype=np.uint8)

    for split_name, count_per_class in SPLITS.items():
        for cls_id, cls_name in enumerate(CLASSES):
            folder = DATASET_DIR / split_name / f"{cls_id}_{cls_name}"
            folder.mkdir(parents=True, exist_ok=True)

            for i in range(count_per_class):
                img = draw_shape(cls_id, rng)
                filename = folder / f"{cls_name.lower()}_{i:04d}.png"
                cv2.imwrite(str(filename), img)

                if split_name == "test" and i < 8:
                    preview_grid[
                        cls_id * IMG_SIZE:(cls_id + 1) * IMG_SIZE,
                        i * IMG_SIZE:(i + 1) * IMG_SIZE,
                    ] = img

    cv2.imwrite("dataset_preview.png", preview_grid)
    print(f"Done! Pictures saved to: {DATASET_DIR.resolve()}")


if __name__ == "__main__":
    main()