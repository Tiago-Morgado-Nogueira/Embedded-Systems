from pathlib import Path
import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader

DATASET_DIR = Path("dataset")
CLASSES = ["Square", "Circle", "Figure-8", "Triangle"] #, "Rectangle", "Ellipse"]
TIME_STEPS = 32
FIXED_SHIFT = 12
FIXED_SCALE = 1 << FIXED_SHIFT  # 4096 (Q4.12)
NUM_EXPORT_TEST_VECTORS = 20


def load_image_split(split_name: str, shuffle: bool = False, seed: int = 42):
    split_dir = DATASET_DIR / split_name
    images, labels = [], []
    for cls_id, cls_name in enumerate(CLASSES):
        cls_dir = split_dir / f"{cls_id}_{cls_name}"
        for img_path in sorted(cls_dir.glob("*.png")):
            img = cv2.imread(str(img_path), cv2.IMREAD_GRAYSCALE)
            images.append(img)
            labels.append(cls_id)

    X = np.array(images, dtype=np.uint8)
    y = np.array(labels, dtype=np.int64)

    if shuffle:
        rng = np.random.default_rng(seed)
        perm = rng.permutation(len(X))
        X, y = X[perm], y[perm]

    return X, y


class CompactCNN(nn.Module):
    def __init__(self, num_classes: int = 4, img_size: int = 32):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 4, kernel_size=3, padding=1, bias=False)
        self.pool1 = nn.AvgPool2d(2)
        self.conv2 = nn.Conv2d(4, 8, kernel_size=3, padding=1, bias=False)
        self.pool2 = nn.AvgPool2d(2)
        feat_dim = img_size // 4
        self.fc = nn.Linear(8 * feat_dim * feat_dim, num_classes, bias=False)

    def forward(self, x):
        x = self.pool1(F.relu(self.conv1(x)))
        x = self.pool2(F.relu(self.conv2(x)))
        x = x.view(x.size(0), -1)
        return self.fc(x)


def train_cnn(model, train_loader, val_x, val_y, epochs=25):
    optimizer = torch.optim.Adam(model.parameters(), lr=2e-3)
    criterion = nn.CrossEntropyLoss()
    best_acc = 0.0
    best_state = None

    for _ in range(epochs):
        model.train()
        for bx, by in train_loader:
            optimizer.zero_grad()
            loss = criterion(model(bx), by)
            loss.backward()
            optimizer.step()

        model.eval()
        with torch.no_grad():
            preds = model(val_x).argmax(dim=1)
            val_acc = (preds == val_y).float().mean().item()
            if val_acc >= best_acc:
                best_acc = val_acc
                best_state = {k: v.clone() for k, v in model.state_dict().items()}

    model.load_state_dict(best_state)
    print(f"Best validated CNN accuracy: {best_acc * 100:.2f}%")


@torch.no_grad()
def normalize_for_snn(model: CompactCNN, calib_x: torch.Tensor):
    """Pozitív, pooling előtti aktivációk 98-as percentilisére skáláz."""
    model.eval()

    c1 = F.relu(model.conv1(calib_x))
    scale1 = float(torch.quantile(c1[c1 > 0], 0.98))
    model.conv1.weight.div_(scale1)
    p1 = model.pool1(c1 / scale1)

    c2 = F.relu(model.conv2(p1))
    scale2 = float(torch.quantile(c2[c2 > 0], 0.98))
    model.conv2.weight.div_(scale2)
    p2 = model.pool2(c2 / scale2)

    out = model.fc(p2.view(calib_x.size(0), -1))
    scale3 = float(torch.quantile(out.abs(), 0.99))
    model.fc.weight.div_(scale3)


@torch.no_grad()
def run_snn_inference(model: CompactCNN, x: torch.Tensor, time_steps: int = TIME_STEPS):
    """Integrate-and-Fire SNN szimuláció fél-küszöbös inicializálással."""
    B, _, H, W = x.shape
    num_classes = model.fc.out_features

    v_in = torch.zeros_like(x)
    v_c1 = torch.full((B, 4, H, W), 0.5)
    v_c2 = torch.full((B, 8, H // 2, W // 2), 0.5)
    v_out = torch.zeros((B, num_classes))

    for _ in range(time_steps):
        v_in += x
        s0 = (v_in >= 1.0).float()
        v_in -= s0

        v_c1 += model.conv1(s0)
        s1 = (v_c1 >= 1.0).float()
        v_c1 -= s1
        p1 = model.pool1(s1)

        v_c2 += model.conv2(p1)
        s2 = (v_c2 >= 1.0).float()
        v_c2 -= s2
        p2 = model.pool2(s2)

        v_out += model.fc(p2.view(B, -1))

    return v_out


def print_metrics(name: str, preds: np.ndarray, targets: np.ndarray):
    overall = (preds == targets).mean() * 100
    print(f"\n=== {name} Overall test accuracy: {overall:.2f}% ===")
    for idx, cname in enumerate(CLASSES):
        mask = targets == idx
        cls_acc = (preds[mask] == targets[mask]).mean() * 100
        print(f"  - {cname:<10}: {cls_acc:.2f}% ({np.sum(preds[mask] == idx)}/{np.sum(mask)})")


def format_c_array(name: str, arr: np.ndarray, c_type: str = "int16_t") -> str:
    flat = arr.flatten()
    vals = ", ".join(str(int(v)) for v in flat)
    return f"const {c_type} {name}[{len(flat)}] = {{\n    {vals}\n}};\n\n"


def export_c_headers(model: CompactCNN, X_test_u8: np.ndarray, y_test: np.ndarray,
                     cnn_preds: np.ndarray, snn_preds: np.ndarray):
    w_c1 = np.round(model.conv1.weight.detach().numpy() * FIXED_SCALE).astype(np.int16)
    w_c2 = np.round(model.conv2.weight.detach().numpy() * FIXED_SCALE).astype(np.int16)
    w_fc = np.round(model.fc.weight.detach().numpy() * FIXED_SCALE).astype(np.int16)

    with open("model_weights.h", "w") as f:
        f.write("#ifndef MODEL_WEIGHTS_H\n#define MODEL_WEIGHTS_H\n\n#include <stdint.h>\n\n")
        f.write(f"#define FIXED_SHIFT {FIXED_SHIFT}\n")
        f.write(f"#define SNN_TIME_STEPS {TIME_STEPS}\n\n")
        f.write(format_c_array("W_CONV1", w_c1))
        f.write(format_c_array("W_CONV2", w_c2))
        f.write(format_c_array("W_FC", w_fc))
        f.write("#endif // MODEL_WEIGHTS_H\n")

    n = NUM_EXPORT_TEST_VECTORS
    with open("test_vectors.h", "w") as f:
        f.write("#ifndef TEST_VECTORS_H\n#define TEST_VECTORS_H\n\n#include <stdint.h>\n\n")
        f.write(f"#define NUM_TEST_IMAGES {n}\n\n")
        f.write(format_c_array("TEST_IMAGES", X_test_u8[:n], c_type="uint8_t"))
        f.write(format_c_array("TEST_LABELS", y_test[:n], c_type="uint8_t"))
        f.write(format_c_array("EXPECTED_CNN_PREDS", cnn_preds[:n], c_type="uint8_t"))
        f.write(format_c_array("EXPECTED_SNN_PREDS", snn_preds[:n], c_type="uint8_t"))
        f.write("#endif // TEST_VECTORS_H\n")

    print("\nExported: model_weights.h and test_vectors.h")


def main():
    torch.manual_seed(42)

    X_train_u8, y_train_np = load_image_split("train", shuffle=True)
    X_val_u8, y_val_np = load_image_split("val", shuffle=False)
    X_test_u8, y_test_np = load_image_split("test", shuffle=True, seed=99)

    X_train = torch.tensor(X_train_u8, dtype=torch.float32).unsqueeze(1) / 255.0
    y_train = torch.tensor(y_train_np, dtype=torch.long)
    X_val = torch.tensor(X_val_u8, dtype=torch.float32).unsqueeze(1) / 255.0
    y_val = torch.tensor(y_val_np, dtype=torch.long)
    X_test = torch.tensor(X_test_u8, dtype=torch.float32).unsqueeze(1) / 255.0

    train_loader = DataLoader(TensorDataset(X_train, y_train), batch_size=64, shuffle=True)

    img_size = X_train_u8.shape[1]
    model = CompactCNN(num_classes=len(CLASSES), img_size=img_size)
    train_cnn(model, train_loader, X_val, y_val, epochs=25)

    normalize_for_snn(model, X_train[:500])

    model.eval()
    with torch.no_grad():
        cnn_preds = model(X_test).argmax(dim=1).numpy()
    snn_preds = run_snn_inference(model, X_test, time_steps=TIME_STEPS).argmax(dim=1).numpy()

    print_metrics("CNN (Software Ref)", cnn_preds, y_test_np)
    print_metrics(f"SNN (T={TIME_STEPS} steps)", snn_preds, y_test_np)

    export_c_headers(model, X_test_u8, y_test_np, cnn_preds, snn_preds)


if __name__ == "__main__":
    main()