# 2026-11-19T16:21:16.138842168
import vitis

client = vitis.create_client()
client.set_workspace(path="Assignment2_HLS")

cfg = client.get_config_file(path="/home/tpeti/V_ES_Second_Assignment/Assignment2_HLS/cnn_hls/hls_config.cfg")

cfg.set_value(section="hls", key="package.ip.name", value="cnn_shape")

comp = client.get_component(name="cnn_hls")
comp.run(operation="C_SIMULATION")

comp.run(operation="SYNTHESIS")

comp.run(operation="PACKAGE")

cfg = client.get_config_file(path="/home/tpeti/V_ES_Second_Assignment/Assignment2_HLS/snn_hls/hls_config.cfg")

cfg.set_value(section="hls", key="package.ip.name", value="snn_shape")

comp = client.get_component(name="snn_hls")
comp.run(operation="C_SIMULATION")

comp.run(operation="SYNTHESIS")

comp.run(operation="PACKAGE")

vitis.dispose()

