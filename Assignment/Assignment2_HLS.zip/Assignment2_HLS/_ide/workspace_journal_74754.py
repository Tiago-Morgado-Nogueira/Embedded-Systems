# 2026-11-19T14:41:42.975111923
import vitis

client = vitis.create_client()
client.set_workspace(path="Assignment2_HLS")

comp = client.create_hls_component(name = "cnn_hls",part = "xc7z020clg400-1",cfg_file = ["hls_config.cfg"],template = "empty_hls_component")

cfg = client.get_config_file(path="/home/tpeti/V_ES_Second_Assignment/Assignment2_HLS/cnn_hls/hls_config.cfg")

cfg.set_values(key="syn.file", values=["/home/tpeti/V_ES_Second_Assignment/cnn_accel.cpp", "/home/tpeti/V_ES_Second_Assignment/model_weights.h", "/home/tpeti/V_ES_Second_Assignment/shape_accel.h"])

cfg.set_values(key="tb.file", values=["/home/tpeti/V_ES_Second_Assignment/tb_accel.cpp", "/home/tpeti/V_ES_Second_Assignment/test_vectors.h"])

cfg.set_value(section="hls", key="syn.top", value="shape_accel")

comp = client.get_component(name="cnn_hls")
comp.run(operation="C_SIMULATION")

comp.run(operation="C_SIMULATION")

comp.run(operation="SYNTHESIS")

cfg.set_values(key="syn.file", values=["/home/tpeti/V_ES_Second_Assignment/cnn_accel.cpp", "/home/tpeti/V_ES_Second_Assignment/shape_accel.h"])

cfg.set_values(key="syn.blackbox.file", values=[])

cfg.set_values(key="tb.file", values=["/home/tpeti/V_ES_Second_Assignment/tb_accel.cpp"])

cfg.set_values(key="syn.file", values=["/home/tpeti/V_ES_Second_Assignment/cnn_accel.cpp", "/home/tpeti/V_ES_Second_Assignment/shape_accel.h", "/home/tpeti/V_ES_Second_Assignment/model_weights.h"])

cfg.set_values(key="tb.file", values=["/home/tpeti/V_ES_Second_Assignment/tb_accel.cpp", "/home/tpeti/V_ES_Second_Assignment/test_vectors.h"])

comp.run(operation="C_SIMULATION")

comp.run(operation="SYNTHESIS")

comp.run(operation="PACKAGE")

comp = client.create_hls_component(name = "snn_hls",part = "xc7z020clg400-1",cfg_file = ["hls_config.cfg"],template = "empty_hls_component")

cfg = client.get_config_file(path="/home/tpeti/V_ES_Second_Assignment/Assignment2_HLS/snn_hls/hls_config.cfg")

cfg.set_values(key="syn.file", values=["/home/tpeti/V_ES_Second_Assignment/model_weights.h", "/home/tpeti/V_ES_Second_Assignment/shape_accel.h", "/home/tpeti/V_ES_Second_Assignment/snn_accel.cpp"])

cfg.set_values(key="tb.file", values=["/home/tpeti/V_ES_Second_Assignment/tb_accel.cpp", "/home/tpeti/V_ES_Second_Assignment/test_vectors.h"])

cfg.set_value(section="hls", key="syn.top", value="shape_accel")

comp = client.get_component(name="snn_hls")
comp.run(operation="C_SIMULATION")

cfg.set_value(section="hls", key="tb.cflags", value="-DTEST_SNN")

cfg.set_value(section="hls", key="syn.csimflags", value="")

cfg.set_values(key="tb.file_cflags", values=[])

cfg.set_values(key="tb.file", values=["/home/tpeti/V_ES_Second_Assignment/tb_accel.cpp", "/home/tpeti/V_ES_Second_Assignment/test_vectors.h"])

comp.run(operation="C_SIMULATION")

cfg.set_value(section="hls", key="syn.csimflags", value="")

cfg.set_value(section="hls", key="tb.cflags", value="")

cfg.set_values(key="tb.file_cflags", values=[])

cfg.set_values(key="tb.file", values=["/home/tpeti/V_ES_Second_Assignment/tb_accel.cpp", "/home/tpeti/V_ES_Second_Assignment/test_vectors.h"])

cfg.set_value(section="hls", key="tb.cflags", value="")

cfg.set_value(section="hls", key="syn.csimflags", value="")

cfg.set_values(key="tb.file_cflags", values=["/home/tpeti/V_ES_Second_Assignment/tb_accel.cpp,-DTEST_SNN"])

cfg.set_values(key="tb.file", values=["/home/tpeti/V_ES_Second_Assignment/tb_accel.cpp", "/home/tpeti/V_ES_Second_Assignment/test_vectors.h"])

comp.run(operation="C_SIMULATION")

comp.run(operation="C_SIMULATION")

comp.run(operation="C_SIMULATION")

cfg.set_value(section="hls", key="csim.setup", value="1")

comp.run(operation="C_SIMULATION")

comp.run(operation="SYNTHESIS")

comp.run(operation="PACKAGE")

cfg = client.get_config_file(path="/home/tpeti/V_ES_Second_Assignment/Assignment2_HLS/cnn_hls/hls_config.cfg")

cfg.set_value(section="hls", key="package.output.file", value="cnn_shape_accel")

comp = client.get_component(name="cnn_hls")
comp.run(operation="PACKAGE")

cfg = client.get_config_file(path="/home/tpeti/V_ES_Second_Assignment/Assignment2_HLS/snn_hls/hls_config.cfg")

cfg.set_value(section="hls", key="package.output.file", value="snn_shape_accel")

comp = client.get_component(name="snn_hls")
comp.run(operation="PACKAGE")

vitis.dispose()

