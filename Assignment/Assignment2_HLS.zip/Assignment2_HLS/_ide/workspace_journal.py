# 2026-11-23T15:21:00.284753175
import vitis

client = vitis.create_client()
client.set_workspace(path="Assignment2_HLS")

comp = client.get_component(name="cnn_hls")
comp.run(operation="C_SIMULATION")

comp.run(operation="SYNTHESIS")

comp = client.get_component(name="snn_hls")
comp.run(operation="C_SIMULATION")

comp.run(operation="SYNTHESIS")

vitis.dispose()

