# 2026-11-19T14:26:20.270956149
import vitis

client = vitis.create_client()
client.set_workspace(path="Assignment2_HLS")

vitis.dispose()

