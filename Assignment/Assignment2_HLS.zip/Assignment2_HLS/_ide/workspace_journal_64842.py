# 2026-11-23T14:41:34.305398189
import vitis

client = vitis.create_client()
client.set_workspace(path="Assignment2_HLS")

cfg = client.get_config_file(path="/home/diogo-azevedo/Robot_Systems_MSc/Assignment2_HLS/cnn_hls/hls_config.cfg")

cfg = client.get_config_file(path="/home/diogo-azevedo/Robot_Systems_MSc/Assignment2_HLS/cnn_hls/hls_config.cfg")

cfg = client.get_config_file(path="/home/diogo-azevedo/Robot_Systems_MSc/Assignment2_HLS/cnn_hls/hls_config.cfg")

cfg.set_value(section="hls", key="syn.csimflags", value="")

cfg.set_value(section="hls", key="syn.cflags", value="")

cfg = client.get_config_file(path="/home/diogo-azevedo/Robot_Systems_MSc/Assignment2_HLS/cnn_hls/hls_config.cfg")

cfg = client.get_config_file(path="/home/diogo-azevedo/Robot_Systems_MSc/Assignment2_HLS/cnn_hls/hls_config.cfg")

cfg.set_values(key="syn.file_cflags", values=[])

cfg.set_values(key="syn.file_csimflags", values=[])

cfg.set_values(key="syn.file", values=["/home/tpeti/V_ES_Second_Assignment/shape_accel.h", "/home/tpeti/V_ES_Second_Assignment/model_weights.h"])

cfg.set_value(section="hls", key="syn.csimflags", value="")

cfg.set_value(section="hls", key="syn.cflags", value="")

cfg.set_values(key="syn.file", values=["/home/tpeti/V_ES_Second_Assignment/model_weights.h"])

cfg.set_values(key="syn.file_csimflags", values=[])

cfg.set_values(key="syn.file_cflags", values=[])

cfg.set_value(section="hls", key="syn.cflags", value="")

cfg.set_value(section="hls", key="syn.csimflags", value="")

cfg.set_values(key="syn.file", values=[])

cfg.set_values(key="syn.file_cflags", values=[])

cfg.set_values(key="syn.file_csimflags", values=[])

cfg.set_values(key="tb.file", values=["/home/tpeti/V_ES_Second_Assignment/tb_accel.cpp", "/home/tpeti/V_ES_Second_Assignment/test_vectors.h", "../tb_accel.cpp", "../test_vectors.h"])

cfg = client.get_config_file(path="/home/diogo-azevedo/Robot_Systems_MSc/Assignment2_HLS/snn_hls/hls_config.cfg")

cfg.set_values(key="tb.file", values=["/home/tpeti/V_ES_Second_Assignment/tb_accel.cpp", "/home/tpeti/V_ES_Second_Assignment/test_vectors.h", "../tb_accel.cpp", "../test_vectors.h"])

cfg.set_values(key="syn.file", values=["/home/tpeti/V_ES_Second_Assignment/model_weights.h", "/home/tpeti/V_ES_Second_Assignment/shape_accel.h", "/home/tpeti/V_ES_Second_Assignment/snn_accel.cpp", "../model_weights.h", "../shape_accel.h", "../snn_accel.cpp"])

cfg = client.get_config_file(path="/home/diogo-azevedo/Robot_Systems_MSc/Assignment2_HLS/cnn_hls/hls_config.cfg")

cfg.set_values(key="syn.file", values=["../cnn_accel.cpp", "../model_weights.h", "../shape_accel.h"])

cfg.set_value(section="hls", key="syn.csimflags", value="")

cfg.set_value(section="hls", key="tb.cflags", value="")

cfg.set_values(key="tb.file", values=["/home/tpeti/V_ES_Second_Assignment/test_vectors.h", "../tb_accel.cpp", "../test_vectors.h"])

cfg.set_values(key="tb.file_cflags", values=[])

cfg.set_value(section="hls", key="tb.cflags", value="")

cfg.set_value(section="hls", key="syn.csimflags", value="")

cfg.set_values(key="tb.file_cflags", values=[])

cfg.set_values(key="tb.file", values=["../tb_accel.cpp", "../test_vectors.h"])

cfg.set_value(section="hls", key="tb.cflags", value="")

cfg.set_value(section="hls", key="syn.csimflags", value="")

cfg.set_values(key="tb.file_cflags", values=["../tb_accel.cpp,-DTEST_SNN"])

cfg.set_values(key="tb.file", values=["../tb_accel.cpp", "../test_vectors.h"])

comp = client.get_component(name="cnn_hls")
comp.run(operation="SYNTHESIS")

comp.run(operation="C_SIMULATION")

comp = client.get_component(name="snn_hls")
comp.run(operation="C_SIMULATION")

comp.run(operation="SYNTHESIS")

comp = client.get_component(name="cnn_hls")
comp.run(operation="C_SIMULATION")

comp.run(operation="SYNTHESIS")

comp = client.get_component(name="snn_hls")
comp.run(operation="C_SIMULATION")

comp.run(operation="SYNTHESIS")

vitis.dispose()

