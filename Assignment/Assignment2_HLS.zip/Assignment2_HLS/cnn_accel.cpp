#include "shape_accel.h"
#include "model_weights.h"

void shape_accel(
    const uint8_t img[IMG_SIZE],
    int32_t scores[NUM_CLASSES],
    int32_t *pred_class
) {
#pragma HLS INTERFACE s_axilite port=return bundle=CTRL
#pragma HLS INTERFACE s_axilite port=img bundle=CTRL
#pragma HLS INTERFACE s_axilite port=scores bundle=CTRL
#pragma HLS INTERFACE s_axilite port=pred_class bundle=CTRL

    int16_t x_in[32][32];
    int16_t c1[4][32][32];
    int16_t p1[4][16][16];
    int16_t c2[8][16][16];
    int16_t p2[8][8][8];

    // 1. Convert input pixels [0..255] -> Q4.12 [0..4096]
    for (int r = 0; r < 32; r++) {
        for (int c = 0; c < 32; c++) {
#pragma HLS PIPELINE II=1
            x_in[r][c] = (int16_t)(((int32_t)img[r * 32 + c] * (1 << FIXED_SHIFT)) / 255);
        }
    }

    // 2. Conv1 (1 -> 4, 3x3, pad=1) + ReLU
    for (int oc = 0; oc < 4; oc++) {
        for (int r = 0; r < 32; r++) {
            for (int c = 0; c < 32; c++) {
#pragma HLS PIPELINE II=1
                int32_t acc = 0;
                for (int kr = -1; kr <= 1; kr++) {
                    for (int kc = -1; kc <= 1; kc++) {
                        int ir = r + kr;
                        int ic = c + kc;
                        if (ir >= 0 && ir < 32 && ic >= 0 && ic < 32) {
                            int16_t w = W_CONV1[oc * 9 + (kr + 1) * 3 + (kc + 1)];
                            acc += (int32_t)x_in[ir][ic] * (int32_t)w;
                        }
                    }
                }
                int32_t val = acc >> FIXED_SHIFT;
                c1[oc][r][c] = (val > 0) ? (int16_t)val : 0;
            }
        }
    }

    // 3. Pool1 (2x2 AvgPool -> 4x16x16)
    for (int ch = 0; ch < 4; ch++) {
        for (int r = 0; r < 16; r++) {
            for (int c = 0; c < 16; c++) {
#pragma HLS PIPELINE II=1
                int32_t sum = (int32_t)c1[ch][2*r][2*c] + c1[ch][2*r][2*c+1] +
                              c1[ch][2*r+1][2*c] + c1[ch][2*r+1][2*c+1];
                p1[ch][r][c] = (int16_t)(sum >> 2);
            }
        }
    }

    // 4. Conv2 (4 -> 8, 3x3, pad=1) + ReLU
    for (int oc = 0; oc < 8; oc++) {
        for (int r = 0; r < 16; r++) {
            for (int c = 0; c < 16; c++) {
#pragma HLS PIPELINE II=1
                int32_t acc = 0;
                for (int ic = 0; ic < 4; ic++) {
                    for (int kr = -1; kr <= 1; kr++) {
                        for (int kc = -1; kc <= 1; kc++) {
                            int ir = r + kr;
                            int i_col = c + kc;
                            if (ir >= 0 && ir < 16 && i_col >= 0 && i_col < 16) {
                                int16_t w = W_CONV2[((oc * 4 + ic) * 3 + (kr + 1)) * 3 + (kc + 1)];
                                acc += (int32_t)p1[ic][ir][i_col] * (int32_t)w;
                            }
                        }
                    }
                }
                int32_t val = acc >> FIXED_SHIFT;
                c2[oc][r][c] = (val > 0) ? (int16_t)val : 0;
            }
        }
    }

    // 5. Pool2 (2x2 AvgPool -> 8x8x8)
    for (int ch = 0; ch < 8; ch++) {
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
#pragma HLS PIPELINE II=1
                int32_t sum = (int32_t)c2[ch][2*r][2*c] + c2[ch][2*r][2*c+1] +
                              c2[ch][2*r+1][2*c] + c2[ch][2*r+1][2*c+1];
                p2[ch][r][c] = (int16_t)(sum >> 2);
            }
        }
    }

    // 6. Fully Connected (512 -> 4) + Argmax
    int32_t best_score = -2147483647;
    int32_t best_cls = 0;

    for (int cls = 0; cls < NUM_CLASSES; cls++) {
        int32_t acc = 0;
        for (int ch = 0; ch < 8; ch++) {
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
#pragma HLS PIPELINE II=1
                    int idx = ch * 64 + r * 8 + c;
                    acc += (int32_t)p2[ch][r][c] * (int32_t)W_FC[cls * 512 + idx];
                }
            }
        }
        int32_t final_score = acc >> FIXED_SHIFT;
        scores[cls] = final_score;
        if (final_score > best_score) {
            best_score = final_score;
            best_cls = cls;
        }
    }

    *pred_class = best_cls;
}