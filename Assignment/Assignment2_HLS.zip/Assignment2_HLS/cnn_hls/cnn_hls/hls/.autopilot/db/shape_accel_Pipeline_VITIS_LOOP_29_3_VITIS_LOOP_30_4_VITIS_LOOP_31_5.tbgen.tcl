set moduleName shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5
set isTopModule 0
set isCombinational 0
set isDatapathOnly 0
set isPipelined 1
set isPipelined_legacy 1
set pipeline_type loop_auto_rewind
set FunctionProtocol ap_ctrl_hs
set restart_counter_num 0
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set hasInterrupt 0
set DLRegFirstOffset 0
set DLRegItemOffset 0
set svuvm_can_support 1
set cdfgNum 9
set C_modelName {shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5}
set C_modelType { void 0 }
set ap_memory_interface_dict [dict create]
dict set ap_memory_interface_dict x_in { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
dict set ap_memory_interface_dict x_in_1 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
dict set ap_memory_interface_dict x_in_2 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
dict set ap_memory_interface_dict x_in_3 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
dict set ap_memory_interface_dict x_in_4 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
dict set ap_memory_interface_dict x_in_5 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
dict set ap_memory_interface_dict x_in_6 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
dict set ap_memory_interface_dict x_in_7 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
dict set ap_memory_interface_dict x_in_8 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
dict set ap_memory_interface_dict c1 { MEM_WIDTH 13 MEM_SIZE 4096 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict c1_1 { MEM_WIDTH 13 MEM_SIZE 4096 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
set C_modelArgList {
	{ x_in int 13 regular {array 121 { 1 3 } 1 1 }  }
	{ x_in_1 int 13 regular {array 121 { 1 3 } 1 1 }  }
	{ x_in_2 int 13 regular {array 121 { 1 3 } 1 1 }  }
	{ x_in_3 int 13 regular {array 121 { 1 3 } 1 1 }  }
	{ x_in_4 int 13 regular {array 121 { 1 3 } 1 1 }  }
	{ x_in_5 int 13 regular {array 121 { 1 3 } 1 1 }  }
	{ x_in_6 int 13 regular {array 121 { 1 3 } 1 1 }  }
	{ x_in_7 int 13 regular {array 121 { 1 3 } 1 1 }  }
	{ x_in_8 int 13 regular {array 121 { 1 3 } 1 1 }  }
	{ c1 int 13 regular {array 2048 { 0 3 } 0 1 }  }
	{ c1_1 int 13 regular {array 2048 { 0 3 } 0 1 }  }
}
set hasAXIMCache 0
set l_AXIML2Cache [list]
set AXIMCacheInstDict [dict create]
set C_modelArgMapList {[ 
	{ "Name" : "x_in", "interface" : "memory", "bitwidth" : 13, "direction" : "READONLY"} , 
 	{ "Name" : "x_in_1", "interface" : "memory", "bitwidth" : 13, "direction" : "READONLY"} , 
 	{ "Name" : "x_in_2", "interface" : "memory", "bitwidth" : 13, "direction" : "READONLY"} , 
 	{ "Name" : "x_in_3", "interface" : "memory", "bitwidth" : 13, "direction" : "READONLY"} , 
 	{ "Name" : "x_in_4", "interface" : "memory", "bitwidth" : 13, "direction" : "READONLY"} , 
 	{ "Name" : "x_in_5", "interface" : "memory", "bitwidth" : 13, "direction" : "READONLY"} , 
 	{ "Name" : "x_in_6", "interface" : "memory", "bitwidth" : 13, "direction" : "READONLY"} , 
 	{ "Name" : "x_in_7", "interface" : "memory", "bitwidth" : 13, "direction" : "READONLY"} , 
 	{ "Name" : "x_in_8", "interface" : "memory", "bitwidth" : 13, "direction" : "READONLY"} , 
 	{ "Name" : "c1", "interface" : "memory", "bitwidth" : 13, "direction" : "WRITEONLY"} , 
 	{ "Name" : "c1_1", "interface" : "memory", "bitwidth" : 13, "direction" : "WRITEONLY"} ]}
# RTL Port declarations: 
set portNum 49
set portList { 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst sc_in sc_logic 1 reset -1 active_high_sync } 
	{ ap_start sc_in sc_logic 1 start -1 } 
	{ ap_done sc_out sc_logic 1 predone -1 } 
	{ ap_idle sc_out sc_logic 1 done -1 } 
	{ ap_ready sc_out sc_logic 1 ready -1 } 
	{ x_in_address0 sc_out sc_lv 7 signal 0 } 
	{ x_in_ce0 sc_out sc_logic 1 signal 0 } 
	{ x_in_q0 sc_in sc_lv 13 signal 0 } 
	{ x_in_1_address0 sc_out sc_lv 7 signal 1 } 
	{ x_in_1_ce0 sc_out sc_logic 1 signal 1 } 
	{ x_in_1_q0 sc_in sc_lv 13 signal 1 } 
	{ x_in_2_address0 sc_out sc_lv 7 signal 2 } 
	{ x_in_2_ce0 sc_out sc_logic 1 signal 2 } 
	{ x_in_2_q0 sc_in sc_lv 13 signal 2 } 
	{ x_in_3_address0 sc_out sc_lv 7 signal 3 } 
	{ x_in_3_ce0 sc_out sc_logic 1 signal 3 } 
	{ x_in_3_q0 sc_in sc_lv 13 signal 3 } 
	{ x_in_4_address0 sc_out sc_lv 7 signal 4 } 
	{ x_in_4_ce0 sc_out sc_logic 1 signal 4 } 
	{ x_in_4_q0 sc_in sc_lv 13 signal 4 } 
	{ x_in_5_address0 sc_out sc_lv 7 signal 5 } 
	{ x_in_5_ce0 sc_out sc_logic 1 signal 5 } 
	{ x_in_5_q0 sc_in sc_lv 13 signal 5 } 
	{ x_in_6_address0 sc_out sc_lv 7 signal 6 } 
	{ x_in_6_ce0 sc_out sc_logic 1 signal 6 } 
	{ x_in_6_q0 sc_in sc_lv 13 signal 6 } 
	{ x_in_7_address0 sc_out sc_lv 7 signal 7 } 
	{ x_in_7_ce0 sc_out sc_logic 1 signal 7 } 
	{ x_in_7_q0 sc_in sc_lv 13 signal 7 } 
	{ x_in_8_address0 sc_out sc_lv 7 signal 8 } 
	{ x_in_8_ce0 sc_out sc_logic 1 signal 8 } 
	{ x_in_8_q0 sc_in sc_lv 13 signal 8 } 
	{ c1_address0 sc_out sc_lv 11 signal 9 } 
	{ c1_ce0 sc_out sc_logic 1 signal 9 } 
	{ c1_we0 sc_out sc_logic 1 signal 9 } 
	{ c1_d0 sc_out sc_lv 13 signal 9 } 
	{ c1_1_address0 sc_out sc_lv 11 signal 10 } 
	{ c1_1_ce0 sc_out sc_logic 1 signal 10 } 
	{ c1_1_we0 sc_out sc_logic 1 signal 10 } 
	{ c1_1_d0 sc_out sc_lv 13 signal 10 } 
	{ grp_fu_531_p_din0 sc_out sc_lv 64 signal -1 } 
	{ grp_fu_531_p_din1 sc_out sc_lv 66 signal -1 } 
	{ grp_fu_531_p_dout0 sc_in sc_lv 129 signal -1 } 
	{ grp_fu_531_p_ce sc_out sc_logic 1 signal -1 } 
	{ grp_fu_535_p_din0 sc_out sc_lv 64 signal -1 } 
	{ grp_fu_535_p_din1 sc_out sc_lv 66 signal -1 } 
	{ grp_fu_535_p_dout0 sc_in sc_lv 129 signal -1 } 
	{ grp_fu_535_p_ce sc_out sc_logic 1 signal -1 } 
}
set NewPortList {[ 
	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst", "role": "default" }} , 
 	{ "name": "ap_start", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "start", "bundle":{"name": "ap_start", "role": "default" }} , 
 	{ "name": "ap_done", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "predone", "bundle":{"name": "ap_done", "role": "default" }} , 
 	{ "name": "ap_idle", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "done", "bundle":{"name": "ap_idle", "role": "default" }} , 
 	{ "name": "ap_ready", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "ready", "bundle":{"name": "ap_ready", "role": "default" }} , 
 	{ "name": "x_in_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in", "role": "address0" }} , 
 	{ "name": "x_in_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in", "role": "ce0" }} , 
 	{ "name": "x_in_q0", "direction": "in", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in", "role": "q0" }} , 
 	{ "name": "x_in_1_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_1", "role": "address0" }} , 
 	{ "name": "x_in_1_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_1", "role": "ce0" }} , 
 	{ "name": "x_in_1_q0", "direction": "in", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_1", "role": "q0" }} , 
 	{ "name": "x_in_2_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_2", "role": "address0" }} , 
 	{ "name": "x_in_2_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_2", "role": "ce0" }} , 
 	{ "name": "x_in_2_q0", "direction": "in", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_2", "role": "q0" }} , 
 	{ "name": "x_in_3_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_3", "role": "address0" }} , 
 	{ "name": "x_in_3_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_3", "role": "ce0" }} , 
 	{ "name": "x_in_3_q0", "direction": "in", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_3", "role": "q0" }} , 
 	{ "name": "x_in_4_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_4", "role": "address0" }} , 
 	{ "name": "x_in_4_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_4", "role": "ce0" }} , 
 	{ "name": "x_in_4_q0", "direction": "in", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_4", "role": "q0" }} , 
 	{ "name": "x_in_5_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_5", "role": "address0" }} , 
 	{ "name": "x_in_5_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_5", "role": "ce0" }} , 
 	{ "name": "x_in_5_q0", "direction": "in", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_5", "role": "q0" }} , 
 	{ "name": "x_in_6_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_6", "role": "address0" }} , 
 	{ "name": "x_in_6_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_6", "role": "ce0" }} , 
 	{ "name": "x_in_6_q0", "direction": "in", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_6", "role": "q0" }} , 
 	{ "name": "x_in_7_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_7", "role": "address0" }} , 
 	{ "name": "x_in_7_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_7", "role": "ce0" }} , 
 	{ "name": "x_in_7_q0", "direction": "in", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_7", "role": "q0" }} , 
 	{ "name": "x_in_8_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_8", "role": "address0" }} , 
 	{ "name": "x_in_8_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_8", "role": "ce0" }} , 
 	{ "name": "x_in_8_q0", "direction": "in", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_8", "role": "q0" }} , 
 	{ "name": "c1_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":11, "type": "signal", "bundle":{"name": "c1", "role": "address0" }} , 
 	{ "name": "c1_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "c1", "role": "ce0" }} , 
 	{ "name": "c1_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "c1", "role": "we0" }} , 
 	{ "name": "c1_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "c1", "role": "d0" }} , 
 	{ "name": "c1_1_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":11, "type": "signal", "bundle":{"name": "c1_1", "role": "address0" }} , 
 	{ "name": "c1_1_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "c1_1", "role": "ce0" }} , 
 	{ "name": "c1_1_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "c1_1", "role": "we0" }} , 
 	{ "name": "c1_1_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "c1_1", "role": "d0" }} , 
 	{ "name": "grp_fu_531_p_din0", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "grp_fu_531_p_din0", "role": "default" }} , 
 	{ "name": "grp_fu_531_p_din1", "direction": "out", "datatype": "sc_lv", "bitwidth":66, "type": "signal", "bundle":{"name": "grp_fu_531_p_din1", "role": "default" }} , 
 	{ "name": "grp_fu_531_p_dout0", "direction": "in", "datatype": "sc_lv", "bitwidth":129, "type": "signal", "bundle":{"name": "grp_fu_531_p_dout0", "role": "default" }} , 
 	{ "name": "grp_fu_531_p_ce", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "grp_fu_531_p_ce", "role": "default" }} , 
 	{ "name": "grp_fu_535_p_din0", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "grp_fu_535_p_din0", "role": "default" }} , 
 	{ "name": "grp_fu_535_p_din1", "direction": "out", "datatype": "sc_lv", "bitwidth":66, "type": "signal", "bundle":{"name": "grp_fu_535_p_din1", "role": "default" }} , 
 	{ "name": "grp_fu_535_p_dout0", "direction": "in", "datatype": "sc_lv", "bitwidth":129, "type": "signal", "bundle":{"name": "grp_fu_535_p_dout0", "role": "default" }} , 
 	{ "name": "grp_fu_535_p_ce", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "grp_fu_535_p_ce", "role": "default" }}  ]}

set ArgLastReadFirstWriteLatency {
	shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5 {
		x_in {Type I LastRead 12 FirstWrite -1}
		x_in_1 {Type I LastRead 12 FirstWrite -1}
		x_in_2 {Type I LastRead 12 FirstWrite -1}
		x_in_3 {Type I LastRead 12 FirstWrite -1}
		x_in_4 {Type I LastRead 12 FirstWrite -1}
		x_in_5 {Type I LastRead 12 FirstWrite -1}
		x_in_6 {Type I LastRead 12 FirstWrite -1}
		x_in_7 {Type I LastRead 12 FirstWrite -1}
		x_in_8 {Type I LastRead 12 FirstWrite -1}
		c1 {Type O LastRead -1 FirstWrite 24}
		c1_1 {Type O LastRead -1 FirstWrite 24}
		p_ZL7W_CONV1_4 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_0 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_1 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_2 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_3 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_5 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_6 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_7 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_8 {Type I LastRead -1 FirstWrite -1}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "4121", "Max" : "4121"}
	, {"Name" : "Interval", "Min" : "4097", "Max" : "4097"}
]}

set PipelineEnableSignalInfo {[
	{"Pipeline" : "0", "EnableSignal" : "ap_enable_pp0"}
]}

set Spec2ImplPortList { 
	x_in { ap_memory {  { x_in_address0 mem_address 1 7 }  { x_in_ce0 mem_ce 1 1 }  { x_in_q0 mem_dout 0 13 } } }
	x_in_1 { ap_memory {  { x_in_1_address0 mem_address 1 7 }  { x_in_1_ce0 mem_ce 1 1 }  { x_in_1_q0 mem_dout 0 13 } } }
	x_in_2 { ap_memory {  { x_in_2_address0 mem_address 1 7 }  { x_in_2_ce0 mem_ce 1 1 }  { x_in_2_q0 mem_dout 0 13 } } }
	x_in_3 { ap_memory {  { x_in_3_address0 mem_address 1 7 }  { x_in_3_ce0 mem_ce 1 1 }  { x_in_3_q0 mem_dout 0 13 } } }
	x_in_4 { ap_memory {  { x_in_4_address0 mem_address 1 7 }  { x_in_4_ce0 mem_ce 1 1 }  { x_in_4_q0 mem_dout 0 13 } } }
	x_in_5 { ap_memory {  { x_in_5_address0 mem_address 1 7 }  { x_in_5_ce0 mem_ce 1 1 }  { x_in_5_q0 mem_dout 0 13 } } }
	x_in_6 { ap_memory {  { x_in_6_address0 mem_address 1 7 }  { x_in_6_ce0 mem_ce 1 1 }  { x_in_6_q0 mem_dout 0 13 } } }
	x_in_7 { ap_memory {  { x_in_7_address0 mem_address 1 7 }  { x_in_7_ce0 mem_ce 1 1 }  { x_in_7_q0 mem_dout 0 13 } } }
	x_in_8 { ap_memory {  { x_in_8_address0 mem_address 1 7 }  { x_in_8_ce0 mem_ce 1 1 }  { x_in_8_q0 mem_dout 0 13 } } }
	c1 { ap_memory {  { c1_address0 mem_address 1 11 }  { c1_ce0 mem_ce 1 1 }  { c1_we0 mem_we 1 1 }  { c1_d0 mem_din 1 13 } } }
	c1_1 { ap_memory {  { c1_1_address0 mem_address 1 11 }  { c1_1_ce0 mem_ce 1 1 }  { c1_1_we0 mem_we 1 1 }  { c1_1_d0 mem_din 1 13 } } }
}
