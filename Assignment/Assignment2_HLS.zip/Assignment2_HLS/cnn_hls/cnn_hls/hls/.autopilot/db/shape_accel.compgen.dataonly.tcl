# This script segment is generated automatically by AutoPilot

set axilite_register_dict [dict create]
set port_CTRL {
scores { 
	dir O
	width 32
	depth 4
	mode ap_memory
	offset 16
	offset_end 31
	direct_io 0
	core_op ram_1p
	core_impl auto
	core_latency 1
	byte_write 0
}
pred_class { 
	dir O
	width 32
	depth 1
	mode ap_vld
	offset 32
	offset_end 39
	direct_io 0
}
img { 
	dir I
	width 8
	depth 1024
	mode ap_memory
	offset 1024
	offset_end 2047
	direct_io 0
	core_op ram_1p
	core_impl auto
	core_latency 1
	byte_write 0
}
ap_start { }
ap_done { }
ap_ready { }
ap_idle { }
interrupt {
}
}
dict set axilite_register_dict CTRL $port_CTRL


