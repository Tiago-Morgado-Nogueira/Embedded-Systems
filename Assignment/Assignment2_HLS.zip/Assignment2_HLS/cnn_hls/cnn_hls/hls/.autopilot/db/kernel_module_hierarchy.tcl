set ModuleHierarchy {[{
"Name" : "shape_accel", "RefName" : "shape_accel","ID" : "0","Type" : "sequential",
"SubInsts" : [
	{"Name" : "grp_shape_accel_Pipeline_VITIS_LOOP_21_1_VITIS_LOOP_22_2_fu_327", "RefName" : "shape_accel_Pipeline_VITIS_LOOP_21_1_VITIS_LOOP_22_2","ID" : "1","Type" : "sequential",
		"SubLoops" : [
		{"Name" : "VITIS_LOOP_21_1_VITIS_LOOP_22_2","RefName" : "VITIS_LOOP_21_1_VITIS_LOOP_22_2","ID" : "2","Type" : "pipeline"},]},
	{"Name" : "grp_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_fu_351", "RefName" : "shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5","ID" : "3","Type" : "sequential",
		"SubLoops" : [
		{"Name" : "VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5","RefName" : "VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5","ID" : "4","Type" : "pipeline"},]},
	{"Name" : "grp_shape_accel_Pipeline_VITIS_LOOP_51_8_VITIS_LOOP_52_9_VITIS_LOOP_53_10_fu_384", "RefName" : "shape_accel_Pipeline_VITIS_LOOP_51_8_VITIS_LOOP_52_9_VITIS_LOOP_53_10","ID" : "5","Type" : "sequential",
		"SubLoops" : [
		{"Name" : "VITIS_LOOP_51_8_VITIS_LOOP_52_9_VITIS_LOOP_53_10","RefName" : "VITIS_LOOP_51_8_VITIS_LOOP_52_9_VITIS_LOOP_53_10","ID" : "6","Type" : "pipeline"},]},
	{"Name" : "grp_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_fu_426", "RefName" : "shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13","ID" : "7","Type" : "sequential",
		"SubLoops" : [
		{"Name" : "VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13","RefName" : "VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13","ID" : "8","Type" : "pipeline"},]},
	{"Name" : "grp_shape_accel_Pipeline_VITIS_LOOP_87_17_VITIS_LOOP_88_18_VITIS_LOOP_89_19_fu_504", "RefName" : "shape_accel_Pipeline_VITIS_LOOP_87_17_VITIS_LOOP_88_18_VITIS_LOOP_89_19","ID" : "9","Type" : "sequential",
		"SubLoops" : [
		{"Name" : "VITIS_LOOP_87_17_VITIS_LOOP_88_18_VITIS_LOOP_89_19","RefName" : "VITIS_LOOP_87_17_VITIS_LOOP_88_18_VITIS_LOOP_89_19","ID" : "10","Type" : "pipeline"},]},
	{"Name" : "grp_shape_accel_Pipeline_VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VITIS_fu_511", "RefName" : "shape_accel_Pipeline_VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VITIS","ID" : "11","Type" : "sequential",
		"SubLoops" : [
		{"Name" : "VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VITIS_LOOP_106_23","RefName" : "VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VITIS_LOOP_106_23","ID" : "12","Type" : "pipeline"},]},]
}]}