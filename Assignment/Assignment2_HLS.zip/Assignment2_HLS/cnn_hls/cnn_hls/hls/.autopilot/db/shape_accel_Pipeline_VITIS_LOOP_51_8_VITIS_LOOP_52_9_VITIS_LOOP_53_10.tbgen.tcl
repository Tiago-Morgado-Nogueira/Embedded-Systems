set moduleName shape_accel_Pipeline_VITIS_LOOP_51_8_VITIS_LOOP_52_9_VITIS_LOOP_53_10
set isTopModule 0
set isCombinational 0
set isDatapathOnly 0
set isPipelined 1
set isPipelined_legacy 1
set pipeline_type loop_auto_rewind
set FunctionProtocol ap_ctrl_hs
set restart_counter_num 0
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set hasInterrupt 0
set DLRegFirstOffset 0
set DLRegItemOffset 0
set svuvm_can_support 1
set cdfgNum 9
set C_modelName {shape_accel_Pipeline_VITIS_LOOP_51_8_VITIS_LOOP_52_9_VITIS_LOOP_53_10}
set C_modelType { void 0 }
set ap_memory_interface_dict [dict create]
dict set ap_memory_interface_dict c1 { MEM_WIDTH 13 MEM_SIZE 4096 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
dict set ap_memory_interface_dict c1_1 { MEM_WIDTH 13 MEM_SIZE 4096 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
dict set ap_memory_interface_dict p1 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_1 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_2 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_3 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_4 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_5 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_6 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_7 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_8 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_9 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_10 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_11 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_12 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_13 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_14 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_15 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_16 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_17 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_18 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_19 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_20 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_21 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_22 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_23 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_24 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_25 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_26 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_27 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_28 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_29 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_30 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_31 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_32 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_33 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_34 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict p1_35 { MEM_WIDTH 16 MEM_SIZE 72 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
set C_modelArgList {
	{ c1 int 13 regular {array 2048 { 1 1 } 1 1 }  }
	{ c1_1 int 13 regular {array 2048 { 1 1 } 1 1 }  }
	{ p1 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_1 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_2 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_3 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_4 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_5 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_6 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_7 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_8 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_9 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_10 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_11 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_12 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_13 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_14 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_15 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_16 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_17 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_18 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_19 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_20 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_21 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_22 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_23 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_24 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_25 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_26 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_27 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_28 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_29 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_30 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_31 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_32 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_33 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_34 int 16 regular {array 36 { 0 3 } 0 1 }  }
	{ p1_35 int 16 regular {array 36 { 0 3 } 0 1 }  }
}
set hasAXIMCache 0
set l_AXIML2Cache [list]
set AXIMCacheInstDict [dict create]
set C_modelArgMapList {[ 
	{ "Name" : "c1", "interface" : "memory", "bitwidth" : 13, "direction" : "READONLY"} , 
 	{ "Name" : "c1_1", "interface" : "memory", "bitwidth" : 13, "direction" : "READONLY"} , 
 	{ "Name" : "p1", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_1", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_2", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_3", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_4", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_5", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_6", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_7", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_8", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_9", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_10", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_11", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_12", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_13", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_14", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_15", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_16", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_17", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_18", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_19", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_20", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_21", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_22", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_23", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_24", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_25", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_26", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_27", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_28", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_29", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_30", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_31", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_32", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_33", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_34", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} , 
 	{ "Name" : "p1_35", "interface" : "memory", "bitwidth" : 16, "direction" : "WRITEONLY"} ]}
# RTL Port declarations: 
set portNum 162
set portList { 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst sc_in sc_logic 1 reset -1 active_high_sync } 
	{ ap_start sc_in sc_logic 1 start -1 } 
	{ ap_done sc_out sc_logic 1 predone -1 } 
	{ ap_idle sc_out sc_logic 1 done -1 } 
	{ ap_ready sc_out sc_logic 1 ready -1 } 
	{ c1_address0 sc_out sc_lv 11 signal 0 } 
	{ c1_ce0 sc_out sc_logic 1 signal 0 } 
	{ c1_q0 sc_in sc_lv 13 signal 0 } 
	{ c1_address1 sc_out sc_lv 11 signal 0 } 
	{ c1_ce1 sc_out sc_logic 1 signal 0 } 
	{ c1_q1 sc_in sc_lv 13 signal 0 } 
	{ c1_1_address0 sc_out sc_lv 11 signal 1 } 
	{ c1_1_ce0 sc_out sc_logic 1 signal 1 } 
	{ c1_1_q0 sc_in sc_lv 13 signal 1 } 
	{ c1_1_address1 sc_out sc_lv 11 signal 1 } 
	{ c1_1_ce1 sc_out sc_logic 1 signal 1 } 
	{ c1_1_q1 sc_in sc_lv 13 signal 1 } 
	{ p1_address0 sc_out sc_lv 6 signal 2 } 
	{ p1_ce0 sc_out sc_logic 1 signal 2 } 
	{ p1_we0 sc_out sc_logic 1 signal 2 } 
	{ p1_d0 sc_out sc_lv 16 signal 2 } 
	{ p1_1_address0 sc_out sc_lv 6 signal 3 } 
	{ p1_1_ce0 sc_out sc_logic 1 signal 3 } 
	{ p1_1_we0 sc_out sc_logic 1 signal 3 } 
	{ p1_1_d0 sc_out sc_lv 16 signal 3 } 
	{ p1_2_address0 sc_out sc_lv 6 signal 4 } 
	{ p1_2_ce0 sc_out sc_logic 1 signal 4 } 
	{ p1_2_we0 sc_out sc_logic 1 signal 4 } 
	{ p1_2_d0 sc_out sc_lv 16 signal 4 } 
	{ p1_3_address0 sc_out sc_lv 6 signal 5 } 
	{ p1_3_ce0 sc_out sc_logic 1 signal 5 } 
	{ p1_3_we0 sc_out sc_logic 1 signal 5 } 
	{ p1_3_d0 sc_out sc_lv 16 signal 5 } 
	{ p1_4_address0 sc_out sc_lv 6 signal 6 } 
	{ p1_4_ce0 sc_out sc_logic 1 signal 6 } 
	{ p1_4_we0 sc_out sc_logic 1 signal 6 } 
	{ p1_4_d0 sc_out sc_lv 16 signal 6 } 
	{ p1_5_address0 sc_out sc_lv 6 signal 7 } 
	{ p1_5_ce0 sc_out sc_logic 1 signal 7 } 
	{ p1_5_we0 sc_out sc_logic 1 signal 7 } 
	{ p1_5_d0 sc_out sc_lv 16 signal 7 } 
	{ p1_6_address0 sc_out sc_lv 6 signal 8 } 
	{ p1_6_ce0 sc_out sc_logic 1 signal 8 } 
	{ p1_6_we0 sc_out sc_logic 1 signal 8 } 
	{ p1_6_d0 sc_out sc_lv 16 signal 8 } 
	{ p1_7_address0 sc_out sc_lv 6 signal 9 } 
	{ p1_7_ce0 sc_out sc_logic 1 signal 9 } 
	{ p1_7_we0 sc_out sc_logic 1 signal 9 } 
	{ p1_7_d0 sc_out sc_lv 16 signal 9 } 
	{ p1_8_address0 sc_out sc_lv 6 signal 10 } 
	{ p1_8_ce0 sc_out sc_logic 1 signal 10 } 
	{ p1_8_we0 sc_out sc_logic 1 signal 10 } 
	{ p1_8_d0 sc_out sc_lv 16 signal 10 } 
	{ p1_9_address0 sc_out sc_lv 6 signal 11 } 
	{ p1_9_ce0 sc_out sc_logic 1 signal 11 } 
	{ p1_9_we0 sc_out sc_logic 1 signal 11 } 
	{ p1_9_d0 sc_out sc_lv 16 signal 11 } 
	{ p1_10_address0 sc_out sc_lv 6 signal 12 } 
	{ p1_10_ce0 sc_out sc_logic 1 signal 12 } 
	{ p1_10_we0 sc_out sc_logic 1 signal 12 } 
	{ p1_10_d0 sc_out sc_lv 16 signal 12 } 
	{ p1_11_address0 sc_out sc_lv 6 signal 13 } 
	{ p1_11_ce0 sc_out sc_logic 1 signal 13 } 
	{ p1_11_we0 sc_out sc_logic 1 signal 13 } 
	{ p1_11_d0 sc_out sc_lv 16 signal 13 } 
	{ p1_12_address0 sc_out sc_lv 6 signal 14 } 
	{ p1_12_ce0 sc_out sc_logic 1 signal 14 } 
	{ p1_12_we0 sc_out sc_logic 1 signal 14 } 
	{ p1_12_d0 sc_out sc_lv 16 signal 14 } 
	{ p1_13_address0 sc_out sc_lv 6 signal 15 } 
	{ p1_13_ce0 sc_out sc_logic 1 signal 15 } 
	{ p1_13_we0 sc_out sc_logic 1 signal 15 } 
	{ p1_13_d0 sc_out sc_lv 16 signal 15 } 
	{ p1_14_address0 sc_out sc_lv 6 signal 16 } 
	{ p1_14_ce0 sc_out sc_logic 1 signal 16 } 
	{ p1_14_we0 sc_out sc_logic 1 signal 16 } 
	{ p1_14_d0 sc_out sc_lv 16 signal 16 } 
	{ p1_15_address0 sc_out sc_lv 6 signal 17 } 
	{ p1_15_ce0 sc_out sc_logic 1 signal 17 } 
	{ p1_15_we0 sc_out sc_logic 1 signal 17 } 
	{ p1_15_d0 sc_out sc_lv 16 signal 17 } 
	{ p1_16_address0 sc_out sc_lv 6 signal 18 } 
	{ p1_16_ce0 sc_out sc_logic 1 signal 18 } 
	{ p1_16_we0 sc_out sc_logic 1 signal 18 } 
	{ p1_16_d0 sc_out sc_lv 16 signal 18 } 
	{ p1_17_address0 sc_out sc_lv 6 signal 19 } 
	{ p1_17_ce0 sc_out sc_logic 1 signal 19 } 
	{ p1_17_we0 sc_out sc_logic 1 signal 19 } 
	{ p1_17_d0 sc_out sc_lv 16 signal 19 } 
	{ p1_18_address0 sc_out sc_lv 6 signal 20 } 
	{ p1_18_ce0 sc_out sc_logic 1 signal 20 } 
	{ p1_18_we0 sc_out sc_logic 1 signal 20 } 
	{ p1_18_d0 sc_out sc_lv 16 signal 20 } 
	{ p1_19_address0 sc_out sc_lv 6 signal 21 } 
	{ p1_19_ce0 sc_out sc_logic 1 signal 21 } 
	{ p1_19_we0 sc_out sc_logic 1 signal 21 } 
	{ p1_19_d0 sc_out sc_lv 16 signal 21 } 
	{ p1_20_address0 sc_out sc_lv 6 signal 22 } 
	{ p1_20_ce0 sc_out sc_logic 1 signal 22 } 
	{ p1_20_we0 sc_out sc_logic 1 signal 22 } 
	{ p1_20_d0 sc_out sc_lv 16 signal 22 } 
	{ p1_21_address0 sc_out sc_lv 6 signal 23 } 
	{ p1_21_ce0 sc_out sc_logic 1 signal 23 } 
	{ p1_21_we0 sc_out sc_logic 1 signal 23 } 
	{ p1_21_d0 sc_out sc_lv 16 signal 23 } 
	{ p1_22_address0 sc_out sc_lv 6 signal 24 } 
	{ p1_22_ce0 sc_out sc_logic 1 signal 24 } 
	{ p1_22_we0 sc_out sc_logic 1 signal 24 } 
	{ p1_22_d0 sc_out sc_lv 16 signal 24 } 
	{ p1_23_address0 sc_out sc_lv 6 signal 25 } 
	{ p1_23_ce0 sc_out sc_logic 1 signal 25 } 
	{ p1_23_we0 sc_out sc_logic 1 signal 25 } 
	{ p1_23_d0 sc_out sc_lv 16 signal 25 } 
	{ p1_24_address0 sc_out sc_lv 6 signal 26 } 
	{ p1_24_ce0 sc_out sc_logic 1 signal 26 } 
	{ p1_24_we0 sc_out sc_logic 1 signal 26 } 
	{ p1_24_d0 sc_out sc_lv 16 signal 26 } 
	{ p1_25_address0 sc_out sc_lv 6 signal 27 } 
	{ p1_25_ce0 sc_out sc_logic 1 signal 27 } 
	{ p1_25_we0 sc_out sc_logic 1 signal 27 } 
	{ p1_25_d0 sc_out sc_lv 16 signal 27 } 
	{ p1_26_address0 sc_out sc_lv 6 signal 28 } 
	{ p1_26_ce0 sc_out sc_logic 1 signal 28 } 
	{ p1_26_we0 sc_out sc_logic 1 signal 28 } 
	{ p1_26_d0 sc_out sc_lv 16 signal 28 } 
	{ p1_27_address0 sc_out sc_lv 6 signal 29 } 
	{ p1_27_ce0 sc_out sc_logic 1 signal 29 } 
	{ p1_27_we0 sc_out sc_logic 1 signal 29 } 
	{ p1_27_d0 sc_out sc_lv 16 signal 29 } 
	{ p1_28_address0 sc_out sc_lv 6 signal 30 } 
	{ p1_28_ce0 sc_out sc_logic 1 signal 30 } 
	{ p1_28_we0 sc_out sc_logic 1 signal 30 } 
	{ p1_28_d0 sc_out sc_lv 16 signal 30 } 
	{ p1_29_address0 sc_out sc_lv 6 signal 31 } 
	{ p1_29_ce0 sc_out sc_logic 1 signal 31 } 
	{ p1_29_we0 sc_out sc_logic 1 signal 31 } 
	{ p1_29_d0 sc_out sc_lv 16 signal 31 } 
	{ p1_30_address0 sc_out sc_lv 6 signal 32 } 
	{ p1_30_ce0 sc_out sc_logic 1 signal 32 } 
	{ p1_30_we0 sc_out sc_logic 1 signal 32 } 
	{ p1_30_d0 sc_out sc_lv 16 signal 32 } 
	{ p1_31_address0 sc_out sc_lv 6 signal 33 } 
	{ p1_31_ce0 sc_out sc_logic 1 signal 33 } 
	{ p1_31_we0 sc_out sc_logic 1 signal 33 } 
	{ p1_31_d0 sc_out sc_lv 16 signal 33 } 
	{ p1_32_address0 sc_out sc_lv 6 signal 34 } 
	{ p1_32_ce0 sc_out sc_logic 1 signal 34 } 
	{ p1_32_we0 sc_out sc_logic 1 signal 34 } 
	{ p1_32_d0 sc_out sc_lv 16 signal 34 } 
	{ p1_33_address0 sc_out sc_lv 6 signal 35 } 
	{ p1_33_ce0 sc_out sc_logic 1 signal 35 } 
	{ p1_33_we0 sc_out sc_logic 1 signal 35 } 
	{ p1_33_d0 sc_out sc_lv 16 signal 35 } 
	{ p1_34_address0 sc_out sc_lv 6 signal 36 } 
	{ p1_34_ce0 sc_out sc_logic 1 signal 36 } 
	{ p1_34_we0 sc_out sc_logic 1 signal 36 } 
	{ p1_34_d0 sc_out sc_lv 16 signal 36 } 
	{ p1_35_address0 sc_out sc_lv 6 signal 37 } 
	{ p1_35_ce0 sc_out sc_logic 1 signal 37 } 
	{ p1_35_we0 sc_out sc_logic 1 signal 37 } 
	{ p1_35_d0 sc_out sc_lv 16 signal 37 } 
}
set NewPortList {[ 
	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst", "role": "default" }} , 
 	{ "name": "ap_start", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "start", "bundle":{"name": "ap_start", "role": "default" }} , 
 	{ "name": "ap_done", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "predone", "bundle":{"name": "ap_done", "role": "default" }} , 
 	{ "name": "ap_idle", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "done", "bundle":{"name": "ap_idle", "role": "default" }} , 
 	{ "name": "ap_ready", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "ready", "bundle":{"name": "ap_ready", "role": "default" }} , 
 	{ "name": "c1_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":11, "type": "signal", "bundle":{"name": "c1", "role": "address0" }} , 
 	{ "name": "c1_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "c1", "role": "ce0" }} , 
 	{ "name": "c1_q0", "direction": "in", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "c1", "role": "q0" }} , 
 	{ "name": "c1_address1", "direction": "out", "datatype": "sc_lv", "bitwidth":11, "type": "signal", "bundle":{"name": "c1", "role": "address1" }} , 
 	{ "name": "c1_ce1", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "c1", "role": "ce1" }} , 
 	{ "name": "c1_q1", "direction": "in", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "c1", "role": "q1" }} , 
 	{ "name": "c1_1_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":11, "type": "signal", "bundle":{"name": "c1_1", "role": "address0" }} , 
 	{ "name": "c1_1_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "c1_1", "role": "ce0" }} , 
 	{ "name": "c1_1_q0", "direction": "in", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "c1_1", "role": "q0" }} , 
 	{ "name": "c1_1_address1", "direction": "out", "datatype": "sc_lv", "bitwidth":11, "type": "signal", "bundle":{"name": "c1_1", "role": "address1" }} , 
 	{ "name": "c1_1_ce1", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "c1_1", "role": "ce1" }} , 
 	{ "name": "c1_1_q1", "direction": "in", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "c1_1", "role": "q1" }} , 
 	{ "name": "p1_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1", "role": "address0" }} , 
 	{ "name": "p1_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1", "role": "ce0" }} , 
 	{ "name": "p1_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1", "role": "we0" }} , 
 	{ "name": "p1_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1", "role": "d0" }} , 
 	{ "name": "p1_1_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_1", "role": "address0" }} , 
 	{ "name": "p1_1_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_1", "role": "ce0" }} , 
 	{ "name": "p1_1_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_1", "role": "we0" }} , 
 	{ "name": "p1_1_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_1", "role": "d0" }} , 
 	{ "name": "p1_2_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_2", "role": "address0" }} , 
 	{ "name": "p1_2_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_2", "role": "ce0" }} , 
 	{ "name": "p1_2_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_2", "role": "we0" }} , 
 	{ "name": "p1_2_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_2", "role": "d0" }} , 
 	{ "name": "p1_3_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_3", "role": "address0" }} , 
 	{ "name": "p1_3_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_3", "role": "ce0" }} , 
 	{ "name": "p1_3_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_3", "role": "we0" }} , 
 	{ "name": "p1_3_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_3", "role": "d0" }} , 
 	{ "name": "p1_4_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_4", "role": "address0" }} , 
 	{ "name": "p1_4_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_4", "role": "ce0" }} , 
 	{ "name": "p1_4_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_4", "role": "we0" }} , 
 	{ "name": "p1_4_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_4", "role": "d0" }} , 
 	{ "name": "p1_5_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_5", "role": "address0" }} , 
 	{ "name": "p1_5_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_5", "role": "ce0" }} , 
 	{ "name": "p1_5_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_5", "role": "we0" }} , 
 	{ "name": "p1_5_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_5", "role": "d0" }} , 
 	{ "name": "p1_6_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_6", "role": "address0" }} , 
 	{ "name": "p1_6_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_6", "role": "ce0" }} , 
 	{ "name": "p1_6_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_6", "role": "we0" }} , 
 	{ "name": "p1_6_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_6", "role": "d0" }} , 
 	{ "name": "p1_7_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_7", "role": "address0" }} , 
 	{ "name": "p1_7_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_7", "role": "ce0" }} , 
 	{ "name": "p1_7_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_7", "role": "we0" }} , 
 	{ "name": "p1_7_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_7", "role": "d0" }} , 
 	{ "name": "p1_8_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_8", "role": "address0" }} , 
 	{ "name": "p1_8_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_8", "role": "ce0" }} , 
 	{ "name": "p1_8_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_8", "role": "we0" }} , 
 	{ "name": "p1_8_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_8", "role": "d0" }} , 
 	{ "name": "p1_9_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_9", "role": "address0" }} , 
 	{ "name": "p1_9_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_9", "role": "ce0" }} , 
 	{ "name": "p1_9_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_9", "role": "we0" }} , 
 	{ "name": "p1_9_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_9", "role": "d0" }} , 
 	{ "name": "p1_10_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_10", "role": "address0" }} , 
 	{ "name": "p1_10_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_10", "role": "ce0" }} , 
 	{ "name": "p1_10_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_10", "role": "we0" }} , 
 	{ "name": "p1_10_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_10", "role": "d0" }} , 
 	{ "name": "p1_11_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_11", "role": "address0" }} , 
 	{ "name": "p1_11_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_11", "role": "ce0" }} , 
 	{ "name": "p1_11_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_11", "role": "we0" }} , 
 	{ "name": "p1_11_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_11", "role": "d0" }} , 
 	{ "name": "p1_12_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_12", "role": "address0" }} , 
 	{ "name": "p1_12_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_12", "role": "ce0" }} , 
 	{ "name": "p1_12_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_12", "role": "we0" }} , 
 	{ "name": "p1_12_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_12", "role": "d0" }} , 
 	{ "name": "p1_13_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_13", "role": "address0" }} , 
 	{ "name": "p1_13_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_13", "role": "ce0" }} , 
 	{ "name": "p1_13_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_13", "role": "we0" }} , 
 	{ "name": "p1_13_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_13", "role": "d0" }} , 
 	{ "name": "p1_14_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_14", "role": "address0" }} , 
 	{ "name": "p1_14_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_14", "role": "ce0" }} , 
 	{ "name": "p1_14_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_14", "role": "we0" }} , 
 	{ "name": "p1_14_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_14", "role": "d0" }} , 
 	{ "name": "p1_15_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_15", "role": "address0" }} , 
 	{ "name": "p1_15_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_15", "role": "ce0" }} , 
 	{ "name": "p1_15_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_15", "role": "we0" }} , 
 	{ "name": "p1_15_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_15", "role": "d0" }} , 
 	{ "name": "p1_16_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_16", "role": "address0" }} , 
 	{ "name": "p1_16_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_16", "role": "ce0" }} , 
 	{ "name": "p1_16_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_16", "role": "we0" }} , 
 	{ "name": "p1_16_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_16", "role": "d0" }} , 
 	{ "name": "p1_17_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_17", "role": "address0" }} , 
 	{ "name": "p1_17_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_17", "role": "ce0" }} , 
 	{ "name": "p1_17_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_17", "role": "we0" }} , 
 	{ "name": "p1_17_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_17", "role": "d0" }} , 
 	{ "name": "p1_18_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_18", "role": "address0" }} , 
 	{ "name": "p1_18_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_18", "role": "ce0" }} , 
 	{ "name": "p1_18_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_18", "role": "we0" }} , 
 	{ "name": "p1_18_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_18", "role": "d0" }} , 
 	{ "name": "p1_19_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_19", "role": "address0" }} , 
 	{ "name": "p1_19_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_19", "role": "ce0" }} , 
 	{ "name": "p1_19_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_19", "role": "we0" }} , 
 	{ "name": "p1_19_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_19", "role": "d0" }} , 
 	{ "name": "p1_20_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_20", "role": "address0" }} , 
 	{ "name": "p1_20_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_20", "role": "ce0" }} , 
 	{ "name": "p1_20_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_20", "role": "we0" }} , 
 	{ "name": "p1_20_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_20", "role": "d0" }} , 
 	{ "name": "p1_21_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_21", "role": "address0" }} , 
 	{ "name": "p1_21_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_21", "role": "ce0" }} , 
 	{ "name": "p1_21_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_21", "role": "we0" }} , 
 	{ "name": "p1_21_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_21", "role": "d0" }} , 
 	{ "name": "p1_22_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_22", "role": "address0" }} , 
 	{ "name": "p1_22_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_22", "role": "ce0" }} , 
 	{ "name": "p1_22_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_22", "role": "we0" }} , 
 	{ "name": "p1_22_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_22", "role": "d0" }} , 
 	{ "name": "p1_23_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_23", "role": "address0" }} , 
 	{ "name": "p1_23_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_23", "role": "ce0" }} , 
 	{ "name": "p1_23_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_23", "role": "we0" }} , 
 	{ "name": "p1_23_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_23", "role": "d0" }} , 
 	{ "name": "p1_24_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_24", "role": "address0" }} , 
 	{ "name": "p1_24_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_24", "role": "ce0" }} , 
 	{ "name": "p1_24_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_24", "role": "we0" }} , 
 	{ "name": "p1_24_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_24", "role": "d0" }} , 
 	{ "name": "p1_25_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_25", "role": "address0" }} , 
 	{ "name": "p1_25_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_25", "role": "ce0" }} , 
 	{ "name": "p1_25_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_25", "role": "we0" }} , 
 	{ "name": "p1_25_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_25", "role": "d0" }} , 
 	{ "name": "p1_26_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_26", "role": "address0" }} , 
 	{ "name": "p1_26_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_26", "role": "ce0" }} , 
 	{ "name": "p1_26_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_26", "role": "we0" }} , 
 	{ "name": "p1_26_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_26", "role": "d0" }} , 
 	{ "name": "p1_27_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_27", "role": "address0" }} , 
 	{ "name": "p1_27_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_27", "role": "ce0" }} , 
 	{ "name": "p1_27_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_27", "role": "we0" }} , 
 	{ "name": "p1_27_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_27", "role": "d0" }} , 
 	{ "name": "p1_28_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_28", "role": "address0" }} , 
 	{ "name": "p1_28_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_28", "role": "ce0" }} , 
 	{ "name": "p1_28_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_28", "role": "we0" }} , 
 	{ "name": "p1_28_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_28", "role": "d0" }} , 
 	{ "name": "p1_29_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_29", "role": "address0" }} , 
 	{ "name": "p1_29_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_29", "role": "ce0" }} , 
 	{ "name": "p1_29_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_29", "role": "we0" }} , 
 	{ "name": "p1_29_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_29", "role": "d0" }} , 
 	{ "name": "p1_30_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_30", "role": "address0" }} , 
 	{ "name": "p1_30_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_30", "role": "ce0" }} , 
 	{ "name": "p1_30_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_30", "role": "we0" }} , 
 	{ "name": "p1_30_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_30", "role": "d0" }} , 
 	{ "name": "p1_31_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_31", "role": "address0" }} , 
 	{ "name": "p1_31_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_31", "role": "ce0" }} , 
 	{ "name": "p1_31_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_31", "role": "we0" }} , 
 	{ "name": "p1_31_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_31", "role": "d0" }} , 
 	{ "name": "p1_32_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_32", "role": "address0" }} , 
 	{ "name": "p1_32_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_32", "role": "ce0" }} , 
 	{ "name": "p1_32_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_32", "role": "we0" }} , 
 	{ "name": "p1_32_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_32", "role": "d0" }} , 
 	{ "name": "p1_33_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_33", "role": "address0" }} , 
 	{ "name": "p1_33_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_33", "role": "ce0" }} , 
 	{ "name": "p1_33_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_33", "role": "we0" }} , 
 	{ "name": "p1_33_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_33", "role": "d0" }} , 
 	{ "name": "p1_34_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_34", "role": "address0" }} , 
 	{ "name": "p1_34_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_34", "role": "ce0" }} , 
 	{ "name": "p1_34_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_34", "role": "we0" }} , 
 	{ "name": "p1_34_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_34", "role": "d0" }} , 
 	{ "name": "p1_35_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "p1_35", "role": "address0" }} , 
 	{ "name": "p1_35_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_35", "role": "ce0" }} , 
 	{ "name": "p1_35_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p1_35", "role": "we0" }} , 
 	{ "name": "p1_35_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p1_35", "role": "d0" }}  ]}

set ArgLastReadFirstWriteLatency {
	shape_accel_Pipeline_VITIS_LOOP_51_8_VITIS_LOOP_52_9_VITIS_LOOP_53_10 {
		c1 {Type I LastRead 9 FirstWrite -1}
		c1_1 {Type I LastRead 9 FirstWrite -1}
		p1 {Type O LastRead -1 FirstWrite 10}
		p1_1 {Type O LastRead -1 FirstWrite 10}
		p1_2 {Type O LastRead -1 FirstWrite 10}
		p1_3 {Type O LastRead -1 FirstWrite 10}
		p1_4 {Type O LastRead -1 FirstWrite 10}
		p1_5 {Type O LastRead -1 FirstWrite 10}
		p1_6 {Type O LastRead -1 FirstWrite 10}
		p1_7 {Type O LastRead -1 FirstWrite 10}
		p1_8 {Type O LastRead -1 FirstWrite 10}
		p1_9 {Type O LastRead -1 FirstWrite 10}
		p1_10 {Type O LastRead -1 FirstWrite 10}
		p1_11 {Type O LastRead -1 FirstWrite 10}
		p1_12 {Type O LastRead -1 FirstWrite 10}
		p1_13 {Type O LastRead -1 FirstWrite 10}
		p1_14 {Type O LastRead -1 FirstWrite 10}
		p1_15 {Type O LastRead -1 FirstWrite 10}
		p1_16 {Type O LastRead -1 FirstWrite 10}
		p1_17 {Type O LastRead -1 FirstWrite 10}
		p1_18 {Type O LastRead -1 FirstWrite 10}
		p1_19 {Type O LastRead -1 FirstWrite 10}
		p1_20 {Type O LastRead -1 FirstWrite 10}
		p1_21 {Type O LastRead -1 FirstWrite 10}
		p1_22 {Type O LastRead -1 FirstWrite 10}
		p1_23 {Type O LastRead -1 FirstWrite 10}
		p1_24 {Type O LastRead -1 FirstWrite 10}
		p1_25 {Type O LastRead -1 FirstWrite 10}
		p1_26 {Type O LastRead -1 FirstWrite 10}
		p1_27 {Type O LastRead -1 FirstWrite 10}
		p1_28 {Type O LastRead -1 FirstWrite 10}
		p1_29 {Type O LastRead -1 FirstWrite 10}
		p1_30 {Type O LastRead -1 FirstWrite 10}
		p1_31 {Type O LastRead -1 FirstWrite 10}
		p1_32 {Type O LastRead -1 FirstWrite 10}
		p1_33 {Type O LastRead -1 FirstWrite 10}
		p1_34 {Type O LastRead -1 FirstWrite 10}
		p1_35 {Type O LastRead -1 FirstWrite 10}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "1035", "Max" : "1035"}
	, {"Name" : "Interval", "Min" : "1025", "Max" : "1025"}
]}

set PipelineEnableSignalInfo {[
	{"Pipeline" : "0", "EnableSignal" : "ap_enable_pp0"}
]}

set Spec2ImplPortList { 
	c1 { ap_memory {  { c1_address0 mem_address 1 11 }  { c1_ce0 mem_ce 1 1 }  { c1_q0 mem_dout 0 13 }  { c1_address1 MemPortADDR2 1 11 }  { c1_ce1 MemPortCE2 1 1 }  { c1_q1 MemPortDOUT2 0 13 } } }
	c1_1 { ap_memory {  { c1_1_address0 mem_address 1 11 }  { c1_1_ce0 mem_ce 1 1 }  { c1_1_q0 mem_dout 0 13 }  { c1_1_address1 MemPortADDR2 1 11 }  { c1_1_ce1 MemPortCE2 1 1 }  { c1_1_q1 MemPortDOUT2 0 13 } } }
	p1 { ap_memory {  { p1_address0 mem_address 1 6 }  { p1_ce0 mem_ce 1 1 }  { p1_we0 mem_we 1 1 }  { p1_d0 mem_din 1 16 } } }
	p1_1 { ap_memory {  { p1_1_address0 mem_address 1 6 }  { p1_1_ce0 mem_ce 1 1 }  { p1_1_we0 mem_we 1 1 }  { p1_1_d0 mem_din 1 16 } } }
	p1_2 { ap_memory {  { p1_2_address0 mem_address 1 6 }  { p1_2_ce0 mem_ce 1 1 }  { p1_2_we0 mem_we 1 1 }  { p1_2_d0 mem_din 1 16 } } }
	p1_3 { ap_memory {  { p1_3_address0 mem_address 1 6 }  { p1_3_ce0 mem_ce 1 1 }  { p1_3_we0 mem_we 1 1 }  { p1_3_d0 mem_din 1 16 } } }
	p1_4 { ap_memory {  { p1_4_address0 mem_address 1 6 }  { p1_4_ce0 mem_ce 1 1 }  { p1_4_we0 mem_we 1 1 }  { p1_4_d0 mem_din 1 16 } } }
	p1_5 { ap_memory {  { p1_5_address0 mem_address 1 6 }  { p1_5_ce0 mem_ce 1 1 }  { p1_5_we0 mem_we 1 1 }  { p1_5_d0 mem_din 1 16 } } }
	p1_6 { ap_memory {  { p1_6_address0 mem_address 1 6 }  { p1_6_ce0 mem_ce 1 1 }  { p1_6_we0 mem_we 1 1 }  { p1_6_d0 mem_din 1 16 } } }
	p1_7 { ap_memory {  { p1_7_address0 mem_address 1 6 }  { p1_7_ce0 mem_ce 1 1 }  { p1_7_we0 mem_we 1 1 }  { p1_7_d0 mem_din 1 16 } } }
	p1_8 { ap_memory {  { p1_8_address0 mem_address 1 6 }  { p1_8_ce0 mem_ce 1 1 }  { p1_8_we0 mem_we 1 1 }  { p1_8_d0 mem_din 1 16 } } }
	p1_9 { ap_memory {  { p1_9_address0 mem_address 1 6 }  { p1_9_ce0 mem_ce 1 1 }  { p1_9_we0 mem_we 1 1 }  { p1_9_d0 mem_din 1 16 } } }
	p1_10 { ap_memory {  { p1_10_address0 mem_address 1 6 }  { p1_10_ce0 mem_ce 1 1 }  { p1_10_we0 mem_we 1 1 }  { p1_10_d0 mem_din 1 16 } } }
	p1_11 { ap_memory {  { p1_11_address0 mem_address 1 6 }  { p1_11_ce0 mem_ce 1 1 }  { p1_11_we0 mem_we 1 1 }  { p1_11_d0 mem_din 1 16 } } }
	p1_12 { ap_memory {  { p1_12_address0 mem_address 1 6 }  { p1_12_ce0 mem_ce 1 1 }  { p1_12_we0 mem_we 1 1 }  { p1_12_d0 mem_din 1 16 } } }
	p1_13 { ap_memory {  { p1_13_address0 mem_address 1 6 }  { p1_13_ce0 mem_ce 1 1 }  { p1_13_we0 mem_we 1 1 }  { p1_13_d0 mem_din 1 16 } } }
	p1_14 { ap_memory {  { p1_14_address0 mem_address 1 6 }  { p1_14_ce0 mem_ce 1 1 }  { p1_14_we0 mem_we 1 1 }  { p1_14_d0 mem_din 1 16 } } }
	p1_15 { ap_memory {  { p1_15_address0 mem_address 1 6 }  { p1_15_ce0 mem_ce 1 1 }  { p1_15_we0 mem_we 1 1 }  { p1_15_d0 mem_din 1 16 } } }
	p1_16 { ap_memory {  { p1_16_address0 mem_address 1 6 }  { p1_16_ce0 mem_ce 1 1 }  { p1_16_we0 mem_we 1 1 }  { p1_16_d0 mem_din 1 16 } } }
	p1_17 { ap_memory {  { p1_17_address0 mem_address 1 6 }  { p1_17_ce0 mem_ce 1 1 }  { p1_17_we0 mem_we 1 1 }  { p1_17_d0 mem_din 1 16 } } }
	p1_18 { ap_memory {  { p1_18_address0 mem_address 1 6 }  { p1_18_ce0 mem_ce 1 1 }  { p1_18_we0 mem_we 1 1 }  { p1_18_d0 mem_din 1 16 } } }
	p1_19 { ap_memory {  { p1_19_address0 mem_address 1 6 }  { p1_19_ce0 mem_ce 1 1 }  { p1_19_we0 mem_we 1 1 }  { p1_19_d0 mem_din 1 16 } } }
	p1_20 { ap_memory {  { p1_20_address0 mem_address 1 6 }  { p1_20_ce0 mem_ce 1 1 }  { p1_20_we0 mem_we 1 1 }  { p1_20_d0 mem_din 1 16 } } }
	p1_21 { ap_memory {  { p1_21_address0 mem_address 1 6 }  { p1_21_ce0 mem_ce 1 1 }  { p1_21_we0 mem_we 1 1 }  { p1_21_d0 mem_din 1 16 } } }
	p1_22 { ap_memory {  { p1_22_address0 mem_address 1 6 }  { p1_22_ce0 mem_ce 1 1 }  { p1_22_we0 mem_we 1 1 }  { p1_22_d0 mem_din 1 16 } } }
	p1_23 { ap_memory {  { p1_23_address0 mem_address 1 6 }  { p1_23_ce0 mem_ce 1 1 }  { p1_23_we0 mem_we 1 1 }  { p1_23_d0 mem_din 1 16 } } }
	p1_24 { ap_memory {  { p1_24_address0 mem_address 1 6 }  { p1_24_ce0 mem_ce 1 1 }  { p1_24_we0 mem_we 1 1 }  { p1_24_d0 mem_din 1 16 } } }
	p1_25 { ap_memory {  { p1_25_address0 mem_address 1 6 }  { p1_25_ce0 mem_ce 1 1 }  { p1_25_we0 mem_we 1 1 }  { p1_25_d0 mem_din 1 16 } } }
	p1_26 { ap_memory {  { p1_26_address0 mem_address 1 6 }  { p1_26_ce0 mem_ce 1 1 }  { p1_26_we0 mem_we 1 1 }  { p1_26_d0 mem_din 1 16 } } }
	p1_27 { ap_memory {  { p1_27_address0 mem_address 1 6 }  { p1_27_ce0 mem_ce 1 1 }  { p1_27_we0 mem_we 1 1 }  { p1_27_d0 mem_din 1 16 } } }
	p1_28 { ap_memory {  { p1_28_address0 mem_address 1 6 }  { p1_28_ce0 mem_ce 1 1 }  { p1_28_we0 mem_we 1 1 }  { p1_28_d0 mem_din 1 16 } } }
	p1_29 { ap_memory {  { p1_29_address0 mem_address 1 6 }  { p1_29_ce0 mem_ce 1 1 }  { p1_29_we0 mem_we 1 1 }  { p1_29_d0 mem_din 1 16 } } }
	p1_30 { ap_memory {  { p1_30_address0 mem_address 1 6 }  { p1_30_ce0 mem_ce 1 1 }  { p1_30_we0 mem_we 1 1 }  { p1_30_d0 mem_din 1 16 } } }
	p1_31 { ap_memory {  { p1_31_address0 mem_address 1 6 }  { p1_31_ce0 mem_ce 1 1 }  { p1_31_we0 mem_we 1 1 }  { p1_31_d0 mem_din 1 16 } } }
	p1_32 { ap_memory {  { p1_32_address0 mem_address 1 6 }  { p1_32_ce0 mem_ce 1 1 }  { p1_32_we0 mem_we 1 1 }  { p1_32_d0 mem_din 1 16 } } }
	p1_33 { ap_memory {  { p1_33_address0 mem_address 1 6 }  { p1_33_ce0 mem_ce 1 1 }  { p1_33_we0 mem_we 1 1 }  { p1_33_d0 mem_din 1 16 } } }
	p1_34 { ap_memory {  { p1_34_address0 mem_address 1 6 }  { p1_34_ce0 mem_ce 1 1 }  { p1_34_we0 mem_we 1 1 }  { p1_34_d0 mem_din 1 16 } } }
	p1_35 { ap_memory {  { p1_35_address0 mem_address 1 6 }  { p1_35_ce0 mem_ce 1 1 }  { p1_35_we0 mem_we 1 1 }  { p1_35_d0 mem_din 1 16 } } }
}
