set moduleName shape_accel_Pipeline_VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VITIS
set isTopModule 0
set isCombinational 0
set isDatapathOnly 0
set isPipelined 1
set isPipelined_legacy 1
set pipeline_type loop_auto_rewind
set FunctionProtocol ap_ctrl_hs
set restart_counter_num 0
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set hasInterrupt 0
set DLRegFirstOffset 0
set DLRegItemOffset 0
set svuvm_can_support 1
set cdfgNum 9
set C_modelName {shape_accel_Pipeline_VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VITIS}
set C_modelType { void 0 }
set ap_memory_interface_dict [dict create]
dict set ap_memory_interface_dict p2 { MEM_WIDTH 16 MEM_SIZE 1024 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
dict set ap_memory_interface_dict scores { MEM_WIDTH 32 MEM_SIZE 16 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
set C_modelArgList {
	{ p2 int 16 regular {array 512 { 1 3 } 1 1 }  }
	{ scores int 32 regular {array 4 { 0 } 1 1 }  }
	{ best_cls_11_out int 32 regular {pointer 1}  }
}
set hasAXIMCache 0
set l_AXIML2Cache [list]
set AXIMCacheInstDict [dict create]
set C_modelArgMapList {[ 
	{ "Name" : "p2", "interface" : "memory", "bitwidth" : 16, "direction" : "READONLY"} , 
 	{ "Name" : "scores", "interface" : "memory", "bitwidth" : 32, "direction" : "WRITEONLY"} , 
 	{ "Name" : "best_cls_11_out", "interface" : "wire", "bitwidth" : 32, "direction" : "WRITEONLY"} ]}
# RTL Port declarations: 
set portNum 15
set portList { 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst sc_in sc_logic 1 reset -1 active_high_sync } 
	{ ap_start sc_in sc_logic 1 start -1 } 
	{ ap_done sc_out sc_logic 1 predone -1 } 
	{ ap_idle sc_out sc_logic 1 done -1 } 
	{ ap_ready sc_out sc_logic 1 ready -1 } 
	{ p2_address0 sc_out sc_lv 9 signal 0 } 
	{ p2_ce0 sc_out sc_logic 1 signal 0 } 
	{ p2_q0 sc_in sc_lv 16 signal 0 } 
	{ scores_address0 sc_out sc_lv 2 signal 1 } 
	{ scores_ce0 sc_out sc_logic 1 signal 1 } 
	{ scores_we0 sc_out sc_logic 1 signal 1 } 
	{ scores_d0 sc_out sc_lv 32 signal 1 } 
	{ best_cls_11_out sc_out sc_lv 32 signal 2 } 
	{ best_cls_11_out_ap_vld sc_out sc_logic 1 outvld 2 } 
}
set NewPortList {[ 
	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst", "role": "default" }} , 
 	{ "name": "ap_start", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "start", "bundle":{"name": "ap_start", "role": "default" }} , 
 	{ "name": "ap_done", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "predone", "bundle":{"name": "ap_done", "role": "default" }} , 
 	{ "name": "ap_idle", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "done", "bundle":{"name": "ap_idle", "role": "default" }} , 
 	{ "name": "ap_ready", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "ready", "bundle":{"name": "ap_ready", "role": "default" }} , 
 	{ "name": "p2_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":9, "type": "signal", "bundle":{"name": "p2", "role": "address0" }} , 
 	{ "name": "p2_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "p2", "role": "ce0" }} , 
 	{ "name": "p2_q0", "direction": "in", "datatype": "sc_lv", "bitwidth":16, "type": "signal", "bundle":{"name": "p2", "role": "q0" }} , 
 	{ "name": "scores_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "scores", "role": "address0" }} , 
 	{ "name": "scores_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "scores", "role": "ce0" }} , 
 	{ "name": "scores_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "scores", "role": "we0" }} , 
 	{ "name": "scores_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "scores", "role": "d0" }} , 
 	{ "name": "best_cls_11_out", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "best_cls_11_out", "role": "default" }} , 
 	{ "name": "best_cls_11_out_ap_vld", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "outvld", "bundle":{"name": "best_cls_11_out", "role": "ap_vld" }}  ]}

set ArgLastReadFirstWriteLatency {
	shape_accel_Pipeline_VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VITIS {
		p2 {Type I LastRead 2 FirstWrite -1}
		scores {Type O LastRead -1 FirstWrite 6}
		best_cls_11_out {Type O LastRead -1 FirstWrite 6}
		W_FC {Type I LastRead -1 FirstWrite -1}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "2056", "Max" : "2056"}
	, {"Name" : "Interval", "Min" : "2049", "Max" : "2049"}
]}

set PipelineEnableSignalInfo {[
	{"Pipeline" : "0", "EnableSignal" : "ap_enable_pp0"}
]}

set Spec2ImplPortList { 
	p2 { ap_memory {  { p2_address0 mem_address 1 9 }  { p2_ce0 mem_ce 1 1 }  { p2_q0 mem_dout 0 16 } } }
	scores { ap_memory {  { scores_address0 mem_address 1 2 }  { scores_ce0 mem_ce 1 1 }  { scores_we0 mem_we 1 1 }  { scores_d0 mem_din 1 32 } } }
	best_cls_11_out { ap_vld {  { best_cls_11_out out_data 1 32 }  { best_cls_11_out_ap_vld out_vld 1 1 } } }
}
