// 0x000 : Control signals
//         bit 0  - ap_start (Read/Write/COH)
//         bit 1  - ap_done (Read/COR)
//         bit 2  - ap_idle (Read)
//         bit 3  - ap_ready (Read/COR)
//         bit 7  - auto_restart (Read/Write)
//         bit 9  - interrupt (Read)
//         others - reserved
// 0x004 : Global Interrupt Enable Register
//         bit 0  - Global Interrupt Enable (Read/Write)
//         others - reserved
// 0x008 : IP Interrupt Enable Register (Read/Write)
//         bit 0 - enable ap_done interrupt (Read/Write)
//         bit 1 - enable ap_ready interrupt (Read/Write)
//         others - reserved
// 0x00c : IP Interrupt Status Register (Read/TOW)
//         bit 0 - ap_done (Read/TOW)
//         bit 1 - ap_ready (Read/TOW)
//         others - reserved
// 0x020 : Data signal of pred_class
//         bit 31~0 - pred_class[31:0] (Read)
// 0x024 : Control signal of pred_class
//         bit 0  - pred_class_ap_vld (Read/COR)
//         others - reserved
// 0x010 ~
// 0x01f : Memory 'scores' (4 * 32b)
//         Word n : bit [31:0] - scores[n]
// 0x400 ~
// 0x7ff : Memory 'img' (1024 * 8b)
//         Word n : bit [ 7: 0] - img[4n]
//                  bit [15: 8] - img[4n+1]
//                  bit [23:16] - img[4n+2]
//                  bit [31:24] - img[4n+3]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define CTRL_ADDR_AP_CTRL         0x000
#define CTRL_ADDR_GIE             0x004
#define CTRL_ADDR_IER             0x008
#define CTRL_ADDR_ISR             0x00c
#define CTRL_ADDR_PRED_CLASS_DATA 0x020
#define CTRL_BITS_PRED_CLASS_DATA 32
#define CTRL_ADDR_PRED_CLASS_CTRL 0x024
#define CTRL_ADDR_SCORES_BASE     0x010
#define CTRL_ADDR_SCORES_HIGH     0x01f
#define CTRL_WIDTH_SCORES         32
#define CTRL_DEPTH_SCORES         4
#define CTRL_ADDR_IMG_BASE        0x400
#define CTRL_ADDR_IMG_HIGH        0x7ff
#define CTRL_WIDTH_IMG            8
#define CTRL_DEPTH_IMG            1024
