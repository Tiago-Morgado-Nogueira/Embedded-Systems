set moduleName shape_accel_Pipeline_VITIS_LOOP_21_1_VITIS_LOOP_22_2
set isTopModule 0
set isCombinational 0
set isDatapathOnly 0
set isPipelined 1
set isPipelined_legacy 1
set pipeline_type loop_auto_rewind
set FunctionProtocol ap_ctrl_hs
set restart_counter_num 0
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set hasInterrupt 0
set DLRegFirstOffset 0
set DLRegItemOffset 0
set svuvm_can_support 1
set cdfgNum 9
set C_modelName {shape_accel_Pipeline_VITIS_LOOP_21_1_VITIS_LOOP_22_2}
set C_modelType { void 0 }
set ap_memory_interface_dict [dict create]
dict set ap_memory_interface_dict x_in { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict x_in_1 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict x_in_2 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict x_in_3 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict x_in_4 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict x_in_5 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict x_in_6 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict x_in_7 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict x_in_8 { MEM_WIDTH 13 MEM_SIZE 242 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 0 }
dict set ap_memory_interface_dict img { MEM_WIDTH 8 MEM_SIZE 1024 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
set C_modelArgList {
	{ x_in int 13 regular {array 121 { 0 3 } 0 1 }  }
	{ x_in_1 int 13 regular {array 121 { 0 3 } 0 1 }  }
	{ x_in_2 int 13 regular {array 121 { 0 3 } 0 1 }  }
	{ x_in_3 int 13 regular {array 121 { 0 3 } 0 1 }  }
	{ x_in_4 int 13 regular {array 121 { 0 3 } 0 1 }  }
	{ x_in_5 int 13 regular {array 121 { 0 3 } 0 1 }  }
	{ x_in_6 int 13 regular {array 121 { 0 3 } 0 1 }  }
	{ x_in_7 int 13 regular {array 121 { 0 3 } 0 1 }  }
	{ x_in_8 int 13 regular {array 121 { 0 3 } 0 1 }  }
	{ img int 8 regular {array 1024 { 1 } 1 1 }  }
}
set hasAXIMCache 0
set l_AXIML2Cache [list]
set AXIMCacheInstDict [dict create]
set C_modelArgMapList {[ 
	{ "Name" : "x_in", "interface" : "memory", "bitwidth" : 13, "direction" : "WRITEONLY"} , 
 	{ "Name" : "x_in_1", "interface" : "memory", "bitwidth" : 13, "direction" : "WRITEONLY"} , 
 	{ "Name" : "x_in_2", "interface" : "memory", "bitwidth" : 13, "direction" : "WRITEONLY"} , 
 	{ "Name" : "x_in_3", "interface" : "memory", "bitwidth" : 13, "direction" : "WRITEONLY"} , 
 	{ "Name" : "x_in_4", "interface" : "memory", "bitwidth" : 13, "direction" : "WRITEONLY"} , 
 	{ "Name" : "x_in_5", "interface" : "memory", "bitwidth" : 13, "direction" : "WRITEONLY"} , 
 	{ "Name" : "x_in_6", "interface" : "memory", "bitwidth" : 13, "direction" : "WRITEONLY"} , 
 	{ "Name" : "x_in_7", "interface" : "memory", "bitwidth" : 13, "direction" : "WRITEONLY"} , 
 	{ "Name" : "x_in_8", "interface" : "memory", "bitwidth" : 13, "direction" : "WRITEONLY"} , 
 	{ "Name" : "img", "interface" : "memory", "bitwidth" : 8, "direction" : "READONLY"} ]}
# RTL Port declarations: 
set portNum 45
set portList { 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst sc_in sc_logic 1 reset -1 active_high_sync } 
	{ ap_start sc_in sc_logic 1 start -1 } 
	{ ap_done sc_out sc_logic 1 predone -1 } 
	{ ap_idle sc_out sc_logic 1 done -1 } 
	{ ap_ready sc_out sc_logic 1 ready -1 } 
	{ x_in_address0 sc_out sc_lv 7 signal 0 } 
	{ x_in_ce0 sc_out sc_logic 1 signal 0 } 
	{ x_in_we0 sc_out sc_logic 1 signal 0 } 
	{ x_in_d0 sc_out sc_lv 13 signal 0 } 
	{ x_in_1_address0 sc_out sc_lv 7 signal 1 } 
	{ x_in_1_ce0 sc_out sc_logic 1 signal 1 } 
	{ x_in_1_we0 sc_out sc_logic 1 signal 1 } 
	{ x_in_1_d0 sc_out sc_lv 13 signal 1 } 
	{ x_in_2_address0 sc_out sc_lv 7 signal 2 } 
	{ x_in_2_ce0 sc_out sc_logic 1 signal 2 } 
	{ x_in_2_we0 sc_out sc_logic 1 signal 2 } 
	{ x_in_2_d0 sc_out sc_lv 13 signal 2 } 
	{ x_in_3_address0 sc_out sc_lv 7 signal 3 } 
	{ x_in_3_ce0 sc_out sc_logic 1 signal 3 } 
	{ x_in_3_we0 sc_out sc_logic 1 signal 3 } 
	{ x_in_3_d0 sc_out sc_lv 13 signal 3 } 
	{ x_in_4_address0 sc_out sc_lv 7 signal 4 } 
	{ x_in_4_ce0 sc_out sc_logic 1 signal 4 } 
	{ x_in_4_we0 sc_out sc_logic 1 signal 4 } 
	{ x_in_4_d0 sc_out sc_lv 13 signal 4 } 
	{ x_in_5_address0 sc_out sc_lv 7 signal 5 } 
	{ x_in_5_ce0 sc_out sc_logic 1 signal 5 } 
	{ x_in_5_we0 sc_out sc_logic 1 signal 5 } 
	{ x_in_5_d0 sc_out sc_lv 13 signal 5 } 
	{ x_in_6_address0 sc_out sc_lv 7 signal 6 } 
	{ x_in_6_ce0 sc_out sc_logic 1 signal 6 } 
	{ x_in_6_we0 sc_out sc_logic 1 signal 6 } 
	{ x_in_6_d0 sc_out sc_lv 13 signal 6 } 
	{ x_in_7_address0 sc_out sc_lv 7 signal 7 } 
	{ x_in_7_ce0 sc_out sc_logic 1 signal 7 } 
	{ x_in_7_we0 sc_out sc_logic 1 signal 7 } 
	{ x_in_7_d0 sc_out sc_lv 13 signal 7 } 
	{ x_in_8_address0 sc_out sc_lv 7 signal 8 } 
	{ x_in_8_ce0 sc_out sc_logic 1 signal 8 } 
	{ x_in_8_we0 sc_out sc_logic 1 signal 8 } 
	{ x_in_8_d0 sc_out sc_lv 13 signal 8 } 
	{ img_address0 sc_out sc_lv 10 signal 9 } 
	{ img_ce0 sc_out sc_logic 1 signal 9 } 
	{ img_q0 sc_in sc_lv 8 signal 9 } 
}
set NewPortList {[ 
	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst", "role": "default" }} , 
 	{ "name": "ap_start", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "start", "bundle":{"name": "ap_start", "role": "default" }} , 
 	{ "name": "ap_done", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "predone", "bundle":{"name": "ap_done", "role": "default" }} , 
 	{ "name": "ap_idle", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "done", "bundle":{"name": "ap_idle", "role": "default" }} , 
 	{ "name": "ap_ready", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "ready", "bundle":{"name": "ap_ready", "role": "default" }} , 
 	{ "name": "x_in_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in", "role": "address0" }} , 
 	{ "name": "x_in_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in", "role": "ce0" }} , 
 	{ "name": "x_in_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in", "role": "we0" }} , 
 	{ "name": "x_in_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in", "role": "d0" }} , 
 	{ "name": "x_in_1_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_1", "role": "address0" }} , 
 	{ "name": "x_in_1_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_1", "role": "ce0" }} , 
 	{ "name": "x_in_1_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_1", "role": "we0" }} , 
 	{ "name": "x_in_1_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_1", "role": "d0" }} , 
 	{ "name": "x_in_2_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_2", "role": "address0" }} , 
 	{ "name": "x_in_2_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_2", "role": "ce0" }} , 
 	{ "name": "x_in_2_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_2", "role": "we0" }} , 
 	{ "name": "x_in_2_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_2", "role": "d0" }} , 
 	{ "name": "x_in_3_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_3", "role": "address0" }} , 
 	{ "name": "x_in_3_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_3", "role": "ce0" }} , 
 	{ "name": "x_in_3_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_3", "role": "we0" }} , 
 	{ "name": "x_in_3_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_3", "role": "d0" }} , 
 	{ "name": "x_in_4_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_4", "role": "address0" }} , 
 	{ "name": "x_in_4_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_4", "role": "ce0" }} , 
 	{ "name": "x_in_4_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_4", "role": "we0" }} , 
 	{ "name": "x_in_4_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_4", "role": "d0" }} , 
 	{ "name": "x_in_5_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_5", "role": "address0" }} , 
 	{ "name": "x_in_5_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_5", "role": "ce0" }} , 
 	{ "name": "x_in_5_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_5", "role": "we0" }} , 
 	{ "name": "x_in_5_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_5", "role": "d0" }} , 
 	{ "name": "x_in_6_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_6", "role": "address0" }} , 
 	{ "name": "x_in_6_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_6", "role": "ce0" }} , 
 	{ "name": "x_in_6_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_6", "role": "we0" }} , 
 	{ "name": "x_in_6_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_6", "role": "d0" }} , 
 	{ "name": "x_in_7_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_7", "role": "address0" }} , 
 	{ "name": "x_in_7_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_7", "role": "ce0" }} , 
 	{ "name": "x_in_7_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_7", "role": "we0" }} , 
 	{ "name": "x_in_7_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_7", "role": "d0" }} , 
 	{ "name": "x_in_8_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":7, "type": "signal", "bundle":{"name": "x_in_8", "role": "address0" }} , 
 	{ "name": "x_in_8_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_8", "role": "ce0" }} , 
 	{ "name": "x_in_8_we0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "x_in_8", "role": "we0" }} , 
 	{ "name": "x_in_8_d0", "direction": "out", "datatype": "sc_lv", "bitwidth":13, "type": "signal", "bundle":{"name": "x_in_8", "role": "d0" }} , 
 	{ "name": "img_address0", "direction": "out", "datatype": "sc_lv", "bitwidth":10, "type": "signal", "bundle":{"name": "img", "role": "address0" }} , 
 	{ "name": "img_ce0", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "img", "role": "ce0" }} , 
 	{ "name": "img_q0", "direction": "in", "datatype": "sc_lv", "bitwidth":8, "type": "signal", "bundle":{"name": "img", "role": "q0" }}  ]}

set ArgLastReadFirstWriteLatency {
	shape_accel_Pipeline_VITIS_LOOP_21_1_VITIS_LOOP_22_2 {
		x_in {Type O LastRead -1 FirstWrite 12}
		x_in_1 {Type O LastRead -1 FirstWrite 12}
		x_in_2 {Type O LastRead -1 FirstWrite 12}
		x_in_3 {Type O LastRead -1 FirstWrite 12}
		x_in_4 {Type O LastRead -1 FirstWrite 12}
		x_in_5 {Type O LastRead -1 FirstWrite 12}
		x_in_6 {Type O LastRead -1 FirstWrite 12}
		x_in_7 {Type O LastRead -1 FirstWrite 12}
		x_in_8 {Type O LastRead -1 FirstWrite 12}
		img {Type I LastRead 10 FirstWrite -1}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "1037", "Max" : "1037"}
	, {"Name" : "Interval", "Min" : "1025", "Max" : "1025"}
]}

set PipelineEnableSignalInfo {[
	{"Pipeline" : "0", "EnableSignal" : "ap_enable_pp0"}
]}

set Spec2ImplPortList { 
	x_in { ap_memory {  { x_in_address0 mem_address 1 7 }  { x_in_ce0 mem_ce 1 1 }  { x_in_we0 mem_we 1 1 }  { x_in_d0 mem_din 1 13 } } }
	x_in_1 { ap_memory {  { x_in_1_address0 mem_address 1 7 }  { x_in_1_ce0 mem_ce 1 1 }  { x_in_1_we0 mem_we 1 1 }  { x_in_1_d0 mem_din 1 13 } } }
	x_in_2 { ap_memory {  { x_in_2_address0 mem_address 1 7 }  { x_in_2_ce0 mem_ce 1 1 }  { x_in_2_we0 mem_we 1 1 }  { x_in_2_d0 mem_din 1 13 } } }
	x_in_3 { ap_memory {  { x_in_3_address0 mem_address 1 7 }  { x_in_3_ce0 mem_ce 1 1 }  { x_in_3_we0 mem_we 1 1 }  { x_in_3_d0 mem_din 1 13 } } }
	x_in_4 { ap_memory {  { x_in_4_address0 mem_address 1 7 }  { x_in_4_ce0 mem_ce 1 1 }  { x_in_4_we0 mem_we 1 1 }  { x_in_4_d0 mem_din 1 13 } } }
	x_in_5 { ap_memory {  { x_in_5_address0 mem_address 1 7 }  { x_in_5_ce0 mem_ce 1 1 }  { x_in_5_we0 mem_we 1 1 }  { x_in_5_d0 mem_din 1 13 } } }
	x_in_6 { ap_memory {  { x_in_6_address0 mem_address 1 7 }  { x_in_6_ce0 mem_ce 1 1 }  { x_in_6_we0 mem_we 1 1 }  { x_in_6_d0 mem_din 1 13 } } }
	x_in_7 { ap_memory {  { x_in_7_address0 mem_address 1 7 }  { x_in_7_ce0 mem_ce 1 1 }  { x_in_7_we0 mem_we 1 1 }  { x_in_7_d0 mem_din 1 13 } } }
	x_in_8 { ap_memory {  { x_in_8_address0 mem_address 1 7 }  { x_in_8_ce0 mem_ce 1 1 }  { x_in_8_we0 mem_we 1 1 }  { x_in_8_d0 mem_din 1 13 } } }
	img { ap_memory {  { img_address0 mem_address 1 10 }  { img_ce0 mem_ce 1 1 }  { img_q0 mem_dout 0 8 } } }
}
