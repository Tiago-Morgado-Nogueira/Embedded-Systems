dict set slaves CTRL {ports {scores {type o_ap_memory width 32} pred_class {type o_ap_vld width 32} img {type i_ap_memory width 8} ap_start {type ap_ctrl width 1} ap_done {type ap_ctrl width 1} ap_ready {type ap_ctrl width 1} ap_idle {type ap_ctrl width 1}} mems {scores {width 32} img {width 8}} has_ctrl 1}
set datawidth 32
set addrwidth 64
set intr_clr_mode TOW
