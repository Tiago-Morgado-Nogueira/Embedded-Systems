# 1 "../cnn_accel.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 405 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/tools/2026.1/Vitis/common/technology/autopilot/etc/autopilot_ssdm_op.h" 1
# 105 "/tools/2026.1/Vitis/common/technology/autopilot/etc/autopilot_ssdm_op.h"
extern "C" {






    void _ssdm_op_IfRead(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_IfWrite(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfNbRead(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfNbWrite(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfCanRead(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfCanWrite(...) __attribute__ ((nothrow)) __attribute__((overloadable));


    void _ssdm_StreamRead(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_StreamWrite(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamNbRead(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamNbWrite(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamCanRead(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamCanWrite(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    unsigned _ssdm_StreamSize(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_ReadReq(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_Read(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_WriteReq(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_Write(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_NbReadReq(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_CanReadReq(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_NbWriteReq(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_CanWriteReq(...) __attribute__ ((nothrow)) __attribute__((overloadable));




    void _ssdm_op_MemShiftRead(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_PrintNone(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_PrintInt(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_PrintDouble(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_Wait(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_Poll(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_Return(...) __attribute__ ((nothrow)) __attribute__((overloadable));


    void _ssdm_op_SpecSynModule(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecTopModule(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecProcessDecl(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecProcessDef(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecPort(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecConnection(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecChannel(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecSensitive(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecModuleInst(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecPortMap(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_SpecReset(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_SpecPlatform(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecClockDomain(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecPowerDomain(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    int _ssdm_op_SpecRegionBegin(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    int _ssdm_op_SpecRegionEnd(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_SpecLoopName(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_SpecLoopTripCount(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    int _ssdm_op_SpecStateBegin(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    int _ssdm_op_SpecStateEnd(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_SpecInterface(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_SpecPipeline(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecDataflowPipeline(...) __attribute__ ((nothrow)) __attribute__((overloadable));


    void _ssdm_op_SpecLatency(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecParallel(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecProtocol(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecOccurrence(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_SpecResource(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecResourceLimit(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecCHCore(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecFUCore(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecIFCore(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecIPCore(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecMemCore(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_SpecExt(...) __attribute__ ((nothrow)) __attribute__((overloadable));




    void _ssdm_SpecArrayDimSize(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_RegionBegin(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_RegionEnd(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_InlineAll(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_InlineLoop(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_Inline(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_InlineSelf(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_InlineRegion(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_SpecArrayMap(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_SpecArrayPartition(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_SpecArrayReshape(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_SpecStream(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_SpecStable(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecStableContent(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_SpecBindPort(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_SpecPipoDepth(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_SpecExpr(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_SpecExprBalance(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_SpecDependence(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_SpecLoopMerge(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_SpecLoopFlatten(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_SpecLoopRewind(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_SpecFuncInstantiation(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_SpecFuncBuffer(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_SpecFuncExtract(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_SpecConstant(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_DataPack(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_SpecDataPack(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void _ssdm_op_SpecBitsMap(...) __attribute__ ((nothrow)) __attribute__((overloadable));
    void _ssdm_op_SpecLicense(...) __attribute__ ((nothrow)) __attribute__((overloadable));

    void __xilinx_ip_top(...) __attribute__ ((nothrow)) __attribute__((overloadable));


}
# 2 "<built-in>" 2
# 1 "../cnn_accel.cpp" 2
# 1 "../shape_accel.h" 1



# 1 "/tools/2026.1/lnx64/tools/clang-16/lib/clang/16/include/stdint.h" 1 3
# 52 "/tools/2026.1/lnx64/tools/clang-16/lib/clang/16/include/stdint.h" 3
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 431 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 432 "/usr/include/features.h" 2 3 4
# 517 "/usr/include/features.h" 3 4
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 518 "/usr/include/features.h" 2 3 4
# 539 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 540 "/usr/include/features.h" 2 3 4
# 563 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 564 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4








# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 39 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 42 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 46 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 64 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 80 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 94 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 53 "/tools/2026.1/lnx64/tools/clang-16/lib/clang/16/include/stdint.h" 2 3
# 5 "../shape_accel.h" 2







__attribute__((sdx_kernel("shape_accel", 0))) void shape_accel(
    const uint8_t img[(32 * 32)],
    int32_t scores[4],
    int32_t *pred_class
);
# 2 "../cnn_accel.cpp" 2
# 1 "../model_weights.h" 1








const int16_t W_CONV1[36] = {
    473, 548, 324, 512, 394, 397, 269, 474, 482, 156, 523, 419, 519, 504, 521, 416, 599, 445, 177, 390, 288, 280, 299, 530, -61, 236, 386, 321, 477, 266, 625, 298, 622, 499, 411, 576
};

const int16_t W_CONV2[288] = {
    98, 222, 44, 8, 110, -38, 175, 269, 182, -33, 161, 41, 191, -103, -210, 8, -106, 237, 140, 95, 102, 107, 177, -118, 107, -130, 143, -3, 122, -10, 230, -91, -100, -82, 275, 119, 212, -483, 15, -813, -286, 432, -360, 554, 393, -336, -260, 205, -547, -173, 576, -577, 302, 641, -131, -438, 520, -472, -211, 400, -260, 433, 346, -431, -480, 419, -798, -78, 511, -492, 368, 605, -396, 227, 821, -539, 67, 263, -899, -239, 465, -439, 291, 399, -577, -8, 503, -882, -296, 292, -125, 552, 937, -612, 457, 720, -1023, 316, 616, -558, 33, 409, -642, -54, 643, -1033, -35, 300, -55, -5, 45, 247, 228, -189, 133, -36, -17, -175, 151, -232, 184, 96, 68, -51, 257, 56, -18, -308, 23, 72, -117, 252, 157, -87, -13, 23, 132, -76, -36, -12, -134, 180, 276, -163, 68, 99, 17, -17, 160, 158, 125, 2, -28, 32, -56, -84, 200, 230, 26, -13, 36, 12, 65, 18, -241, 45, 247, 156, 61, -125, -70, -154, -41, 80, 225, 192, -122, -67, 37, 269, 637, 344, 594, 145, -55, 618, -566, -764, -643, 775, 601, 633, -39, -199, 258, -413, -656, -221, 735, 579, 704, 106, 201, 696, -675, -922, 13, 720, 555, 575, -103, -138, 374, -482, -1024, -622, -11, 7, -87, -129, 255, -79, 199, 217, 249, -116, 285, -129, 188, 348, 33, 96, 60, -101, 222, -147, -48, 295, 344, -61, -53, 150, 205, -161, 141, -82, 56, 47, 10, 25, -75, 282, 738, 464, -10, 439, -17, -782, 443, -301, -840, 569, 365, -187, 559, 56, -737, 233, -524, -602, 518, 365, -291, 442, -83, -673, 18, -504, -720, 686, 670, -94, 592, 296, -829, 300, -125, -804
};

const int16_t W_FC[2048] = {
    124, 97, 7, -87, -67, -20, 55, 164, -229, -95, 81, -11, 19, 50, 8, 74, 25, 5, -2, -97, -44, -21, 95, -16, -25, 102, 23, -174, -151, 23, -10, -30, 127, 53, 0, -103, -258, -57, 13, -20, 133, -5, 78, -59, -111, 54, 79, 81, 166, -101, -47, -6, 76, 42, 76, -156, -45, -134, 27, 81, 13, 39, 12, 81, 333, 313, -69, -110, 390, 175, 158, -39, -258, -98, 61, -68, 168, 415, 106, 3, -60, -48, 23, -155, -162, -87, -251, 453, 66, 13, -75, -364, 113, 193, -106, 110, -7, -65, 19, 146, 231, -8, -198, 89, 69, 76, -38, 186, -117, -23, -164, 94, -263, 60, 224, 202, -508, -21, -92, 130, -237, 208, 389, 864, 186, -241, -83, -117, 247, 230, 222, 460, 245, -640, 10, -41, -155, 12, 212, -99, -408, -48, 131, -38, -5, -34, 30, 99, 47, -53, 42, 29, -30, -97, -27, 191, 188, 38, -87, -280, -68, -66, -68, -396, 267, 193, -134, -471, 63, -19, 1, 83, 105, -37, -119, -145, -4, -145, -4, 50, 87, 324, 152, -83, -154, -59, 33, -9, 376, 822, 304, -58, 0, 100, 169, -9, -50, 62, -38, 162, -40, -132, 21, 12, 59, 2, 34, 40, -43, 58, 99, 35, -73, -4, -18, 68, -92, 74, 48, -171, -156, -59, 111, 12, 44, -3, 41, -140, -278, -19, 36, -68, 98, 3, 90, 73, 16, 122, 24, -10, 6, -154, -86, -12, 9, -57, -31, -131, -143, -120, 73, 3, -8, 49, 75, 154, 194, 118, 76, 47, 16, 24, -27, 111, -129, -10, 26, 57, -42, 14, -3, -17, -27, -83, 108, 37, -9, 29, -58, 7, 6, 19, -15, -206, -129, 65, 105, -80, -23, 94, 23, -180, -269, -91, 32, 12, 128, 1, 17, -47, -41, -13, 19, 78, 19, -118, -59, 9, 90, 64, -18, -125, -168, -184, -27, 0, 30, -32, 159, 135, -68, -3, 15, 71, 50, -21, 63, -54, 650, -136, 20, 100, -243, 54, 136, -87, 242, -37, -95, 169, 165, 55, 60, 466, 335, 29, -66, 22, 124, 120, -81, 576, -98, 100, -35, -207, -129, 116, -102, 69, -23, 176, -67, -4, -95, -1, 92, 179, 108, -30, 2, 1, 21, 50, -71, -59, -89, -100, -56, -66, 18, -112, 2, 84, 146, 212, 89, 12, 34, -60, 39, 166, -161, -76, -24, -27, 9, 62, 63, 137, 43, 34, 69, -115, -117, -77, 50, -27, -21, 127, 34, -181, -273, -103, 85, 12, 134, 35, 67, -31, -311, 51, 82, -122, 158, -17, 93, 109, 65, 43, 63, -38, 97, -104, -85, 87, 10, -53, -13, -196, -179, -122, 136, -76, -57, 106, 161, 80, -51, 22, 55, -319, 565, 196, 23, 138, -29, -322, 363, -264, 171, 38, 85, 138, -1, -162, 33, 26, 60, -86, 47, 2, 16, -278, 68, 200, 98, -112, 3, 48, 40, -321, 133, 190, -190, -158, 9, -25, 326, -55, 12, 192, -47, 119, -39, 138, 94, 270, 222, -141, -80, 22, 54, -128, 46, 743, 424, 62, -66, -93, -8, 178, 23, -62, -102, -32, 151, -33, -144, -270, 198, 43, -43, 7, 168, 168, 38, -24, 19, 101, -24, -57, 39, 69, 86, 103, 1, 8, 3, -211, -144, 0, 88, 91, -131, -27, -79, -130, -147, -108, 15, 38, -59, 58, 59, -91, -89, -30, 8, -33, -101, 188, 128, 16, -34, 37, 27, -24, 177, 171, 66, 50, -6, 0, 41, 14, 148, -263, -281, -37, -448, -1228, -780, 6, 234, 37, -129, -18, -912, -2088, -865, -28, 194, 158, 94, 317, -438, -431, 462, -375, 67, 176, 390, 496, 48, 174, 390, -521, -199, -53, 103, 115, 96, 426, 276, -395, -327, -187, -446, -642, 95, 548, 497, -64, 248, -256, -1061, -1526, -330, 478, 687, -156, 496, -371, -1308, -2006, -1737, -146, 71, 39, 39, -276, -936, -1178, -1415, -1177, 27, 28, 206, -178, -862, -1184, -621, 31, 171, 69, 98, -140, -542, -495, 103, 394, 511, -80, -60, -4, 41, -55, 233, 409, 582, 277, -143, 52, 312, 290, 57, 323, 388, 523, -186, 65, 92, 7, -660, -299, 200, -13, 92, 173, 30, -176, -1237, -1933, -959, -5, 270, 72, -98, -253, -871, -1525, -462, -41, 77, -157, -179, -128, 80, -11, -39, -132, 2, 10, 1, 22, 61, 156, 11, 43, -61, 16, 58, -21, 9, -13, 70, 26, -55, 28, 107, -123, -120, -131, 10, 22, -141, 86, 44, -119, -208, -67, -6, 89, -85, 82, 88, -43, -112, 0, -24, -63, -66, 120, 13, 42, 9, 9, -8, -57, 117, 173, 26, 18, -82, -123, -17, -75, -12, -68, -168, -86, -19, 28, -86, -117, 84, 93, -42, 170, 143, 141, 13, 11, 109, 94, -12, -122, 9, 109, 7, 32, -11, 127, 35, -101, -150, -115, 47, 20, -30, -14, -54, -119, -90, -72, 4, 143, -183, -44, 63, -151, -154, 12, -60, -136, 5, 160, 109, 15, 51, 15, 9, -61, 163, 170, -88, 52, -1, -41, -49, 2, 67, -7, -53, -51, 24, 92, 98, 77, -711, -705, -56, 326, 636, 554, 294, -141, -830, -1216, -185, 314, 381, 321, -360, -1363, -182, -871, -242, -6, 188, -119, -1095, -1352, -20, -157, -258, -31, 75, -369, -550, -440, -194, -169, -111, 50, 19, -222, -310, -151, 29, 93, 147, 139, 195, 56, 3, -111, 373, 217, 7, 126, 111, 107, 225, 158, -7, -51, -186, -81, 140, -21, -3, -112, 217, 11, 12, 88, 180, 122, 72, -27, 83, 61, -44, -73, -49, -20, 6, -26, -59, 67, -105, -151, -179, -110, 17, -32, -242, 30, -56, -93, -121, -25, 99, -28, -213, 133, -17, -59, -1, 53, -26, -80, -84, 111, 87, 96, 40, 75, -13, 56, 181, 165, -179, -48, -138, -172, -61, -71, -45, 78, -376, -1472, -1582, -626, -147, -221, 136, 516, 248, -52, -1051, -971, -357, -60, 11, 862, 394, 321, -56, -454, -178, -57, -1, 603, 484, 292, 42, 119, -85, 38, -86, 582, 386, 70, 132, 324, 94, 110, -376, -151, -431, -382, 87, 141, 12, -48, -54, -1706, -1606, -430, 87, 62, 86, 1, -21, -887, -800, -169, 28, 10, 70, 119, -314, 49, 96, 33, 146, 57, -104, -478, -111, 136, 73, 73, 57, 103, 117, -63, -30, -38, -7, 64, 158, 149, 60, 8, -85, -128, -17, 273, 308, 76, 150, -49, -118, -108, -26, 171, 332, 33, -97, -64, -276, 9, -91, 8, 178, -54, 35, -79, 19, 19, -51, -86, -63, -48, 68, 6, -765, -190, 88, -46, 50, 72, -50, -13, -288, -11, 71, 212, -62, -373, -611, 27, -88, 377, 157, 145, 90, -507, -923, -23, 43, 63, 198, 131, 45, 30, -278, -564, -35, 26, -208, -10, -210, -609, 4, -199, -5, -29, -89, -13, -346, -405, 370, -198, 357, -78, -26, 54, -181, 188, 325, -87, -140, 26, -406, -229, 193, 259, -11, -41, -1117, 11, -604, -468, -423, -299, 57, 69, -281, 146, -173, -205, -153, -604, -48, -44, -113, 309, 12, 47, -52, 92, -741, -39, 42, 26, 50, -199, -206, -66, 2, 57, 90, -4, -109, -118, -178, -830, 30, -289, 30, 9, -104, 63, -182, -761, 278, -106, 153, 33, 118, -99, 101, -249, 335, -78, 44, 109, 88, 40, -3, -461, -244, 3, -997, -89, 81, -26, -110, -680, -644, -22, -142, 14, 76, 64, 144, 70, -74, -486, -74, 52, 112, 103, 143, 158, 267, -67, 76, 10, -98, -9, 60, 96, 127, -71, -17, -30, -137, 227, 260, 113, 88, -54, -108, -25, -115, 208, 278, 67, -66, -93, 28, 97, -131, -35, 47, -25, 12, -56, 99, 130, 13, 42, -21, -8, 153, -8, -373, -9, 17, -46, -14, 70, -168, -170, -236, 43, -121, -74, 24, 59, -126, -373, -143, 48, 212, 68, 103, 106, 255, -30, -62, 45, -27, 57, 95, -1, 71, -111, -36, -41, -17, 187, 225, 129, 35, -156, -253, -14, -10, 246, 292, 38, -100, -65, -53, 34, -38, -71, 101, -111, -15, -120, -59, 5, 140, -79, -11, 4, 154, -2, -309, -161, 64, -87, 8, 8, -95, 39, 11, -66, -92, 14, -74, -4, 4, -22, -886, -889, 9, 331, 320, 266, -1027, -218, -51, -356, -79, -592, -473, 49, -156, -158, -52, -133, 79, -99, -162, -23, -9, -282, -79, -181, 170, 124, 185, -1, 33, -221, -18, -21, 48, 48, 23, 88, -88, -290, 28, 166, 85, -54, -28, 69, 99, -31, -932, -109, 138, 81, 200, 132, 28, 89, -224, 23, -9, 21, 92, 29, -121, -413, -68, 146, 132, 201, 179, 157, 200, 67, -32, 91, 45, 157, 73, 147, 101, -105, -10, -87, -31, 315, 223, 120, 56, -152, -290, 19, -79, 196, 318, -55, -4, -167, -120, 191, -32, -126, -60, -160, 9, -180, 37, 13, 79, 32, -24, 101, 190, 34, -320, -105, 34, -267, -15, 36, -134, -32, -64, -121, -412, -608, -670, -400, 90, -567, -71, -530, -164, -14, -195, -386, 110, 86, -100, 35, 368, -47, -183, 86, -52, 263, -107, 228, -611, -283, -125, -83, 253, 10, -108, 577, -669, -302, 52, -103, 126, 54, -96, -431, 87, -21, -78, -14, 70, -57, -130, -473, -382, -2, 22, 7, 205, 44, 10, -217, -127, 77, 17, 146, -70, 26, -56, -221, 94, 113, -261, 52, 209, 295, 75, -32, 37, -36, -225, -176, -254, -84, -159, -89, -49, 13, -126, -154, -1, 45, 136, -105, 68, 41, 64, -13, -101, 120, 172, -49, 108, 27, 37, 78, -18, 7, 260, -143, -45, 90, 87, 91, -56, 94, -196, -40, -144, -49, -7, -83, -201, 91, -112, -9, -39, -53, -149, -131, -191, -360, -193, -34, 426, 32, 164, 987, 584, -18, -8, -179, -154, -89, 561, 1550, 1317, 6, -226, -289, -261, -213, 327, 593, -252, 37, 194, -274, -199, -42, -89, -14, -798, 357, 71, 2, 1, -41, -31, -410, -987, 279, -104, 141, 361, 256, -5, -928, -978, -2, -96, 134, 898, 945, 664, -894, -614, 79, -365, 180, 995, 1213, 802, 568, -240, -99, -281, 62, 725, 725, 697, 997, -66, -36, 33, -19, 628, 813, 748, -40, -660, -29, -115, 31, 424, 332, -127, -647, -1264, 28, -51, -99, 2, -97, -114, -267, -1331, 50, 225, -76, -79, -57, -80, -133, -1269, -47, 130, -65, -104, 63, 329, 519, -640, 11, -273, -237, -74, 198, 853, 1319, 657, 17, -195, 57, -6, 225, 557, 917, 652, 33, 17, -116, 81, 205, -99, 4, 116, 246, 96, -44, -49, -99, -208, -189, -131, -160, -25, -129, -79, 50, -83, 9, -38, 24, 157, -133, 63, 100, -60, 99, -143, 48, 216, -11, 55, 26, 18, 71, -4, 57, 68, -47, -56, 83, 129, 61, -25, 11, -133, -103, -125, -121, -121, -29, -177, 81, -183, -22, 47, 96, -7, 13, -23, -87, -23, -30, 312, 278, 2, 95, 261, 303, 71, -101, -36, -229, -246, -160, -128, -77, -186, -74, -32, 55, -41, -113, -26, -23, 92, -146, 87, 74, 40, 47, -134, 27, 318, -46, 132, -6, -22, 72, -12, 118, 110, -7, -11, 98, 59, 54, 52, 108, -128, -102, -239, -129, -31, -40, -134, 40, -218, 31, 14, 56, -12, 9, -167, -216, -22, -20, 8, -67, -33, -38, -92, 34, 455, 1005, 38, -1115, -1244, -1023, 262, 173, 386, 1250, 445, 16, -255, -536, 580, 559, -101, 817, 144, 133, 26, 70, 1017, 845, 196, 307, -1, 22, -33, 107, 454, 530, 267, 131, 65, -48, -79, 76, 260, 355, -206, -249, -146, -121, -100, -70, 29, 102, -100, 111, -120, -223, -218, -220, -237, -472, -74, -205, 170, 97, -96, -17, 92, 247, 13, -184, -47, -134, -306, -242, -204, -185, -221, -121, 99, 96, 3, -2, -28, 15, 245, -47, 104, 91, 39, 59, -103, 112, 299, -146, 116, -11, -71, 59, -169, 206, 98, -215, 20, 18, 2, 118, 19, 186, -213, -136, -190, -109, -89, -135, -315, 42, -181, 81, 9, 212, 79, 52, -145, -139, -20, 25, 536, 1124, 960, 629, 171, 330, -38, -164, -967, 438, 673, 821, 288, -95, 27, -1049, -1142, -329, 108, 260, 223, -294, -63, -1409, -437, 82, 43, 12, -74, -75, 123, -1324, -327, 16, 117, -92, -177, -71, -20, 485, 466, 175, 45, -56, -85, 21, 72, 1383, 1253, 483, -15, -201, -133, -7, 33, 417, 546, 202, -87, -69, -105, -398
};
# 3 "../cnn_accel.cpp" 2

__attribute__((sdx_kernel("shape_accel", 0))) void shape_accel(
    const uint8_t img[(32 * 32)],
    int32_t scores[4],
    int32_t *pred_class
) {
#line 1 "directive"
#pragma HLSDIRECTIVE TOP name=shape_accel
# 8 "../cnn_accel.cpp"

#pragma HLS INTERFACE s_axilite port=return bundle=CTRL
#pragma HLS INTERFACE s_axilite port=img bundle=CTRL
#pragma HLS INTERFACE s_axilite port=scores bundle=CTRL
#pragma HLS INTERFACE s_axilite port=pred_class bundle=CTRL

    int16_t x_in[32][32];
    int16_t c1[4][32][32];
    int16_t p1[4][16][16];
    int16_t c2[8][16][16];
    int16_t p2[8][8][8];


    VITIS_LOOP_21_1: for (int r = 0; r < 32; r++) {
        VITIS_LOOP_22_2: for (int c = 0; c < 32; c++) {
#pragma HLS PIPELINE II=1
            x_in[r][c] = (int16_t)(((int32_t)img[r * 32 + c] * (1 << 12)) / 255);
        }
    }


    VITIS_LOOP_29_3: for (int oc = 0; oc < 4; oc++) {
        VITIS_LOOP_30_4: for (int r = 0; r < 32; r++) {
            VITIS_LOOP_31_5: for (int c = 0; c < 32; c++) {
#pragma HLS PIPELINE II=1
                int32_t acc = 0;
                VITIS_LOOP_34_6: for (int kr = -1; kr <= 1; kr++) {
                    VITIS_LOOP_35_7: for (int kc = -1; kc <= 1; kc++) {
                        int ir = r + kr;
                        int ic = c + kc;
                        if (ir >= 0 && ir < 32 && ic >= 0 && ic < 32) {
                            int16_t w = W_CONV1[oc * 9 + (kr + 1) * 3 + (kc + 1)];
                            acc += (int32_t)x_in[ir][ic] * (int32_t)w;
                        }
                    }
                }
                int32_t val = acc >> 12;
                c1[oc][r][c] = (val > 0) ? (int16_t)val : 0;
            }
        }
    }


    VITIS_LOOP_51_8: for (int ch = 0; ch < 4; ch++) {
        VITIS_LOOP_52_9: for (int r = 0; r < 16; r++) {
            VITIS_LOOP_53_10: for (int c = 0; c < 16; c++) {
#pragma HLS PIPELINE II=1
                int32_t sum = (int32_t)c1[ch][2*r][2*c] + c1[ch][2*r][2*c+1] +
                              c1[ch][2*r+1][2*c] + c1[ch][2*r+1][2*c+1];
                p1[ch][r][c] = (int16_t)(sum >> 2);
            }
        }
    }


    VITIS_LOOP_63_11: for (int oc = 0; oc < 8; oc++) {
        VITIS_LOOP_64_12: for (int r = 0; r < 16; r++) {
            VITIS_LOOP_65_13: for (int c = 0; c < 16; c++) {
#pragma HLS PIPELINE II=1
                int32_t acc = 0;
                VITIS_LOOP_68_14: for (int ic = 0; ic < 4; ic++) {
                    VITIS_LOOP_69_15: for (int kr = -1; kr <= 1; kr++) {
                        VITIS_LOOP_70_16: for (int kc = -1; kc <= 1; kc++) {
                            int ir = r + kr;
                            int i_col = c + kc;
                            if (ir >= 0 && ir < 16 && i_col >= 0 && i_col < 16) {
                                int16_t w = W_CONV2[((oc * 4 + ic) * 3 + (kr + 1)) * 3 + (kc + 1)];
                                acc += (int32_t)p1[ic][ir][i_col] * (int32_t)w;
                            }
                        }
                    }
                }
                int32_t val = acc >> 12;
                c2[oc][r][c] = (val > 0) ? (int16_t)val : 0;
            }
        }
    }


    VITIS_LOOP_87_17: for (int ch = 0; ch < 8; ch++) {
        VITIS_LOOP_88_18: for (int r = 0; r < 8; r++) {
            VITIS_LOOP_89_19: for (int c = 0; c < 8; c++) {
#pragma HLS PIPELINE II=1
                int32_t sum = (int32_t)c2[ch][2*r][2*c] + c2[ch][2*r][2*c+1] +
                              c2[ch][2*r+1][2*c] + c2[ch][2*r+1][2*c+1];
                p2[ch][r][c] = (int16_t)(sum >> 2);
            }
        }
    }


    int32_t best_score = -2147483647;
    int32_t best_cls = 0;

    VITIS_LOOP_102_20: for (int cls = 0; cls < 4; cls++) {
        int32_t acc = 0;
        VITIS_LOOP_104_21: for (int ch = 0; ch < 8; ch++) {
            VITIS_LOOP_105_22: for (int r = 0; r < 8; r++) {
                VITIS_LOOP_106_23: for (int c = 0; c < 8; c++) {
#pragma HLS PIPELINE II=1
                    int idx = ch * 64 + r * 8 + c;
                    acc += (int32_t)p2[ch][r][c] * (int32_t)W_FC[cls * 512 + idx];
                }
            }
        }
        int32_t final_score = acc >> 12;
        scores[cls] = final_score;
        if (final_score > best_score) {
            best_score = final_score;
            best_cls = cls;
        }
    }

    *pred_class = best_cls;
}
