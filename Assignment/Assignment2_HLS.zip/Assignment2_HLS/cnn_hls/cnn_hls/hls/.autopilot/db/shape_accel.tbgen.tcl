set moduleName shape_accel
set isTopModule 1
set isCombinational 0
set isDatapathOnly 0
set isPipelined 0
set isPipelined_legacy 0
set pipeline_type none
set FunctionProtocol ap_ctrl_hs
set restart_counter_num 0
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set hasInterrupt 0
set DLRegFirstOffset 0
set DLRegItemOffset 0
set svuvm_can_support 1
set cdfgNum 9
set C_modelName {shape_accel}
set C_modelType { void 0 }
set ap_memory_interface_dict [dict create]
dict set ap_memory_interface_dict img { MEM_WIDTH 8 MEM_SIZE 1024 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
dict set ap_memory_interface_dict scores { MEM_WIDTH 32 MEM_SIZE 16 MASTER_TYPE BRAM_CTRL MEM_ADDRESS_MODE WORD_ADDRESS PACKAGE_IO port READ_LATENCY 1 }
set C_modelArgList {
	{ img int 8 regular {axi_slave 0}  }
	{ scores int 32 regular {axi_slave 1}  }
	{ pred_class int 32 regular {axi_slave 1}  }
}
set hasAXIMCache 0
set l_AXIML2Cache [list]
set AXIMCacheInstDict [dict create]
set C_modelArgMapList {[ 
	{ "Name" : "img", "interface" : "axi_slave", "bundle":"CTRL","type":"ap_memory","bitwidth" : 8, "direction" : "READONLY", "offset" : {"in":1024}, "offset_end" : {"in":2047}} , 
 	{ "Name" : "scores", "interface" : "axi_slave", "bundle":"CTRL","type":"ap_memory","bitwidth" : 32, "direction" : "WRITEONLY", "offset" : {"out":16}, "offset_end" : {"out":31}} , 
 	{ "Name" : "pred_class", "interface" : "axi_slave", "bundle":"CTRL","type":"ap_vld","bitwidth" : 32, "direction" : "WRITEONLY", "offset" : {"out":32}, "offset_end" : {"out":39}} ]}
# RTL Port declarations: 
set portNum 20
set portList { 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst_n sc_in sc_logic 1 reset -1 active_low_sync } 
	{ s_axi_CTRL_AWVALID sc_in sc_logic 1 signal -1 } 
	{ s_axi_CTRL_AWREADY sc_out sc_logic 1 signal -1 } 
	{ s_axi_CTRL_AWADDR sc_in sc_lv 11 signal -1 } 
	{ s_axi_CTRL_WVALID sc_in sc_logic 1 signal -1 } 
	{ s_axi_CTRL_WREADY sc_out sc_logic 1 signal -1 } 
	{ s_axi_CTRL_WDATA sc_in sc_lv 32 signal -1 } 
	{ s_axi_CTRL_WSTRB sc_in sc_lv 4 signal -1 } 
	{ s_axi_CTRL_ARVALID sc_in sc_logic 1 signal -1 } 
	{ s_axi_CTRL_ARREADY sc_out sc_logic 1 signal -1 } 
	{ s_axi_CTRL_ARADDR sc_in sc_lv 11 signal -1 } 
	{ s_axi_CTRL_RVALID sc_out sc_logic 1 signal -1 } 
	{ s_axi_CTRL_RREADY sc_in sc_logic 1 signal -1 } 
	{ s_axi_CTRL_RDATA sc_out sc_lv 32 signal -1 } 
	{ s_axi_CTRL_RRESP sc_out sc_lv 2 signal -1 } 
	{ s_axi_CTRL_BVALID sc_out sc_logic 1 signal -1 } 
	{ s_axi_CTRL_BREADY sc_in sc_logic 1 signal -1 } 
	{ s_axi_CTRL_BRESP sc_out sc_lv 2 signal -1 } 
	{ interrupt sc_out sc_logic 1 signal -1 } 
}
set NewPortList {[ 
	{ "name": "s_axi_CTRL_AWADDR", "direction": "in", "datatype": "sc_lv", "bitwidth":11, "type": "signal", "bundle":{"name": "CTRL", "role": "AWADDR" },"address":[{"name":"shape_accel","role":"start","value":"0","valid_bit":"0"},{"name":"shape_accel","role":"continue","value":"0","valid_bit":"4"},{"name":"shape_accel","role":"auto_start","value":"0","valid_bit":"7"},{"name":"img","role":"data","value":"1024"}] },
	{ "name": "s_axi_CTRL_AWVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "CTRL", "role": "AWVALID" } },
	{ "name": "s_axi_CTRL_AWREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "CTRL", "role": "AWREADY" } },
	{ "name": "s_axi_CTRL_WVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "CTRL", "role": "WVALID" } },
	{ "name": "s_axi_CTRL_WREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "CTRL", "role": "WREADY" } },
	{ "name": "s_axi_CTRL_WDATA", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "CTRL", "role": "WDATA" } },
	{ "name": "s_axi_CTRL_WSTRB", "direction": "in", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "CTRL", "role": "WSTRB" } },
	{ "name": "s_axi_CTRL_ARADDR", "direction": "in", "datatype": "sc_lv", "bitwidth":11, "type": "signal", "bundle":{"name": "CTRL", "role": "ARADDR" },"address":[{"name":"shape_accel","role":"start","value":"0","valid_bit":"0"},{"name":"shape_accel","role":"done","value":"0","valid_bit":"1"},{"name":"shape_accel","role":"idle","value":"0","valid_bit":"2"},{"name":"shape_accel","role":"ready","value":"0","valid_bit":"3"},{"name":"shape_accel","role":"auto_start","value":"0","valid_bit":"7"},{"name":"scores","role":"data","value":"16"},{"name":"pred_class","role":"data","value":"32"}, {"name":"pred_class","role":"valid","value":"36","valid_bit":"0"}] },
	{ "name": "s_axi_CTRL_ARVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "CTRL", "role": "ARVALID" } },
	{ "name": "s_axi_CTRL_ARREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "CTRL", "role": "ARREADY" } },
	{ "name": "s_axi_CTRL_RVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "CTRL", "role": "RVALID" } },
	{ "name": "s_axi_CTRL_RREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "CTRL", "role": "RREADY" } },
	{ "name": "s_axi_CTRL_RDATA", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "CTRL", "role": "RDATA" } },
	{ "name": "s_axi_CTRL_RRESP", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "CTRL", "role": "RRESP" } },
	{ "name": "s_axi_CTRL_BVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "CTRL", "role": "BVALID" } },
	{ "name": "s_axi_CTRL_BREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "CTRL", "role": "BREADY" } },
	{ "name": "s_axi_CTRL_BRESP", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "CTRL", "role": "BRESP" } },
	{ "name": "interrupt", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "CTRL", "role": "interrupt" } }, 
 	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst_n", "role": "default" }}  ]}

set ArgLastReadFirstWriteLatency {
	shape_accel {
		img {Type I LastRead 10 FirstWrite -1}
		scores {Type O LastRead -1 FirstWrite 6}
		pred_class {Type O LastRead -1 FirstWrite 12}
		p_ZL7W_CONV1_4 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_0 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_1 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_2 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_3 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_5 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_6 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_7 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_8 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_4 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_13 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_0 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_1 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_2 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_3 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_5 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_6 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_7 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_8 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_9 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_10 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_11 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_12 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_14 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_15 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_16 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_17 {Type I LastRead -1 FirstWrite -1}
		W_FC {Type I LastRead -1 FirstWrite -1}}
	shape_accel_Pipeline_VITIS_LOOP_21_1_VITIS_LOOP_22_2 {
		x_in {Type O LastRead -1 FirstWrite 12}
		x_in_1 {Type O LastRead -1 FirstWrite 12}
		x_in_2 {Type O LastRead -1 FirstWrite 12}
		x_in_3 {Type O LastRead -1 FirstWrite 12}
		x_in_4 {Type O LastRead -1 FirstWrite 12}
		x_in_5 {Type O LastRead -1 FirstWrite 12}
		x_in_6 {Type O LastRead -1 FirstWrite 12}
		x_in_7 {Type O LastRead -1 FirstWrite 12}
		x_in_8 {Type O LastRead -1 FirstWrite 12}
		img {Type I LastRead 10 FirstWrite -1}}
	shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5 {
		x_in {Type I LastRead 12 FirstWrite -1}
		x_in_1 {Type I LastRead 12 FirstWrite -1}
		x_in_2 {Type I LastRead 12 FirstWrite -1}
		x_in_3 {Type I LastRead 12 FirstWrite -1}
		x_in_4 {Type I LastRead 12 FirstWrite -1}
		x_in_5 {Type I LastRead 12 FirstWrite -1}
		x_in_6 {Type I LastRead 12 FirstWrite -1}
		x_in_7 {Type I LastRead 12 FirstWrite -1}
		x_in_8 {Type I LastRead 12 FirstWrite -1}
		c1 {Type O LastRead -1 FirstWrite 24}
		c1_1 {Type O LastRead -1 FirstWrite 24}
		p_ZL7W_CONV1_4 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_0 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_1 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_2 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_3 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_5 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_6 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_7 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV1_8 {Type I LastRead -1 FirstWrite -1}}
	shape_accel_Pipeline_VITIS_LOOP_51_8_VITIS_LOOP_52_9_VITIS_LOOP_53_10 {
		c1 {Type I LastRead 9 FirstWrite -1}
		c1_1 {Type I LastRead 9 FirstWrite -1}
		p1 {Type O LastRead -1 FirstWrite 10}
		p1_1 {Type O LastRead -1 FirstWrite 10}
		p1_2 {Type O LastRead -1 FirstWrite 10}
		p1_3 {Type O LastRead -1 FirstWrite 10}
		p1_4 {Type O LastRead -1 FirstWrite 10}
		p1_5 {Type O LastRead -1 FirstWrite 10}
		p1_6 {Type O LastRead -1 FirstWrite 10}
		p1_7 {Type O LastRead -1 FirstWrite 10}
		p1_8 {Type O LastRead -1 FirstWrite 10}
		p1_9 {Type O LastRead -1 FirstWrite 10}
		p1_10 {Type O LastRead -1 FirstWrite 10}
		p1_11 {Type O LastRead -1 FirstWrite 10}
		p1_12 {Type O LastRead -1 FirstWrite 10}
		p1_13 {Type O LastRead -1 FirstWrite 10}
		p1_14 {Type O LastRead -1 FirstWrite 10}
		p1_15 {Type O LastRead -1 FirstWrite 10}
		p1_16 {Type O LastRead -1 FirstWrite 10}
		p1_17 {Type O LastRead -1 FirstWrite 10}
		p1_18 {Type O LastRead -1 FirstWrite 10}
		p1_19 {Type O LastRead -1 FirstWrite 10}
		p1_20 {Type O LastRead -1 FirstWrite 10}
		p1_21 {Type O LastRead -1 FirstWrite 10}
		p1_22 {Type O LastRead -1 FirstWrite 10}
		p1_23 {Type O LastRead -1 FirstWrite 10}
		p1_24 {Type O LastRead -1 FirstWrite 10}
		p1_25 {Type O LastRead -1 FirstWrite 10}
		p1_26 {Type O LastRead -1 FirstWrite 10}
		p1_27 {Type O LastRead -1 FirstWrite 10}
		p1_28 {Type O LastRead -1 FirstWrite 10}
		p1_29 {Type O LastRead -1 FirstWrite 10}
		p1_30 {Type O LastRead -1 FirstWrite 10}
		p1_31 {Type O LastRead -1 FirstWrite 10}
		p1_32 {Type O LastRead -1 FirstWrite 10}
		p1_33 {Type O LastRead -1 FirstWrite 10}
		p1_34 {Type O LastRead -1 FirstWrite 10}
		p1_35 {Type O LastRead -1 FirstWrite 10}}
	shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13 {
		c2 {Type O LastRead -1 FirstWrite 49}
		c2_1 {Type O LastRead -1 FirstWrite 49}
		p1 {Type I LastRead 11 FirstWrite -1}
		p1_1 {Type I LastRead 11 FirstWrite -1}
		p1_2 {Type I LastRead 11 FirstWrite -1}
		p1_3 {Type I LastRead 11 FirstWrite -1}
		p1_4 {Type I LastRead 11 FirstWrite -1}
		p1_5 {Type I LastRead 11 FirstWrite -1}
		p1_6 {Type I LastRead 11 FirstWrite -1}
		p1_7 {Type I LastRead 11 FirstWrite -1}
		p1_8 {Type I LastRead 11 FirstWrite -1}
		p1_9 {Type I LastRead 11 FirstWrite -1}
		p1_10 {Type I LastRead 11 FirstWrite -1}
		p1_11 {Type I LastRead 11 FirstWrite -1}
		p1_12 {Type I LastRead 11 FirstWrite -1}
		p1_13 {Type I LastRead 11 FirstWrite -1}
		p1_14 {Type I LastRead 11 FirstWrite -1}
		p1_15 {Type I LastRead 11 FirstWrite -1}
		p1_16 {Type I LastRead 11 FirstWrite -1}
		p1_17 {Type I LastRead 11 FirstWrite -1}
		p1_18 {Type I LastRead 11 FirstWrite -1}
		p1_19 {Type I LastRead 11 FirstWrite -1}
		p1_20 {Type I LastRead 11 FirstWrite -1}
		p1_21 {Type I LastRead 11 FirstWrite -1}
		p1_22 {Type I LastRead 11 FirstWrite -1}
		p1_23 {Type I LastRead 11 FirstWrite -1}
		p1_24 {Type I LastRead 11 FirstWrite -1}
		p1_25 {Type I LastRead 11 FirstWrite -1}
		p1_26 {Type I LastRead 11 FirstWrite -1}
		p1_27 {Type I LastRead 11 FirstWrite -1}
		p1_28 {Type I LastRead 11 FirstWrite -1}
		p1_29 {Type I LastRead 11 FirstWrite -1}
		p1_30 {Type I LastRead 11 FirstWrite -1}
		p1_31 {Type I LastRead 11 FirstWrite -1}
		p1_32 {Type I LastRead 11 FirstWrite -1}
		p1_33 {Type I LastRead 11 FirstWrite -1}
		p1_34 {Type I LastRead 11 FirstWrite -1}
		p1_35 {Type I LastRead 11 FirstWrite -1}
		p_ZL7W_CONV2_4 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_13 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_0 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_1 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_2 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_3 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_5 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_6 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_7 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_8 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_9 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_10 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_11 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_12 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_14 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_15 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_16 {Type I LastRead -1 FirstWrite -1}
		p_ZL7W_CONV2_17 {Type I LastRead -1 FirstWrite -1}}
	shape_accel_Pipeline_VITIS_LOOP_87_17_VITIS_LOOP_88_18_VITIS_LOOP_89_19 {
		c2 {Type I LastRead 3 FirstWrite -1}
		c2_1 {Type I LastRead 3 FirstWrite -1}
		p2 {Type O LastRead -1 FirstWrite 4}}
	shape_accel_Pipeline_VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VITIS {
		p2 {Type I LastRead 2 FirstWrite -1}
		scores {Type O LastRead -1 FirstWrite 6}
		best_cls_11_out {Type O LastRead -1 FirstWrite 6}
		W_FC {Type I LastRead -1 FirstWrite -1}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "10876", "Max" : "10876"}
	, {"Name" : "Interval", "Min" : "10877", "Max" : "10877"}
]}

set PipelineEnableSignalInfo {[
]}

set Spec2ImplPortList { 
}

set maxi_interface_dict [dict create]

# RTL port scheduling information:
set fifoSchedulingInfoList { 
}

# RTL bus port read request latency information:
set busReadReqLatencyList { 
}

# RTL bus port write response latency information:
set busWriteResLatencyList { 
}

# RTL array port load latency information:
set memoryLoadLatencyList { 
}
