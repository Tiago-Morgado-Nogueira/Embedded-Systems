set SynModuleInfo {
  {SRCNAME shape_accel_Pipeline_VITIS_LOOP_21_1_VITIS_LOOP_22_2 MODELNAME shape_accel_Pipeline_VITIS_LOOP_21_1_VITIS_LOOP_22_2 RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_21_1_VITIS_LOOP_22_2
    SUBMODULES {
      {MODELNAME shape_accel_mul_20ns_22ns_41_1_1 RTLNAME shape_accel_mul_20ns_22ns_41_1_1 BINDTYPE op TYPE mul IMPL auto LATENCY 0 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_mul_6ns_8ns_13_1_1 RTLNAME shape_accel_mul_6ns_8ns_13_1_1 BINDTYPE op TYPE mul IMPL auto LATENCY 0 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_urem_6ns_3ns_2_10_1 RTLNAME shape_accel_urem_6ns_3ns_2_10_1 BINDTYPE op TYPE urem IMPL auto LATENCY 9 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_mac_muladd_5ns_4ns_5ns_7_4_1 RTLNAME shape_accel_mac_muladd_5ns_4ns_5ns_7_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_flow_control_loop_pipe_sequential_init RTLNAME shape_accel_flow_control_loop_pipe_sequential_init BINDTYPE interface TYPE internal_upc_flow_control INSTNAME shape_accel_flow_control_loop_pipe_sequential_init_U}
    }
  }
  {SRCNAME shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5 MODELNAME shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5 RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5
    SUBMODULES {
      {MODELNAME shape_accel_mul_64ns_66ns_129_5_1 RTLNAME shape_accel_mul_64ns_66ns_129_5_1 BINDTYPE op TYPE mul IMPL auto LATENCY 4 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_sparsemux_7_2_13_1_1 RTLNAME shape_accel_sparsemux_7_2_13_1_1 BINDTYPE op TYPE sparsemux IMPL onehotencoding_realdef}
      {MODELNAME shape_accel_mul_5ns_5ns_7_1_1 RTLNAME shape_accel_mul_5ns_5ns_7_1_1 BINDTYPE op TYPE mul IMPL auto LATENCY 0 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_mul_7s_5ns_7_1_1 RTLNAME shape_accel_mul_7s_5ns_7_1_1 BINDTYPE op TYPE mul IMPL auto LATENCY 0 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_mul_13ns_9ns_21_1_1 RTLNAME shape_accel_mul_13ns_9ns_21_1_1 BINDTYPE op TYPE mul IMPL auto LATENCY 0 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_mac_muladd_13ns_10ns_21ns_22_4_1 RTLNAME shape_accel_mac_muladd_13ns_10ns_21ns_22_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_13ns_9ns_22ns_23_4_1 RTLNAME shape_accel_mac_muladd_13ns_9ns_22ns_23_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_13ns_10ns_23ns_24_4_1 RTLNAME shape_accel_mac_muladd_13ns_10ns_23ns_24_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_13ns_9ns_24s_24_4_1 RTLNAME shape_accel_mac_muladd_13ns_9ns_24s_24_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_13ns_10ns_24s_24_4_1 RTLNAME shape_accel_mac_muladd_13ns_10ns_24s_24_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_13ns_10s_24ns_25_4_1 RTLNAME shape_accel_mac_muladd_13ns_10s_24ns_25_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_13ns_10ns_25s_26_4_1 RTLNAME shape_accel_mac_muladd_13ns_10ns_25s_26_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_13ns_10ns_26s_26_4_1 RTLNAME shape_accel_mac_muladd_13ns_10ns_26s_26_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Cbkb RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Cbkb BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Ccud RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Ccud BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_CdEe RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_CdEe BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_CeOg RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_CeOg BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_CfYi RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_CfYi BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Cg8j RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Cg8j BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Chbi RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Chbi BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Cibs RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Cibs BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_CjbC RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_CjbC BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
    }
  }
  {SRCNAME shape_accel_Pipeline_VITIS_LOOP_51_8_VITIS_LOOP_52_9_VITIS_LOOP_53_10 MODELNAME shape_accel_Pipeline_VITIS_LOOP_51_8_VITIS_LOOP_52_9_VITIS_LOOP_53_10 RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_51_8_VITIS_LOOP_52_9_VITIS_LOOP_53_10
    SUBMODULES {
      {MODELNAME shape_accel_urem_5ns_3ns_2_9_1 RTLNAME shape_accel_urem_5ns_3ns_2_9_1 BINDTYPE op TYPE urem IMPL auto LATENCY 8 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_mul_5ns_7ns_11_1_1 RTLNAME shape_accel_mul_5ns_7ns_11_1_1 BINDTYPE op TYPE mul IMPL auto LATENCY 0 ALLOW_PRAGMA 1}
    }
  }
  {SRCNAME shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13 MODELNAME shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13 RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13
    SUBMODULES {
      {MODELNAME shape_accel_sparsemux_7_2_16_1_1 RTLNAME shape_accel_sparsemux_7_2_16_1_1 BINDTYPE op TYPE sparsemux IMPL onehotencoding_realdef}
      {MODELNAME shape_accel_mul_16s_11s_26_1_1 RTLNAME shape_accel_mul_16s_11s_26_1_1 BINDTYPE op TYPE mul IMPL auto LATENCY 0 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_mac_muladd_16s_11s_26s_27_4_1 RTLNAME shape_accel_mac_muladd_16s_11s_26s_27_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_16s_11s_27s_28_4_1 RTLNAME shape_accel_mac_muladd_16s_11s_27s_28_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_16s_11s_28s_28_4_1 RTLNAME shape_accel_mac_muladd_16s_11s_28s_28_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_16s_10s_28s_28_4_1 RTLNAME shape_accel_mac_muladd_16s_10s_28s_28_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_16s_11s_28s_29_4_1 RTLNAME shape_accel_mac_muladd_16s_11s_28s_29_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_16s_11s_29s_29_4_1 RTLNAME shape_accel_mac_muladd_16s_11s_29s_29_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_16s_11s_29s_30_4_1 RTLNAME shape_accel_mac_muladd_16s_11s_29s_30_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_16s_11s_30s_30_4_1 RTLNAME shape_accel_mac_muladd_16s_11s_30s_30_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_16s_10s_30s_30_4_1 RTLNAME shape_accel_mac_muladd_16s_10s_30s_30_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_16s_12s_30s_30_4_1 RTLNAME shape_accel_mac_muladd_16s_12s_30s_30_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_16s_11s_30s_31_4_1 RTLNAME shape_accel_mac_muladd_16s_11s_30s_31_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_16s_10s_31s_31_4_1 RTLNAME shape_accel_mac_muladd_16s_10s_31s_31_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_16s_11s_31s_31_4_1 RTLNAME shape_accel_mac_muladd_16s_11s_31s_31_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_mac_muladd_16s_12s_31s_31_4_1 RTLNAME shape_accel_mac_muladd_16s_12s_31s_31_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7kbM RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7kbM BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7lbW RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7lbW BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7mb6 RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7mb6 BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7ncg RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7ncg BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7ocq RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7ocq BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7pcA RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7pcA BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7qcK RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7qcK BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7rcU RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7rcU BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7sc4 RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7sc4 BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7tde RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7tde BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7udo RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7udo BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7vdy RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7vdy BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7wdI RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7wdI BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7xdS RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7xdS BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7yd2 RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7yd2 BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7zec RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7zec BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7Aem RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7Aem BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7Bew RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7Bew BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
    }
  }
  {SRCNAME shape_accel_Pipeline_VITIS_LOOP_87_17_VITIS_LOOP_88_18_VITIS_LOOP_89_19 MODELNAME shape_accel_Pipeline_VITIS_LOOP_87_17_VITIS_LOOP_88_18_VITIS_LOOP_89_19 RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_87_17_VITIS_LOOP_88_18_VITIS_LOOP_89_19}
  {SRCNAME shape_accel_Pipeline_VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VITIS MODELNAME shape_accel_Pipeline_VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VITIS RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VITIS
    SUBMODULES {
      {MODELNAME shape_accel_mac_muladd_16s_13s_32s_32_4_1 RTLNAME shape_accel_mac_muladd_16s_13s_32s_32_4_1 BINDTYPE op TYPE all IMPL dsp_slice LATENCY 3}
      {MODELNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VICeG RTLNAME shape_accel_shape_accel_Pipeline_VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VICeG BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
    }
  }
  {SRCNAME shape_accel MODELNAME shape_accel RTLNAME shape_accel IS_TOP 1
    SUBMODULES {
      {MODELNAME shape_accel_x_in_RAM_AUTO_1R1W RTLNAME shape_accel_x_in_RAM_AUTO_1R1W BINDTYPE storage TYPE ram IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_c1_RAM_AUTO_1R1W RTLNAME shape_accel_c1_RAM_AUTO_1R1W BINDTYPE storage TYPE ram IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_p1_RAM_AUTO_1R1W RTLNAME shape_accel_p1_RAM_AUTO_1R1W BINDTYPE storage TYPE ram IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_c2_RAM_AUTO_1R1W RTLNAME shape_accel_c2_RAM_AUTO_1R1W BINDTYPE storage TYPE ram IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_p2_RAM_AUTO_1R1W RTLNAME shape_accel_p2_RAM_AUTO_1R1W BINDTYPE storage TYPE ram IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME shape_accel_CTRL_s_axi RTLNAME shape_accel_CTRL_s_axi BINDTYPE interface TYPE interface_s_axilite}
    }
  }
}
