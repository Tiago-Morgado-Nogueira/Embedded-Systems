# Inferred from performance & pipeline pragmas/directives
set_directive_loop_flatten shape_accel/VITIS_LOOP_22_2
set_directive_array_partition shape_accel/W_CONV1 -dim=1 -type=cyclic -factor=9 W_CONV1
set_directive_array_partition shape_accel/x_in -dim=1 -type=cyclic -factor=3 x_in
set_directive_loop_flatten shape_accel/VITIS_LOOP_31_5
set_directive_array_partition shape_accel/c1 -dim=3 -type=cyclic -factor=2 c1
set_directive_loop_flatten shape_accel/VITIS_LOOP_53_10
set_directive_array_partition shape_accel/W_CONV2 -dim=1 -type=cyclic -factor=18 W_CONV2
set_directive_array_partition shape_accel/p1 -dim=1 -type=complete p1
set_directive_loop_flatten shape_accel/VITIS_LOOP_65_13
set_directive_array_partition shape_accel/c2 -dim=3 -type=cyclic -factor=2 c2
set_directive_loop_flatten shape_accel/VITIS_LOOP_89_19
set_directive_loop_flatten shape_accel/VITIS_LOOP_106_23
