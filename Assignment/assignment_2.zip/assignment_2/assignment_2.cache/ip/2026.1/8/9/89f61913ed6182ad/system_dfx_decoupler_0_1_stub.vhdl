-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2026.1 (lin64) Build 6511674 Tue Jun 16 11:01:26 MDT 2026
-- Date        : Sat Nov 21 15:49:00 2026
-- Host        : diogo-azevedo-Legion-Pro-7-16IAX10H running 64-bit Ubuntu 26.04.1 LTS
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ system_dfx_decoupler_0_1_stub.vhdl
-- Design      : system_dfx_decoupler_0_1
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    s_intf_0_ARVALID : in STD_LOGIC;
    rp_intf_0_ARVALID : out STD_LOGIC;
    s_intf_0_ARREADY : out STD_LOGIC;
    rp_intf_0_ARREADY : in STD_LOGIC;
    s_intf_0_AWVALID : in STD_LOGIC;
    rp_intf_0_AWVALID : out STD_LOGIC;
    s_intf_0_AWREADY : out STD_LOGIC;
    rp_intf_0_AWREADY : in STD_LOGIC;
    s_intf_0_BVALID : out STD_LOGIC;
    rp_intf_0_BVALID : in STD_LOGIC;
    s_intf_0_BREADY : in STD_LOGIC;
    rp_intf_0_BREADY : out STD_LOGIC;
    s_intf_0_RVALID : out STD_LOGIC;
    rp_intf_0_RVALID : in STD_LOGIC;
    s_intf_0_RREADY : in STD_LOGIC;
    rp_intf_0_RREADY : out STD_LOGIC;
    s_intf_0_WVALID : in STD_LOGIC;
    rp_intf_0_WVALID : out STD_LOGIC;
    s_intf_0_WREADY : out STD_LOGIC;
    rp_intf_0_WREADY : in STD_LOGIC;
    s_intf_0_AWADDR : in STD_LOGIC_VECTOR ( 30 downto 0 );
    rp_intf_0_AWADDR : out STD_LOGIC_VECTOR ( 30 downto 0 );
    s_intf_0_WDATA : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rp_intf_0_WDATA : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s_intf_0_WSTRB : in STD_LOGIC_VECTOR ( 3 downto 0 );
    rp_intf_0_WSTRB : out STD_LOGIC_VECTOR ( 3 downto 0 );
    s_intf_0_BRESP : out STD_LOGIC_VECTOR ( 1 downto 0 );
    rp_intf_0_BRESP : in STD_LOGIC_VECTOR ( 1 downto 0 );
    s_intf_0_ARADDR : in STD_LOGIC_VECTOR ( 30 downto 0 );
    rp_intf_0_ARADDR : out STD_LOGIC_VECTOR ( 30 downto 0 );
    s_intf_0_RDATA : out STD_LOGIC_VECTOR ( 31 downto 0 );
    rp_intf_0_RDATA : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s_intf_0_RRESP : out STD_LOGIC_VECTOR ( 1 downto 0 );
    rp_intf_0_RRESP : in STD_LOGIC_VECTOR ( 1 downto 0 );
    intf_0_aclk : in STD_LOGIC;
    intf_0_arstn : in STD_LOGIC;
    decouple : in STD_LOGIC;
    decouple_status : out STD_LOGIC
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "system_dfx_decoupler_0_1,dfx_decoupler_system_dfx_decoupler_0_1,{}";
  attribute core_generation_info : string;
  attribute core_generation_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "system_dfx_decoupler_0_1,dfx_decoupler_system_dfx_decoupler_0_1,{x_ipProduct=Vivado 2026.1,x_ipVendor=xilinx.com,x_ipLibrary=ip,x_ipName=dfx_decoupler,x_ipVersion=1.0,x_ipCoreRevision=15,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,C_XDEVICEFAMILY=zynq}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "s_intf_0_ARVALID,rp_intf_0_ARVALID,s_intf_0_ARREADY,rp_intf_0_ARREADY,s_intf_0_AWVALID,rp_intf_0_AWVALID,s_intf_0_AWREADY,rp_intf_0_AWREADY,s_intf_0_BVALID,rp_intf_0_BVALID,s_intf_0_BREADY,rp_intf_0_BREADY,s_intf_0_RVALID,rp_intf_0_RVALID,s_intf_0_RREADY,rp_intf_0_RREADY,s_intf_0_WVALID,rp_intf_0_WVALID,s_intf_0_WREADY,rp_intf_0_WREADY,s_intf_0_AWADDR[30:0],rp_intf_0_AWADDR[30:0],s_intf_0_WDATA[31:0],rp_intf_0_WDATA[31:0],s_intf_0_WSTRB[3:0],rp_intf_0_WSTRB[3:0],s_intf_0_BRESP[1:0],rp_intf_0_BRESP[1:0],s_intf_0_ARADDR[30:0],rp_intf_0_ARADDR[30:0],s_intf_0_RDATA[31:0],rp_intf_0_RDATA[31:0],s_intf_0_RRESP[1:0],rp_intf_0_RRESP[1:0],intf_0_aclk,intf_0_arstn,decouple,decouple_status";
  attribute x_interface_info : string;
  attribute x_interface_info of s_intf_0_ARVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 ARVALID";
  attribute x_interface_mode : string;
  attribute x_interface_mode of s_intf_0_ARVALID : signal is "slave s_intf_0";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of s_intf_0_ARVALID : signal is "XIL_INTERFACENAME s_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE";
  attribute x_interface_info of rp_intf_0_ARVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 ARVALID";
  attribute x_interface_mode of rp_intf_0_ARVALID : signal is "master rp_intf_0";
  attribute x_interface_parameter of rp_intf_0_ARVALID : signal is "XIL_INTERFACENAME rp_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE";
  attribute x_interface_info of s_intf_0_ARREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 ARREADY";
  attribute x_interface_info of rp_intf_0_ARREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 ARREADY";
  attribute x_interface_info of s_intf_0_AWVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 AWVALID";
  attribute x_interface_info of rp_intf_0_AWVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 AWVALID";
  attribute x_interface_info of s_intf_0_AWREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 AWREADY";
  attribute x_interface_info of rp_intf_0_AWREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 AWREADY";
  attribute x_interface_info of s_intf_0_BVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 BVALID";
  attribute x_interface_info of rp_intf_0_BVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 BVALID";
  attribute x_interface_info of s_intf_0_BREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 BREADY";
  attribute x_interface_info of rp_intf_0_BREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 BREADY";
  attribute x_interface_info of s_intf_0_RVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 RVALID";
  attribute x_interface_info of rp_intf_0_RVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 RVALID";
  attribute x_interface_info of s_intf_0_RREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 RREADY";
  attribute x_interface_info of rp_intf_0_RREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 RREADY";
  attribute x_interface_info of s_intf_0_WVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 WVALID";
  attribute x_interface_info of rp_intf_0_WVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 WVALID";
  attribute x_interface_info of s_intf_0_WREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 WREADY";
  attribute x_interface_info of rp_intf_0_WREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 WREADY";
  attribute x_interface_info of s_intf_0_AWADDR : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 AWADDR";
  attribute x_interface_info of rp_intf_0_AWADDR : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 AWADDR";
  attribute x_interface_info of s_intf_0_WDATA : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 WDATA";
  attribute x_interface_info of rp_intf_0_WDATA : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 WDATA";
  attribute x_interface_info of s_intf_0_WSTRB : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 WSTRB";
  attribute x_interface_info of rp_intf_0_WSTRB : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 WSTRB";
  attribute x_interface_info of s_intf_0_BRESP : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 BRESP";
  attribute x_interface_info of rp_intf_0_BRESP : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 BRESP";
  attribute x_interface_info of s_intf_0_ARADDR : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 ARADDR";
  attribute x_interface_info of rp_intf_0_ARADDR : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 ARADDR";
  attribute x_interface_info of s_intf_0_RDATA : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 RDATA";
  attribute x_interface_info of rp_intf_0_RDATA : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 RDATA";
  attribute x_interface_info of s_intf_0_RRESP : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 RRESP";
  attribute x_interface_info of rp_intf_0_RRESP : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 RRESP";
  attribute x_interface_info of intf_0_aclk : signal is "xilinx.com:signal:clock:1.0 intf_0_aclk_CLOCK CLK";
  attribute x_interface_mode of intf_0_aclk : signal is "slave intf_0_aclk_CLOCK";
  attribute x_interface_parameter of intf_0_aclk : signal is "XIL_INTERFACENAME intf_0_aclk_CLOCK, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, ASSOCIATED_BUSIF s_intf_0:rp_intf_0, ASSOCIATED_RESET intf_0_arstn, INSERT_VIP 0";
  attribute x_interface_info of intf_0_arstn : signal is "xilinx.com:signal:reset:1.0 intf_0_arstn RST";
  attribute x_interface_mode of intf_0_arstn : signal is "slave intf_0_arstn";
  attribute x_interface_parameter of intf_0_arstn : signal is "XIL_INTERFACENAME intf_0_arstn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_core_info : string;
  attribute x_core_info of stub : architecture is "dfx_decoupler_system_dfx_decoupler_0_1,Vivado 2026.1";
begin
end;
