// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (lin64) Build 6511674 Tue Jun 16 11:01:26 MDT 2026
// Date        : Sat Nov 21 15:49:00 2026
// Host        : diogo-azevedo-Legion-Pro-7-16IAX10H running 64-bit Ubuntu 26.04.1 LTS
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ system_dfx_decoupler_0_1_stub.v
// Design      : system_dfx_decoupler_0_1
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "system_dfx_decoupler_0_1,dfx_decoupler_system_dfx_decoupler_0_1,{}" *) (* core_generation_info = "system_dfx_decoupler_0_1,dfx_decoupler_system_dfx_decoupler_0_1,{x_ipProduct=Vivado 2026.1,x_ipVendor=xilinx.com,x_ipLibrary=ip,x_ipName=dfx_decoupler,x_ipVersion=1.0,x_ipCoreRevision=15,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,C_XDEVICEFAMILY=zynq}" *) (* downgradeipidentifiedwarnings = "yes" *) 
(* x_core_info = "dfx_decoupler_system_dfx_decoupler_0_1,Vivado 2026.1" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(s_intf_0_ARVALID, rp_intf_0_ARVALID, 
  s_intf_0_ARREADY, rp_intf_0_ARREADY, s_intf_0_AWVALID, rp_intf_0_AWVALID, 
  s_intf_0_AWREADY, rp_intf_0_AWREADY, s_intf_0_BVALID, rp_intf_0_BVALID, s_intf_0_BREADY, 
  rp_intf_0_BREADY, s_intf_0_RVALID, rp_intf_0_RVALID, s_intf_0_RREADY, rp_intf_0_RREADY, 
  s_intf_0_WVALID, rp_intf_0_WVALID, s_intf_0_WREADY, rp_intf_0_WREADY, s_intf_0_AWADDR, 
  rp_intf_0_AWADDR, s_intf_0_WDATA, rp_intf_0_WDATA, s_intf_0_WSTRB, rp_intf_0_WSTRB, 
  s_intf_0_BRESP, rp_intf_0_BRESP, s_intf_0_ARADDR, rp_intf_0_ARADDR, s_intf_0_RDATA, 
  rp_intf_0_RDATA, s_intf_0_RRESP, rp_intf_0_RRESP, intf_0_aclk, intf_0_arstn, decouple, 
  decouple_status)
/* synthesis syn_black_box black_box_pad_pin="s_intf_0_ARVALID,rp_intf_0_ARVALID,s_intf_0_ARREADY,rp_intf_0_ARREADY,s_intf_0_AWVALID,rp_intf_0_AWVALID,s_intf_0_AWREADY,rp_intf_0_AWREADY,s_intf_0_BVALID,rp_intf_0_BVALID,s_intf_0_BREADY,rp_intf_0_BREADY,s_intf_0_RVALID,rp_intf_0_RVALID,s_intf_0_RREADY,rp_intf_0_RREADY,s_intf_0_WVALID,rp_intf_0_WVALID,s_intf_0_WREADY,rp_intf_0_WREADY,s_intf_0_AWADDR[30:0],rp_intf_0_AWADDR[30:0],s_intf_0_WDATA[31:0],rp_intf_0_WDATA[31:0],s_intf_0_WSTRB[3:0],rp_intf_0_WSTRB[3:0],s_intf_0_BRESP[1:0],rp_intf_0_BRESP[1:0],s_intf_0_ARADDR[30:0],rp_intf_0_ARADDR[30:0],s_intf_0_RDATA[31:0],rp_intf_0_RDATA[31:0],s_intf_0_RRESP[1:0],rp_intf_0_RRESP[1:0],intf_0_aclk,intf_0_arstn,decouple,decouple_status" */;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 ARVALID" *) (* x_interface_mode = "slave s_intf_0" *) (* x_interface_parameter = "XIL_INTERFACENAME s_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE" *) input s_intf_0_ARVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 ARVALID" *) (* x_interface_mode = "master rp_intf_0" *) (* x_interface_parameter = "XIL_INTERFACENAME rp_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE" *) output rp_intf_0_ARVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 ARREADY" *) output s_intf_0_ARREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 ARREADY" *) input rp_intf_0_ARREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 AWVALID" *) input s_intf_0_AWVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 AWVALID" *) output rp_intf_0_AWVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 AWREADY" *) output s_intf_0_AWREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 AWREADY" *) input rp_intf_0_AWREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 BVALID" *) output s_intf_0_BVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 BVALID" *) input rp_intf_0_BVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 BREADY" *) input s_intf_0_BREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 BREADY" *) output rp_intf_0_BREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 RVALID" *) output s_intf_0_RVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 RVALID" *) input rp_intf_0_RVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 RREADY" *) input s_intf_0_RREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 RREADY" *) output rp_intf_0_RREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 WVALID" *) input s_intf_0_WVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 WVALID" *) output rp_intf_0_WVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 WREADY" *) output s_intf_0_WREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 WREADY" *) input rp_intf_0_WREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 AWADDR" *) input [30:0]s_intf_0_AWADDR;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 AWADDR" *) output [30:0]rp_intf_0_AWADDR;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 WDATA" *) input [31:0]s_intf_0_WDATA;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 WDATA" *) output [31:0]rp_intf_0_WDATA;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 WSTRB" *) input [3:0]s_intf_0_WSTRB;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 WSTRB" *) output [3:0]rp_intf_0_WSTRB;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 BRESP" *) output [1:0]s_intf_0_BRESP;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 BRESP" *) input [1:0]rp_intf_0_BRESP;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 ARADDR" *) input [30:0]s_intf_0_ARADDR;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 ARADDR" *) output [30:0]rp_intf_0_ARADDR;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 RDATA" *) output [31:0]s_intf_0_RDATA;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 RDATA" *) input [31:0]rp_intf_0_RDATA;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 RRESP" *) output [1:0]s_intf_0_RRESP;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 RRESP" *) input [1:0]rp_intf_0_RRESP;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 intf_0_aclk_CLOCK CLK" *) (* x_interface_mode = "slave intf_0_aclk_CLOCK" *) (* x_interface_parameter = "XIL_INTERFACENAME intf_0_aclk_CLOCK, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, ASSOCIATED_BUSIF s_intf_0:rp_intf_0, ASSOCIATED_RESET intf_0_arstn, INSERT_VIP 0" *) input intf_0_aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 intf_0_arstn RST" *) (* x_interface_mode = "slave intf_0_arstn" *) (* x_interface_parameter = "XIL_INTERFACENAME intf_0_arstn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input intf_0_arstn;
  input decouple;
  output decouple_status;
endmodule
