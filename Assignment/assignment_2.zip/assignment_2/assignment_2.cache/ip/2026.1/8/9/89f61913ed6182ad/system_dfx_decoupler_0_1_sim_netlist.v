// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (lin64) Build 6511674 Tue Jun 16 11:01:26 MDT 2026
// Date        : Sat Nov 21 15:49:00 2026
// Host        : diogo-azevedo-Legion-Pro-7-16IAX10H running 64-bit Ubuntu 26.04.1 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ system_dfx_decoupler_0_1_sim_netlist.v
// Design      : system_dfx_decoupler_0_1
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "system_dfx_decoupler_0_1,dfx_decoupler_system_dfx_decoupler_0_1,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dfx_decoupler_system_dfx_decoupler_0_1,Vivado 2026.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (s_intf_0_ARVALID,
    rp_intf_0_ARVALID,
    s_intf_0_ARREADY,
    rp_intf_0_ARREADY,
    s_intf_0_AWVALID,
    rp_intf_0_AWVALID,
    s_intf_0_AWREADY,
    rp_intf_0_AWREADY,
    s_intf_0_BVALID,
    rp_intf_0_BVALID,
    s_intf_0_BREADY,
    rp_intf_0_BREADY,
    s_intf_0_RVALID,
    rp_intf_0_RVALID,
    s_intf_0_RREADY,
    rp_intf_0_RREADY,
    s_intf_0_WVALID,
    rp_intf_0_WVALID,
    s_intf_0_WREADY,
    rp_intf_0_WREADY,
    s_intf_0_AWADDR,
    rp_intf_0_AWADDR,
    s_intf_0_WDATA,
    rp_intf_0_WDATA,
    s_intf_0_WSTRB,
    rp_intf_0_WSTRB,
    s_intf_0_BRESP,
    rp_intf_0_BRESP,
    s_intf_0_ARADDR,
    rp_intf_0_ARADDR,
    s_intf_0_RDATA,
    rp_intf_0_RDATA,
    s_intf_0_RRESP,
    rp_intf_0_RRESP,
    intf_0_aclk,
    intf_0_arstn,
    decouple,
    decouple_status);
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 ARVALID" *) (* x_interface_mode = "slave s_intf_0" *) (* x_interface_parameter = "XIL_INTERFACENAME s_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE" *) input s_intf_0_ARVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 ARVALID" *) (* x_interface_mode = "master rp_intf_0" *) (* x_interface_parameter = "XIL_INTERFACENAME rp_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE" *) output rp_intf_0_ARVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 ARREADY" *) output s_intf_0_ARREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 ARREADY" *) input rp_intf_0_ARREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 AWVALID" *) input s_intf_0_AWVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 AWVALID" *) output rp_intf_0_AWVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 AWREADY" *) output s_intf_0_AWREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 AWREADY" *) input rp_intf_0_AWREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 BVALID" *) output s_intf_0_BVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 BVALID" *) input rp_intf_0_BVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 BREADY" *) input s_intf_0_BREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 BREADY" *) output rp_intf_0_BREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 RVALID" *) output s_intf_0_RVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 RVALID" *) input rp_intf_0_RVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 RREADY" *) input s_intf_0_RREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 RREADY" *) output rp_intf_0_RREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 WVALID" *) input s_intf_0_WVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 WVALID" *) output rp_intf_0_WVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 WREADY" *) output s_intf_0_WREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 WREADY" *) input rp_intf_0_WREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 AWADDR" *) input [30:0]s_intf_0_AWADDR;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 AWADDR" *) output [30:0]rp_intf_0_AWADDR;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 WDATA" *) input [31:0]s_intf_0_WDATA;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 WDATA" *) output [31:0]rp_intf_0_WDATA;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 WSTRB" *) input [3:0]s_intf_0_WSTRB;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 WSTRB" *) output [3:0]rp_intf_0_WSTRB;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 BRESP" *) output [1:0]s_intf_0_BRESP;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 BRESP" *) input [1:0]rp_intf_0_BRESP;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 ARADDR" *) input [30:0]s_intf_0_ARADDR;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 ARADDR" *) output [30:0]rp_intf_0_ARADDR;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 RDATA" *) output [31:0]s_intf_0_RDATA;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 RDATA" *) input [31:0]rp_intf_0_RDATA;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 RRESP" *) output [1:0]s_intf_0_RRESP;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 RRESP" *) input [1:0]rp_intf_0_RRESP;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 intf_0_aclk_CLOCK CLK" *) (* x_interface_mode = "slave intf_0_aclk_CLOCK" *) (* x_interface_parameter = "XIL_INTERFACENAME intf_0_aclk_CLOCK, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, ASSOCIATED_BUSIF s_intf_0:rp_intf_0, ASSOCIATED_RESET intf_0_arstn, INSERT_VIP 0" *) input intf_0_aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 intf_0_arstn RST" *) (* x_interface_mode = "slave intf_0_arstn" *) (* x_interface_parameter = "XIL_INTERFACENAME intf_0_arstn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input intf_0_arstn;
  input decouple;
  output decouple_status;

  wire decouple;
  wire decouple_status;
  wire [30:0]rp_intf_0_ARADDR;
  wire rp_intf_0_ARREADY;
  wire rp_intf_0_ARVALID;
  wire [30:0]rp_intf_0_AWADDR;
  wire rp_intf_0_AWREADY;
  wire rp_intf_0_AWVALID;
  wire rp_intf_0_BREADY;
  wire [1:0]rp_intf_0_BRESP;
  wire rp_intf_0_BVALID;
  wire [31:0]rp_intf_0_RDATA;
  wire rp_intf_0_RREADY;
  wire [1:0]rp_intf_0_RRESP;
  wire rp_intf_0_RVALID;
  wire [31:0]rp_intf_0_WDATA;
  wire rp_intf_0_WREADY;
  wire [3:0]rp_intf_0_WSTRB;
  wire rp_intf_0_WVALID;
  wire [30:0]s_intf_0_ARADDR;
  wire s_intf_0_ARREADY;
  wire s_intf_0_ARVALID;
  wire [30:0]s_intf_0_AWADDR;
  wire s_intf_0_AWREADY;
  wire s_intf_0_AWVALID;
  wire s_intf_0_BREADY;
  wire [1:0]s_intf_0_BRESP;
  wire s_intf_0_BVALID;
  wire [31:0]s_intf_0_RDATA;
  wire s_intf_0_RREADY;
  wire [1:0]s_intf_0_RRESP;
  wire s_intf_0_RVALID;
  wire [31:0]s_intf_0_WDATA;
  wire s_intf_0_WREADY;
  wire [3:0]s_intf_0_WSTRB;
  wire s_intf_0_WVALID;

  (* C_XDEVICEFAMILY = "zynq" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_dfx_decoupler_system_dfx_decoupler_0_1 U0
       (.decouple(decouple),
        .decouple_status(decouple_status),
        .intf_0_aclk(1'b0),
        .intf_0_arstn(1'b0),
        .rp_intf_0_ARADDR(rp_intf_0_ARADDR),
        .rp_intf_0_ARREADY(rp_intf_0_ARREADY),
        .rp_intf_0_ARVALID(rp_intf_0_ARVALID),
        .rp_intf_0_AWADDR(rp_intf_0_AWADDR),
        .rp_intf_0_AWREADY(rp_intf_0_AWREADY),
        .rp_intf_0_AWVALID(rp_intf_0_AWVALID),
        .rp_intf_0_BREADY(rp_intf_0_BREADY),
        .rp_intf_0_BRESP(rp_intf_0_BRESP),
        .rp_intf_0_BVALID(rp_intf_0_BVALID),
        .rp_intf_0_RDATA(rp_intf_0_RDATA),
        .rp_intf_0_RREADY(rp_intf_0_RREADY),
        .rp_intf_0_RRESP(rp_intf_0_RRESP),
        .rp_intf_0_RVALID(rp_intf_0_RVALID),
        .rp_intf_0_WDATA(rp_intf_0_WDATA),
        .rp_intf_0_WREADY(rp_intf_0_WREADY),
        .rp_intf_0_WSTRB(rp_intf_0_WSTRB),
        .rp_intf_0_WVALID(rp_intf_0_WVALID),
        .s_intf_0_ARADDR(s_intf_0_ARADDR),
        .s_intf_0_ARREADY(s_intf_0_ARREADY),
        .s_intf_0_ARVALID(s_intf_0_ARVALID),
        .s_intf_0_AWADDR(s_intf_0_AWADDR),
        .s_intf_0_AWREADY(s_intf_0_AWREADY),
        .s_intf_0_AWVALID(s_intf_0_AWVALID),
        .s_intf_0_BREADY(s_intf_0_BREADY),
        .s_intf_0_BRESP(s_intf_0_BRESP),
        .s_intf_0_BVALID(s_intf_0_BVALID),
        .s_intf_0_RDATA(s_intf_0_RDATA),
        .s_intf_0_RREADY(s_intf_0_RREADY),
        .s_intf_0_RRESP(s_intf_0_RRESP),
        .s_intf_0_RVALID(s_intf_0_RVALID),
        .s_intf_0_WDATA(s_intf_0_WDATA),
        .s_intf_0_WREADY(s_intf_0_WREADY),
        .s_intf_0_WSTRB(s_intf_0_WSTRB),
        .s_intf_0_WVALID(s_intf_0_WVALID));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2014"
`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ldf5+Eel1Xg47b67VCGO7Sn/f72qKUySSTqXHGLUuZMIEDbs8goxQH4jU4WCjayrQJlXUckjGK/R
+xpETivd1XBijlHOq+6pIPdNxud+uxsRiXFv/PdzNxLegGX1Kj+803vDsMZhyEcbEqAfwJ/XsMgx
gBB3b/e5gGbV3FjPatgl7u8g268mjOlSJ+kkpomjHLtQ4Gu3L/cmyf9qcuyuSXneKmTvfORpbdKD
F2KLnH12m21xCjsq1RyhG0/rX/tpSRtK/Cyjf1iBN1+CumcP4BnjhZF7HkN0/5fofc+trTwCugHq
lf092Cse0hMjT6qh6zRp7oOdPO/lo4YOrUsaFw==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
JYsc1i5wADC636qJkhtbbqI30icWri941gSqMjRHc1zAGxG/CxWqes1E6tM5X8S85ZYoCMqqUTCP
zPeYa7aQNirLk409DDiowqJ6IqZQrrY+fBMxexE4af4mFTcMnATbeJB7S3rwotwFuRjuxR1OtFsI
U+JiT0aqHwnIalXbGMgVkVNE1neFFQJ4ZBnrRdzj9e+1B6XJdQNQM6SBY9zmfPppe7wa0YnEgTyH
QGRyr+S4kNHnZaNGTz+0RM1hdPRC3HCjXOAGx1aJin9qks+nKaDyBD9iEacoGE1w3ZEEo37ZetHB
p0RnY3Iknk5a0/ghb1YeXW0NxGfKF6kEMI+etQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="cds_rsa_key", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=64)
`pragma protect key_block
WlaT7VStZV63t0DHLAK7130SPqtmORk3fcjLdtxvo7Zr8Vmf8RaEvpcsRYObgwUmUqVm2/hPKxJO
+gb5wmyLtA==

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YDObQ1NtkfjBlvUYh1vxXDdyFI4c395gslA2Nhvha9xfwbCxrCMC+Y4k3qcOISA8VnP3PtRnlSnk
gqsB5Z+NsTUYpVMwc9bR/xjzv465vByNc0VTPmks9o70hDTl3hTSVaGde5wXmpj23OoPZXXCeJFB
eOrulFJJZvgPwReJV3lqiSpMDZQk3SC43ps+uaG8ijNKNBZR+WjC12wPewpZ8VBZ7Hma6nHEqHW+
5ZR4xr6ue8/TRPL7q4G9HTfnnZ+ZvA6SE7rcmqTlc6Dkssv9CGfP9CCAQefaCaAHA0Awsm+GbusB
6jUiAQCL3UHrJtZ1RAuhk/TuaLwO45uK6dD1Aw==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
LQm8cJQoDLEdpDz42uCYcg02AxUSfKw1bk/grtDTdPuSzYtA9NwhjNJyIayYsCIaWAPtBxYRoip/
tybUgI9T3bbwD2ghc4BLznwa0plIbJkroT7Jrn58u/A2W26vreY2bp1xUZ+QSVZMyZnXNo9V+gLF
ayYkFh3bP6mbHfjwzA6hR4FcoZ2eepttevQF5DMpBLrLnVq/aIBFpwQ49lO68jNmijSgba7Ii7O5
K89AQ7slKWtr2ww3BC0tbqV3EyrBw3sCcw63cUrTmsEqXoBRku/H4GyxQPdJAdHGxYuDgsLFCh1Q
SuZHjhlxsijRsmFnMb0Fc2gajleiVE7C0MTBcA==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
JaH4Inem8lV8ECCJnQGn3skgvDGVe62ipkMWHHBP1li/NSo4EQlLZZiUL9vgkQBmrZ+36laWQaMM
CJnuIT0s3L3LFuo4mVHfooiTSkI4DUH9qY1JrG5kjxsSrUrrsHnxtddQ1+cLfpHI6hMbfxn1/Uwh
MGRFxX8DBuqBkg2zrXA=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
mC30iYh3XPktRMXUAIPhQauehS1OnX+FwBY8y1V9+O8M03GUPlifFt6HlwbZBlU8xApEI7PfOmTD
Wxo5PJIQ8uzfBJzImHSUGAxVym5w4F7A5B4FgkG6AOmZDycXBgE0QeFwBvV5Zddd6qm63Vt6kepz
OSI0urDhDBb/36e1gb+9JKsIHI9qxSWcvwP8Pky+fHrn+nNKQLF3/Bv0njiQX5coTnyuFflprHjh
wx9qx2jy/hqmwnsFAaRJqwtUAfyKY9TW/4cjVt/tLuVxyL9g2BOZvak4SSdO58UjmKfBBBxG1/US
hCIl5Qwlqc5VVeI/0Kv8UUY2jaTfzQkWUspPXg==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
0ibm5urUCFAbXqRlTOQ2X1ugmfvpVMrJXwV1fwuIH6ljvHrT1hKbxyH9X+apdZPsAzy0S6NLBFIX
mG+NMUOKGLZkpKIMGyx+U5BVD2jstq2+1JJ4z37sZUGIBV19IDn3+xnXVZZ9Tkh1z4LrSn/nyd3e
rbQztBLmUQCUPMDDEuqTAZP7R2qP4WFH4rOfmOe0w2+WtVkSeofom3SnI3YBdJ707uOZv0JBwTKk
TeDtpW7sGFHaRoWAQIK/9zTcHZR3gkAJVZKdxYbz2txR/+Gk+Jq5DVkqOtnSV8cMKL2uJDoHmQBG
+vtfs5jfvxdSu9g39cHe3i46F14roUnaEpM3MA==

`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
j+M6szjq7Dpktyj1Fx+ygOR028nRSqdhf0GrkmUbngYnh2jwZLUV9a9D5jfzs6E9iJZ5WkK5MkFt
ZFRvxLWzxwTvotagxsMch8IapGp9U8N1G6hb8BgErPeMxOA3sMjzhTVW667aYdQH83t8LVtKY/FR
k0pWRpkEgdfxJ2phO7o=

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2026.1-2030.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
CZKy7wRvWs9USNSXaYbUkn+cLRCzmixbqtpmXRaKrtVpPBhr3AlT8jO2yswKRl5svnmVAVBAOcw8
NiSfC6AJPyXUjxIIPT/2uVJC3kKf5d9lzg+dMWlP5CT3uo+I7vDPDwVkOT7qjLoiJ+VesOcOl0fr
P+E3qVmejpgM8/dBdSZ8maUV5QrLv/4nRufPppOE2eHSHbIF6Bi4VUWVGIo0dhEm5KiATz8VgKMQ
88yJ9p56YWHnyjysqF3dS4UihNxpRjtVtJkxiM9jC6bG8fWpmlDyHPVEiWbytqXY3tORjtqOWzRp
DqMHOPalje0P+n9Akox1jSWIsty/ZD8PW1L9wA==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 5008)
`pragma protect data_block
lKEvfxypNEoPKxgOfL5TfNm/rmm9+9/CdLT+qMwtvonZY9kBfAPVIVKk/dgAVfJKu++xfgR+NqOY
DpX4blF1VioxB4k0nXfWlPPVj5NzQXSPr6OqDcRVSlhzdhyatvDOSVfgYEME9Ds4mLyytoLYpuof
3i+jKaJXIj3dP8vNFdW4Qi01VDXpyKdXKFjqSuVeDJpwxTRbq3wRpZG23DDk819dQuiT/Ko716N1
zszPr2nXqjJ0uckmJj5w5Z77I8+mZms4PoXEj9k6jv3lfoKBK6rYGYBobtOJopqsG8e0C+XgRfUZ
K28ASX/GoHEl9OBAXKcrx2ZeUcfWU8ZWuFQlz+FZarOlUtzI64ve2yNY1/CttAVL1itBL5/V3odV
OMCwkg/2oxSbyIvId8cuHHfBngHwG5r9MNOh72Bzb6z6la8ZR0Pk2NdHXh1ESTkHY2wwaBYoKEye
jqGaMMCA0e4THBN+zjyqjD5eKr7/MEO9MI0OgrHrABk1yEd6WYsrfljsqXZBA6Evu42lSqRBKRJR
/zOvQWPAWFTn15CYcDe7x/GoUCi17bn01YGGvHStM2V4DU/mW2Fbm7Be6ynKlr0DSWKjDaYb50Xt
uJpAw8CxtbrKW4oqjYEGkIkcIRE9sp0IHi3EUCSHqA/c/NxrLwg4m50R+I+bx/7NtjPW1fwERkeL
Kmyh8Ly9yCBtkSXZQG2ghIUO/msaBJ/UbxfhOUD1HAovz4X+CduiqN+EHPebZ6cKc/noKd4PBzjy
WHO/R3lihHQd2zEF1GxUxwvOtZyWPESmhsTAtFH9OlMHaKnc+YTZzf22XbOAhhPLD65yrccyN6JB
4Bj92onKLzPqxF0onxDiFc2Gqx3/OnGTzwRiD8RD16oqOTvb7IIkh9se6SVsMLFLvXabMRjEj8Pr
AbuYkdPi/4IY6YHRlfP62YyTs0IwOBiBjBNMNrpzeKlgfhcF/sBnxgSsot9NzKJB8cThrt1FmLKt
osnZWhGT12xzlKiyOfqtB1vnJcFHsGJPyZQpWnM5G4V8rdRlEd5Bgf2/QPr1zo3gt9mZfUxA04J5
Ojl45NJT0/ln0H6UyNl6+JBCVjChwEVboAubzpmazP6J7FfFrGfWO6VhLhWZen5UnDaCdCVFibLN
rlgvBqGJXGcbxoE4mePKw4ODdYJzDaf9NA9p9h9v4D+LWwkFxIMt1cUJyn02lCGg5u3QsOqZ7Fg0
pSC6vFsUBSKinBCZ+WwAHps/V09fB4Uuwk4/a37/BJwx1Bg8LTGCZqjCNm8lbCvfIZ3xfwzeMpou
qf7GMqEhkza4hFPRIf+5K9mkb3pOWpi9itHKSWg0h9z/NnZqNQxSxolFQnIft0Z0YfJoS/e/lOvU
umQHMo/AdgWh7z2YOuTmOoY3qjlCmtYhViwuo7JEj8utYS5Mj3RjfMTwJFw8Fiy7ALielhBya56T
Gb2novbAHZVlWCQFEJnBz/0Y5u7u6ToJ/sN6OtuAcqtswshxRYt8+h/nRp2Cr9P4WZFQXQTlugcC
EvHBE0tGgD266qPkG8Os4Epr4NET4JtmAkfpY42D3h31dM3IwsQ/ijOWooO5NjUDwiL8DOH5a63P
n3YeWgCZwWuuHk98/W5cpc9yNIsdiotZtGwtNgcPJQuOem+nul341FPZQDN697NJuIBFYfNY2952
GtSiphs7e5jyet0Ovv9mLWIf+8NtsoQNi1FnYTNgHmX4M3vYO38Wl03TP3aV0T7FWRetO3tKSMgl
Q86a/JDcKg9euWyXQpSK3Tqrn3fOwzNOFSJwt/RoMDw4ASSjzjB6Ly/kw3yVQwTCBqBKer1+bX9F
3GFD8Lv6mm9mOzHEKWGErdGDSX7UHn0+BkUr3Ojog3pRyBQELWw1pZsEVhy8rjoI/yDd52Dve6Qa
pX8ptnzU9aR2m7ayOpyf0zAQB9sQAIoGj+5Ir0nm2t4XFXrTPJ2GASS27G0dbSFSerbAXu0/MzJx
HYcM+0SPQUU6cU1IJ2o9J3zPvfMZ/hkvJ7/FZixa5+ikfXjTVmBbLvKlkd3xY6520zetpLhafpwQ
qQ1Q2YBLVw7sXb+aEQ8X2fd6cAXmhoE+Jlm4TzqK6G71OvD8qh0YtHG5sSUsc/j8rA6wugTqxOTf
ZuKEnhvlhg+ILLfet2FrBBfMTftZ7JuxUYAS0vs4vDM+QHIJ/TQHiv63b4XojBrOPK6zpacAfHGH
k/JYW3ScvL8FzZAT1hepmV8DmHseOMIBzocVc31+OYNfW8wxJ8Ur7fixB3me0mLSqLYfceX5D5pE
TVGIBEdbJpYBAmXlfu/VXtymSbIZfqAPM83ie/xquzq5+FoBexdQa+a4MIemjUPfm68f0yQU8FKP
o0OaJ7MLUrLGHf0fzt6Jc4ODfpkhve9kjRFtQOhVlqT0wNwfAqp3hyU4+DzJyGTpbY/DyzApoYJg
oAcI5kBt8AlzGkEJZvEnqThigWiJ3iH+tAQN6fYN7/p1Pvqwwiuio2vgWNzgFuFwy76zJ9/7J/7j
qJ89l25YvcEZvVZGzUw8ZuEXu+lWd4pfCHAwr+isPe35qno2wcK6nPWNnqiKNDo5A6LiZoWRE0Vk
qn1pf8zcKDGZbPPRHu6jbPiBbim/uOiUwAj3wWqe1k/kbylTBbfSn+n3xTUlzK5RRLqMT0/gjvNO
VZ4zB6Hr7QcLjAYGFIHMtOTZqPRabnk1nEq7vjsI2q6du7U6AysTlhzCGJbvsBw3lTwK1Tu0P3rp
4h4DSfi9+62djHyRN2Sk5nTgRKOw7o5HHzuH0nhFqllQbcm4fgGY/yiK1fbQRoRn1PXGzqpuDiAD
ABQ6vKyOPL3GJjUd23Xb5m0kbYA7tqToE1pOr5dwkpipFLD6PQHMw8XPop3KFMKFRjq7hxCws2Qe
LvmZxB9coAllnVURlGWa0tuyImeskeZi5qfVIitYJNw9cnwht+5S/yympx+Duqt2NjNcVvj8S1jC
p2xOoP9h9t2lPWj8yLVtzA1PO3bIzJ1QX/RGT8CWSSfjBC1zWDDsBh/9WXOMaKmJotkJz0+E1r6g
krePeTUsSZXdKsaqFgDNVT7yFRnzabe6MIY1KgkKbyQeVtQMMWp8oQrxYY/ea24sfIUxxU5+28cQ
IFuy/dubHp1bmIiMrnvn9IqHswuWjYqmYeHZt2n9MzxUtW1tJP16zYDypcrJgeW76FMZ1uUFrPqA
WaWQI91KGXeLP55LZdkOCQ/wpd8FZS43jpon3rPk/F08qlRNTX0Q90sAAMLbT317XWcHdVfuaxo0
pu2o5qeP6WHN/OdBQsjq5FhyG3NxLHS1sYM8l5k6dUGDB1kSNs8V8qOMIcUpDtnMg69wpepg0nFm
SY1TX+wVBpOTo4W/j2TzTugfXmYhDIw0z89v0H/uLpJrjUu0oXBDE4Nw2j6msaeHkc+PvlraZji1
SYz+fpaOJ1xScgLtPT1SknAiA0HMuXPJ3ep3743sYXQeWVMRTY3IQ2r+zCFaEb8in7iyoWgtf7/9
6adP3aMAv1cJDho3iTiXH/XEfXkAS2Wf2DIGIG4zo20XARWzwT+WEbq0t9aLcHvW1Pm8s1GteUXE
g3TMAvSPnyRhnaQ9xZ+tDuCKkWmKRmd3eILBbiTdSbwmIZ8zXFJVDT9wJPtDFhFBegScKzJTNbPz
MVU85s/17b5xBAKVxzvavDn7+T4nTuqn99e4FXucb0+W9vq81ugxBDwzQwDRfR2PfQN2Pow5TwZx
WSbexLv1Ig7JUQgJJQbL/tCEtxZ9qbuFEo9ACckxq+Daxv/aWIhGrXev5xu8hb1D9JuOq1tH+RFN
HfNHTIac2U4Ko6TOnemXf6iryWR4vcbhDTz2biwFx9MNt7R5tkb2Ln6f1xzClK/V2CGPgQ3eLYV4
iW0TIyESefZ8YzlpNDfZ+4DN2Kw+AZEiw1pMe0ZRGa1VgngYOm4MW0zhXQtRPvqcytw2TUBVQ4c/
OkNilMTmwilsnpjU439z047UU64EwXVb/A/2q3WvioxfwwE/C+vkQq2s9oUVTjG8pa73z2NnCUlm
34AP9u93xmzxZXT4UD5EkHgpJUXqBQpFJuEBdBvfuHPEpYttgBxGNSwZD14NU65ywZr8GHKDRKmd
2j9DLPO+ie5SNA4WIF/YFI8behXdnOYmajQxvn09MIP0qJt1Nyux117/4l8SPSGDAUquqwd5uiCQ
yrq7K0EtwbXrXy/+CoICf3a46c842J8fcU7clNrEJYqYuA/oK4VDAI5UuECMAKykS3cmJm7knR8U
pmDOZGklsMDBFqb1ISEeG/VxBck4eY7x9Ulg2L1tftz5whvjmR9sAvfVj8lq5fQrmjj/n+N4+lWr
UqhDPRyIONu7hagOPVcSrWLch7t1oiGF/LJkfX7x9HVe0SxJVN7a9S7U/frbe1QuGAdhhdL1T9c0
RVav7OpOEYaSXdgURHJCRMkWcvhTxA5TbRByFmbtkKuz8XfK7eNy/+nJ1kyLkg5CKvQAMZ607HQZ
uPErVWjHBTAxP3Jo6yTLHshKrvJNsBAL5RY5WQ0mMQVoF0MjPJdci1f3eR4BpqyQEvqrFPjEGqf+
GynuBlVxUc4fJrLVkwTg1cy8pRJt3M0rY1WykRk2oyVpWNVXCAMeuSFkcistDF5Y76EPvMky0x4r
AIWnTMu1gs8BKoDHHhYfk5rCOefJ3QNpuSWNyuGgA9jPTjjc9rsPK1bAhkZK7o3ITRr6oNF+MNQR
SsghKKGXedAO35UN/V8grjl/WsM7UzCYA39/hM/KhgL25w/QElJRJvvCNQLshS4iZKvTnsHkW+m/
Kgy5ykwuo4pc50zOaexj6PPpoC2mC1dJfa8JOIgdJG356jBhJcZJBv7Ne9KVNW+XlCHugmVNQttZ
3OhrSrlanc3GOZDiMThH6eXJaOmUrvNOg4MxL6RXMreSji1SkILd18ycAVl3K+CRMN5ZumfVKQWK
eI3uTwIgdzjMQQt0rUH1GGJ/gR6IPYc014f6qFdQ7X0Oo1PyM53CdO9su8bH/2VM0pnrID00l8/+
T5anZJJxK1DHWYgZL9ej8TqwWDXtTnbDcUUO62ETtDrj2hbcy7SDiYafpKVQcFLxxAN55hSbBCQv
jKYd8nokbRc2wASYbt/kyYvDjjk9LqgVRUMMLbk4rarwmnqFpmZoRruesjPFgAwH5kbtu/05xhrU
6h/j/RQfs3tXkVj77JdOi/FH9q4Xt1I0wxrOgiwBofir2c2rnvc/eXxCWg3kbbOS+YuOKSZ3YslT
F79dlqraKAjGLtxmg96DrDt4q3XxkGbC5KzXyUHaY9E3dpnxiNNVMQ/ynzK81DHqP0a5KVDdj8V5
viCBwm0I/cXFOYIH5ndlv1CWY8QV0JBVgEcWc5DI1ul0Fquw73iG6PQWTa2zqe/ZSpmRO8wb8D5C
cjPJG2G3Yvsn63xFkgpOxY1R04ckMLoyw5BRf2btCoEvcmS0nLru8XwUPmU3fsg//T05ifqNNrbm
1PNB44sERXLB47D9cqvloGS2GSvbUHsrpVfGKjKh7nMa/aR+4cj13N1eAzI5Ft2ETEgrci6woP8S
is9KgsimSTJy3ksv3BXjDFO5HifXaWy94O+kVXA07DFEu+uvHiw1FbWpb0Ro8pemNCl/33rr1Cxc
wUFZ1L55GYQX0RDM2Vsuc7C+nkhHB8QiYJyF7J4NHfDPgbvi0b8JThno06wQtYOIJANSRynw0in6
sAgV0axHYNvd7BtkzaUmXe6wzCi5p2lMO0BZL7m8F//qDr//tq9cjWoythlPGuDCHUrMv57wHbdc
MgRr9hJ6jsCl1QdbQlAhss6IPbcxmjDphRjzweIBfvy37dXx2iEv1vkpegYp5fKbpmmuxHl+pGxI
z9CEckHXsTFp1hPJzO9Ytgm1dhQcXF1iXSYEBkVFquV9s3oly+hP8FV0Htw7vZZ6LY49lbD3C4dX
ZkKpnlBq+Bg8aHEzbu2bNG01tfEkIEgbHddQkrEJiDeiEarB9sqq/8NK2YJLxinIpStWe6DP0FnF
gi/KZbUFgRD2uiP59umidHiGPd+chf03swhO9hWW8IcgGtAe2PYXdJNIKIiyaUoJVxQk+Ni43DyX
mlrdwoD1v3kJWakubJ/m7bGzsxUCcm20lX2J2jcDWlRkfoGeVFgPSp3pyqiEaMGTbP88j87jIgK5
UVvvVyeE3qqwoSg6yTz+qo7lzcNWI1ehwz4GGcUBbMWdwuDAadJbwxYeG+t4ZcuVpQDg/KiRjZJM
RnWRwYToHJF14eZfcEtAhBJG5oOeDlju6/H4J/aXp7LaQipsNbmDsmu9BVniM8YmYM+lyeeaQZc7
NjV0qLaEn7uG1ZxY9OawUHkWiJy7UX/xVX2qqZ4yCxtAPD0U/Cxf5kJjp8pcrDIRtBJ/23ZRWe58
OweRkBTZixPfGFaTlqJ2OMUAwvv9nHNBFy71VvZaea7Q66ieotPutLvpH12XoYzYws7ehR6z5FuA
K6J/7PuxanuZWhI/L3GjQ5007tzXUvyEaRHSEMo7EqV2v9IrF6HnJFUkKT9XC6p1lD2LfjDKj1+H
bUczQTQI/0rJm6bYKKqgTsX9tdj3CIIpi5XY5/QV0vScGL/NkuMQwrVXIhyX5E1XuKAzqhvECShx
qfIbU9n1a88jacSGLah89MGxEE7C6EzsGlYtMGQTsqVG30VYaT9O4MLQsHHKctlafQ==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
