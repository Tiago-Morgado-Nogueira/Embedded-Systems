-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2026.1 (lin64) Build 6511674 Tue Jun 16 11:01:26 MDT 2026
-- Date        : Sat Nov 21 15:49:00 2026
-- Host        : diogo-azevedo-Legion-Pro-7-16IAX10H running 64-bit Ubuntu 26.04.1 LTS
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ system_dfx_decoupler_0_1_sim_netlist.vhdl
-- Design      : system_dfx_decoupler_0_1
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
`protect begin_protected
`protect version = 1
`protect encrypt_agent = "XILINX"
`protect encrypt_agent_info = "Xilinx Encryption Tool 2014"
`protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
ldf5+Eel1Xg47b67VCGO7Sn/f72qKUySSTqXHGLUuZMIEDbs8goxQH4jU4WCjayrQJlXUckjGK/R
+xpETivd1XBijlHOq+6pIPdNxud+uxsRiXFv/PdzNxLegGX1Kj+803vDsMZhyEcbEqAfwJ/XsMgx
gBB3b/e5gGbV3FjPatgl7u8g268mjOlSJ+kkpomjHLtQ4Gu3L/cmyf9qcuyuSXneKmTvfORpbdKD
F2KLnH12m21xCjsq1RyhG0/rX/tpSRtK/Cyjf1iBN1+CumcP4BnjhZF7HkN0/5fofc+trTwCugHq
lf092Cse0hMjT6qh6zRp7oOdPO/lo4YOrUsaFw==

`protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`protect key_block
JYsc1i5wADC636qJkhtbbqI30icWri941gSqMjRHc1zAGxG/CxWqes1E6tM5X8S85ZYoCMqqUTCP
zPeYa7aQNirLk409DDiowqJ6IqZQrrY+fBMxexE4af4mFTcMnATbeJB7S3rwotwFuRjuxR1OtFsI
U+JiT0aqHwnIalXbGMgVkVNE1neFFQJ4ZBnrRdzj9e+1B6XJdQNQM6SBY9zmfPppe7wa0YnEgTyH
QGRyr+S4kNHnZaNGTz+0RM1hdPRC3HCjXOAGx1aJin9qks+nKaDyBD9iEacoGE1w3ZEEo37ZetHB
p0RnY3Iknk5a0/ghb1YeXW0NxGfKF6kEMI+etQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

`protect key_keyowner="Cadence Design Systems.", key_keyname="cds_rsa_key", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=64)
`protect key_block
WlaT7VStZV63t0DHLAK7130SPqtmORk3fcjLdtxvo7Zr8Vmf8RaEvpcsRYObgwUmUqVm2/hPKxJO
+gb5wmyLtA==

`protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
YDObQ1NtkfjBlvUYh1vxXDdyFI4c395gslA2Nhvha9xfwbCxrCMC+Y4k3qcOISA8VnP3PtRnlSnk
gqsB5Z+NsTUYpVMwc9bR/xjzv465vByNc0VTPmks9o70hDTl3hTSVaGde5wXmpj23OoPZXXCeJFB
eOrulFJJZvgPwReJV3lqiSpMDZQk3SC43ps+uaG8ijNKNBZR+WjC12wPewpZ8VBZ7Hma6nHEqHW+
5ZR4xr6ue8/TRPL7q4G9HTfnnZ+ZvA6SE7rcmqTlc6Dkssv9CGfP9CCAQefaCaAHA0Awsm+GbusB
6jUiAQCL3UHrJtZ1RAuhk/TuaLwO45uK6dD1Aw==

`protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
LQm8cJQoDLEdpDz42uCYcg02AxUSfKw1bk/grtDTdPuSzYtA9NwhjNJyIayYsCIaWAPtBxYRoip/
tybUgI9T3bbwD2ghc4BLznwa0plIbJkroT7Jrn58u/A2W26vreY2bp1xUZ+QSVZMyZnXNo9V+gLF
ayYkFh3bP6mbHfjwzA6hR4FcoZ2eepttevQF5DMpBLrLnVq/aIBFpwQ49lO68jNmijSgba7Ii7O5
K89AQ7slKWtr2ww3BC0tbqV3EyrBw3sCcw63cUrTmsEqXoBRku/H4GyxQPdJAdHGxYuDgsLFCh1Q
SuZHjhlxsijRsmFnMb0Fc2gajleiVE7C0MTBcA==

`protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`protect key_block
JaH4Inem8lV8ECCJnQGn3skgvDGVe62ipkMWHHBP1li/NSo4EQlLZZiUL9vgkQBmrZ+36laWQaMM
CJnuIT0s3L3LFuo4mVHfooiTSkI4DUH9qY1JrG5kjxsSrUrrsHnxtddQ1+cLfpHI6hMbfxn1/Uwh
MGRFxX8DBuqBkg2zrXA=

`protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
mC30iYh3XPktRMXUAIPhQauehS1OnX+FwBY8y1V9+O8M03GUPlifFt6HlwbZBlU8xApEI7PfOmTD
Wxo5PJIQ8uzfBJzImHSUGAxVym5w4F7A5B4FgkG6AOmZDycXBgE0QeFwBvV5Zddd6qm63Vt6kepz
OSI0urDhDBb/36e1gb+9JKsIHI9qxSWcvwP8Pky+fHrn+nNKQLF3/Bv0njiQX5coTnyuFflprHjh
wx9qx2jy/hqmwnsFAaRJqwtUAfyKY9TW/4cjVt/tLuVxyL9g2BOZvak4SSdO58UjmKfBBBxG1/US
hCIl5Qwlqc5VVeI/0Kv8UUY2jaTfzQkWUspPXg==

`protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
0ibm5urUCFAbXqRlTOQ2X1ugmfvpVMrJXwV1fwuIH6ljvHrT1hKbxyH9X+apdZPsAzy0S6NLBFIX
mG+NMUOKGLZkpKIMGyx+U5BVD2jstq2+1JJ4z37sZUGIBV19IDn3+xnXVZZ9Tkh1z4LrSn/nyd3e
rbQztBLmUQCUPMDDEuqTAZP7R2qP4WFH4rOfmOe0w2+WtVkSeofom3SnI3YBdJ707uOZv0JBwTKk
TeDtpW7sGFHaRoWAQIK/9zTcHZR3gkAJVZKdxYbz2txR/+Gk+Jq5DVkqOtnSV8cMKL2uJDoHmQBG
+vtfs5jfvxdSu9g39cHe3i46F14roUnaEpM3MA==

`protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`protect key_block
j+M6szjq7Dpktyj1Fx+ygOR028nRSqdhf0GrkmUbngYnh2jwZLUV9a9D5jfzs6E9iJZ5WkK5MkFt
ZFRvxLWzxwTvotagxsMch8IapGp9U8N1G6hb8BgErPeMxOA3sMjzhTVW667aYdQH83t8LVtKY/FR
k0pWRpkEgdfxJ2phO7o=

`protect key_keyowner="Xilinx", key_keyname="xilinxt_2026.1-2030.x", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
CZKy7wRvWs9USNSXaYbUkn+cLRCzmixbqtpmXRaKrtVpPBhr3AlT8jO2yswKRl5svnmVAVBAOcw8
NiSfC6AJPyXUjxIIPT/2uVJC3kKf5d9lzg+dMWlP5CT3uo+I7vDPDwVkOT7qjLoiJ+VesOcOl0fr
P+E3qVmejpgM8/dBdSZ8maUV5QrLv/4nRufPppOE2eHSHbIF6Bi4VUWVGIo0dhEm5KiATz8VgKMQ
88yJ9p56YWHnyjysqF3dS4UihNxpRjtVtJkxiM9jC6bG8fWpmlDyHPVEiWbytqXY3tORjtqOWzRp
DqMHOPalje0P+n9Akox1jSWIsty/ZD8PW1L9wA==

`protect data_method = "AES128-CBC"
`protect encoding = (enctype = "BASE64", line_length = 76, bytes = 7136)
`protect data_block
7uD+aadpjlcImkdFOLUbhlXbJpeLJiIdspA8uNGoKo5uiCW6pd/UysqgX2Cmit34DKJv/id9g2Xl
FHnoBWl5sfSY15/gYqFpW9gPwzLrXr72yIzurv9Db+f9dGuinLwJcUvY532fwdOMVReu2UjxcYTf
uoQ+84yqLk4nVPfnSHOcIE2ZbOrXrsMnYZjEI9yehVve6w1M/k2AHNubtlHJgq/qBrhUj9PLDb5Q
LxeobbSK+706c5TOcGJlzbyiux0k3B3bTCvwTeVif34i2bcBiwIL4R2fRJJHWpU4WfQRMx8ckxLO
N0/FvltooZuyCutfWdcE1qicgn8ap6VSEVmU0n92rBh+pxqDyvy1U+99Gykvscjc6clkuWqZLCMT
7fdm1VPleIs6cadhxthPiYYWFLQYsGdd/du7OszVMDk4APlmJzPPozb0QiEOFtw5Yo9NUMe+nErC
zsy+17/l1jZm//7BACaUeMvKdaJat4ek235oRLSHHMvE0Hy1+mlzxXD++uvPP+BKDeA4vr7eOKQs
1x0Rw7JDACRSRr7f9joHaGhgtPkR0s1qveb3rGpH9QHpx/a+bvRmreq6+xHAvRAiJNbdgp2Ni5en
PKIXuI0NAbv9fSfP7hgZ6edTHS5wfqF+QUi8T/APB7TNRL2Ou9ayapjXMDqSmxMNNpWNpJSHHll6
1+m7lvd97nfeeGZL/afy73HPI4+R9bwm5dN2eoJWl5gogx9OpGTrgh0eSWWRhcIwMXSa9zOIWCvH
s1bMU/7g6/L7GogY2ZoBiiOH8SadHg3S3xD5gdDn27k1b0X1KJ6N5ZGDLyaAVECpx0tNbCTXZrNM
Fp6WmqRVxGAGcVgoaessiZmBOeW4HnCWSQ9BkMpOMGElkbR9gd0SQ8iNZW+Ah3x3ol2wXoOl7XWH
viFTNC98BzVrZ+GEfcrk+Wf+bvnFwfNpnM9eBpxCzmFRKk8TJNvXGtuFTRdgzex1gz01A8escjEL
RUe+5x4Q8ZAwCUjXTmfKYznDAIXLmHGTjRqdVA2dkr+luC2G3+YcGG/nuRSvgbAwrmcVMPepDSl+
5RMSAMI9oYdOUhi33y+2o32XX52F0ln56nH7KtRU8/eohzvxxpbQ7X/WxrZogZeoQjPKb/+09qcm
yZ3EQV3MfMbpdz126BEtRyp7njD3Bmjooh7W8bsFRYeFlx3aVHi//1VTci6YtD/GsczDXkZKPxkj
o+hcLXrb7psOj2t04m9upvecW925TLG+e8T2XCTYxDGV+HGEejsvlDUT0m1RW86MjbJCsovEki2K
qQNSWqnq95NVld90UPX3cxyZRi2t1o9+PxtvRozcHH8n8UcLQghn+B3NRYVOh8opagzjq9gS0nqn
3WWL9VKEhzDsZ6ldZCcny/xadW7uMRLk7c1y8V0IrQVs8DeLYewn3wSZdM10Dpl7PJYTZpU3Phvu
xceFVzRgdD6CyFk/9EsOUNY5f896nUpSjKAVPzIY7rN4/oMuZQ1M3e0pj3rU47sir5Q0hddnv2wN
AJ9+LHXbidCDI1z0BybqLZRyAy5CN/hgVQMPRiJ2pyvvLOSxhuRj2aNymi7w5pckfeDX9NLv8YKi
QPBPpVNc8tMoDtPmIiIivr7WPMY8+fdY61o6cWV75gKVcCN21BjLdYaCg9tsYH75PfYKjw3ivkCB
VOvsONlYI9iUWYyukHjIp0xQjhTjgehFiV+FphRACooNhHsF0k579f182zFbQBD3RaB81uvGmAKz
5qPDYiIX47tS9tsGSd8vhTWh8MURa+Y3W8e0igAs7bWc19kfvjReA7wHf7LlXl8GGebT162v523Z
FupPsrQKKb8rOLyt+67kxaiLZkTBTV6pMR08RfuwJV+mI3WxgAOWKsJ/30SnO+OCW1RmsV38bD9Q
cQ9lND1RC8GWAFU5HRK4jU4X6VQSRmCHmJoRWKKSvWLs767kDW8HCdrwGvn0nQIDG83ffPRQZAbx
F+qjsC/RQ2xqP+m5RnCJt8x487KzVGpMwz/onOvJsWD6yghSG/ubOsq6H641azrg0zjmiZXUP4I/
8QIPvZF2DRYRFFsIk1JummsaqPyXmG7C4twyssyP+n3KI40jXdw8OB0f3wI+7NrnPDFAozJG9Nve
l/3FEwxIR6sorU22ikc6ZNgxpZFcQPv4ofIw62rBsvAbv/R6e2f7XaUuP18VCJhljL/qQJWnwnaR
D8n1/U7s+qDJPqMrJLdIQG+Vp1TzkaxBp1RiT3tQ0U0PalR/KXzJhh7wL+E6OCCrKg+2hKUZlFMH
eQUmtrnWBzJNBZy8XoUREYG/Je3kZ0IBIhTBMLxj9MlxYBWb/QEzWZeEnH73qX8nRZ7ELS0QelPp
+xddwFITSLKIhcaGQBgSQmOUMydLnOKTS10I7SF88yqykEgKPRx3FwlIYS3+PpEiPYoGhT8AKVZ5
SsNaOi3isYr5rgif3n10d310tkDNq6s4kzPFL/O7wilngu/yQHWxvVHYo8/sCjzMyF2f7sTqIUS3
IqeLuRtCNWZAaxSC/GV6hZtKwkRzztJuB1b2Mb74bASWYn/q9dpSuy3khyKu9LCkWZaj6fAWs2vF
sTcmPN+RMGNFSyAddvp0xlfBBkH0NCQ84EuSWWrgCk4c52PTJsv9+rAum4nvAif/0iyXkNrMn3Zj
GNUNG2VEKuM4YMe1kB6lVxOXu9IiEQHlUo6Y3WosnDVaMCuZ7pJ4mcRsibUEsWZUGzVmcwBDqr4j
0OfwD8kvJckwcQyrs0fQapMH0f+LgAQWvptypcVf3CiS2hqeea2esdYmwA4VetIrYmULgx8AXdHG
T5FjDY3fWDurrpDDcZ9JJhqLv9LwYSIM5B72YTmzOe9bdQAao/6YbsuObs63oJ3LT+2D3QC02ZgM
iqWwl0WRUtKFprk0ojfdr7YRFEB4K/rNJxMxFWgnYQoZ2al+2J3iwXuX/Q9idisNUOSwdRZihOK6
D6A32Nk0ASvjHuXE2ofGuUNJK/yksyywZQ/yi+sJmwYI7py4+rrKBIqd2LnJ15qgJzSfh4i38TqW
uWA4MeKEFs8+L8BMv+UORpTToSVE5UY2UgMthtdISAvEOsAHWWOzUUlxC+zkGfpIjIjXIxsdNeOk
PWZZR+7+TFTBu5vnmHpRluNqJmRTuAwPx46r+6Ub/sWFAJTuKqrhj/EApwUfWR+JIgsLZptksUTa
u+D5kj9xzmnoHkEZyvHX8ETiVGXZREXpxkPndMrrmdzCwEYjU5qgqeyfT2zybU7j0FnQyKg7LSee
+qQVsa+d56OUhZk8hj/jtuwfeo89MBCkL35VleMCGTsH/hCZux4aCJuMqSdQtruVKsSMeQWO0bG3
ce2ylOSLvB4wjP5tj6BjXnu98hJDXpwgt675nwtIqlilSfcV1FbE/oEb3MgFXEOw6ntaqT2T+VUR
Q9Js4GNqk/VxuzwomteECH6aaLSUx3BAaxm130o8GVV8KQLBsbd+Rg4fkqORD6bhMDayhyVvAFET
123ZTW0IacE1ZH2jrbjzyA3OKxBhHgyMC4rsAyJ1DDdeCwYT34Ru6jR+ZrAaqfM/O2IVZrTNv4a2
LP8z3sO7vUgVzbVhqXFtxfjTXZYBrq4wG0V7YPBbMKJh5rrAi7lS1gy29VYURIZmZ+47hmZGki3Q
ol4+hSkpf2AB0Id2ogyfdSIlcZLJa2aIAHkMEPoKy17fDwCdjS2L7bhwHNsL9pmDixVHKm68E2D7
a+4Mv0GygrMexaxJM5x9rZ9Igy1t00ZHasnuUjb2zkj8/Ic8sz+BOKxE4+Nev64C9q32vdiiStXt
lg9RbEfgT2Jw6e5NUdNb6fqSHyTvlprf6TlXU05jvUump0mH0jjZnaMM2FDekGccSuqR7WN9SnKw
K0Q9b7AhZfcuxajnf07TkPi2rEM2K1Wx4a+vUgAODVwWMK2OT8hDtBWlJIbZKXHfvRWWn7V86BED
IhC36HyJRUpmz0KCXtCRP6Q3NGILXVa1GoETA8GzP9L9ptaruvmJdAO7xIhPhbBESuk9AZZ5dqfn
cOj/FzZ9KbeNAKVAFZzhVsImTQfpTAKZwdpXFvYBPPiU8Vuc3ajZWJbu3GfCIO1oihPS3FajsTJF
irrF7lzgVHQgLW1sa/qcCa9tED+juJuz0XxIlUd3s8osykl2pyczeRYqQqLcmh/YwFzGhhxsoUbP
gdnOpBmdDOMpKO25fWsglxLyr02bkgd0tfbe/+yuhCDTLB9Weu+tVfjCrzCRtCAsKkZUqKlICWjf
ImmD5pywtiBkx63qHw4QDuKUZxi8b2r1pM2AlY+rRQrpvvl8tbRv2nCc9pZq6G4WB+CvA8sqzNNp
YZFuunRy94Lfn5lEH7yGy43sGfZtGqpIqyfAc7af6DT4viI4KIKUtcGKAGGgt8xype2T9UV9Jc7z
vS2CLx2NKQjxAIPxXmb/GvIoB+SOBBCnWZPWdYiNspmrDe+NCSHhxRTJwcK7bmaoux4uGPYBoOvh
N3WhWCfyFEDPHu10rcDrmvcA/ErPRmZZQSwRbMmPgsVC+kc+xiXRMDhJNC4rLAJ3AjgixTEeFvqj
aXulfZLiqVyBqUba/1G6y8mohJgDA50UAJgTEEhJjmwN/9JO9TweevzDEuROGXe3XZwxVTDerPzj
gpwDqBVYvuCWW5CSZJt/NkRcSWKJXYuCT6cF/yYdvMj8dXUAiGzSvXfPtlFLQ5n6bR5bFgjkG/60
Qbi1JAYAGq7FnkQEBcwUmnLwy60dhIPaZLeTCp9hawYF5ddI7kwBh/ynrjUVcBBNhUp+ppRmnvRq
6pEfavoHkW4u17huU882xFHDlBcVPAmQH23krR/TfEIh+h9VLuo5d/Sq4HZJrTiX1j/tjNIfWjuV
irfhqJ3RXLGoxwAO185T/mR+qzEnXl8xOYi7jruy8xVqVIOEI01ZHS+OBo7cQBok0UJSo1Dgee7+
Uxwy2OqU4mL+OrNH8L39eW9rB+W6/h8wOGD7EwESph1wRb7fed6lLSNynd9Wzi8ACMpsmwp9MimN
g0W1+Wx2kwFy3qU9Ed5SnDHFMTCdltTduiYZOGj+xfsGCa1wdiQWX6FMqq7wg6+KqfHdZPLnwHWs
gFTbip5XYpgMwkmfWk+G86WQdMFHE3cuRR8lUSlq8ETML1IZRxaenM6cJR/YjY4TRwBG7a8+P/Po
lFw59FsLALDEYYMjAzCR9E1twhejMAgvsqJ7E4QBp27NRtwz8MxOsyOkZmEs6aTtczfF23iYe1RP
xxbZgKK8RUD+50OYNYpxefefN0KVefi32kXOccDSHksX8M1/uFas5EqS9Fr9qPQUvJl4FFP9l3q+
HvRow66GBKIL+MnHycCNP7v8ShejCjAe2cy/PlABA1WR7ygMWzIslbd5xzzBkf/6Z1zlPiqN3KCc
7WvdCBXHUAXZsFeDTAIC9sYuDSX3azw3aIFiRfABFqZeRhKd5AeiSfNg4hQtyEtCytECWEi/9Brk
Q3IfAXIu8JH6pOkHDkumyv1TPqS8co5r4XjrmWUff2aGQDkBQFLS2DM5QvKnDgoaDkJwCc1oQZOg
OMHW/JHpWWpDWKLzDYzP2EWav+Xgg56fzWHfbQATOYvc07ARkndKizykD/lRPgeLDQV9mMpS92EG
n6ZNZm8vQdBREBVdI4yMqDPqQ2lYc8P1OreaXmX5GQb94hKIFl302DJ5mPN7XWPVh1FXt0VCjAyH
Tpw3uwUYdekCKBXRjPPexSTriAcj/Hq3S7pHZsofVgSA4pazHMuDS06/aqLlhkhjqqx4xPFbnTBP
4jUuGIo8RDXsk/87rJvh7JoQ2SMshpAUhN0oQFJ+vNAs1v8rA7mCn0L/3twesgLg3hbdMr/s6Zym
nupYdM/oQbVIoPbyyFwb58t10YhrHwgD83kqHtMvss3oi+KYLNvuj/IYGhZirS3M1d7IaJuV/VJ5
oOPpHHbs0o7jdrZ7axuVUoR08pUOWmdqUuTCJv/xTRsiFjLOwgfv6HGg6nTfxlJdJd12OQCOXOsX
94YJ2z6nN3awTtWmXi/sbhkOZzYr6hfpEfRynJHfDPDUgVsvvvqZGZ8Ig2Qhr3r4085zatnt3fuZ
CYHs6K7FFb4OeT7IXNCcTBmw0gtECd9+l7RBuT2reNoUU5pnuMvq+Wt7819RsJqL4ek63t/susqf
rT4C6xmtFsostLGmksVwM3gX+nGqs0WwFi2yDLfx/A9Zod3B4+pXK5uOJPTby3CVcqYZTPKqM9Rb
Pucougbachq8ag7D5mApPyCQybMnudid6ZWKmIom/Yf7PMUVIJBUwQAKB2BN3sHd6F8heVtt6CS7
mfRSF4VxAAJ2KwDCJJ8KXZPCcgvZ9AD+Skgd+VtxDZgt6tRgdivXYv4lb17Tnqx7wsX8gWapywuS
9cr+KziBelD19KvCA5NraGytH5VXtSx9jZUKDK1dnpakPzHy65GR1DUhfqtzz6VKKa5HhnJ145Ae
TAZsCAFF86kw6i+Mp4OVIBfEPRH9IbitIBSEqVgHxO0uHEFvpU+Oodi7s1lx2pFfLZvXfZ2f+GbY
4M8U74QYMAKwZDEL81KWTI/LKhZPZ0/X3+Cyy1xuBlY/fN4pIskCbPYpYC6QVHTvmwURcVBVejjx
gMJ1o8koAqvrCG3F+nj1Xf7cbyBLKANJ2Rx/ACZRVYuqH5n5b8yHwFdXMotheKs4v0fIpGk/SRaJ
bUAJGW1d7tVfHR66lx6OOGtXeNemyEvCx0DU20z96wioQ7gUy+Qt78tFrswFYo6+JJJLqernCT1R
DAxNR1qQ6MTzSpuPiv6nlovw6G31O8PSFWbASpDO+mJXezbViljnnBRcJ761okC53To9FZWOAWeS
LZPVALyyOONhMTrI7Vc7kTK0nZksoflFC+l5CgqecD1TLYVq8Ie2GYIZQlWHew6p51bSkYeLI3bI
OppkResl05XgZjmfEoOhvZMocPisq3tvJV2Y7A+b/NtYI3VxIiWjZ4JVXj6YzYkZq82rz6SW+SOQ
q3cBsMraX3Vq3iyeJi+rH28D28LP7sodeWNGQQR9+nb+QH7ZegjLPhyt83TCvarHTkpdPRHkwhw4
yHp3IHPG3btM5AAs/vEjycu+NCz2Stacg4Ii+4XGNVLCBMxwrxXZjabA8BQ297kHvInpZ+i9iwUM
yd95dErOMey/Ij05cxfUrtnbSnD50bTpxJzMyiJiXVJes+ASdhBHGzrztAamkXBjW7CnNVAzSk3k
7YhpbROZ7aKY80Cl2t28UdZcYl+fZIGnnzSj+lYuSPy52vViu3i8iYnSVPLGXUY8sRwEnC2slLZd
QOpSRikzERbY2j9KWei46EJPG7pBktR6aINoYq5EnGgw/ruH3xVfUJ+JOdvyOPqjYuCwJuaLkeN9
okzXEaCcjliJDy2Xm/0UFYQo/jHSUdhgXdvjiczgIMRK9Md+Vog9NumWPbE9yN4LkOnVTHGOWhO0
Ty48T/SuBXO4c51btsq+7ZFeU5+KIC8nzqQBABsI3+SzTnqEM+/rQeQrTKkLu+3ABpCi3M7djM8e
NCY8e/3pYg6RodcglFAvThyIk9hSrOoS7Kz7YcqCqyj4NwmLBUovxOL3x2P+sE7ZZUtHcr2JabAq
JfAjVa0DYaFykGn67tNHVQDpxO3pfjbiZfPr7lVbfcYl38kGpULWpn0HldZjXjgWC/sgAwnPxfOM
f87tRCS5SoEjO4vYiYjsYcCXwN7D8FyjBqW6QuYq1GTp+NuEA26RxsRWY5FO9PbDHxDgr/kdRU4r
P/OqxJcdH4zWSuKNNRMfm6XC9p7oy309GijyIEENfKNHzFTB4Uo9rOXewpWIjZHkrQtT53yDvyx4
2TZ8k+07xpt9+2uK7wUSfVk7FvqC3kKiTb4SRpb0/Clem1iCQxPbJtj3FqGUZdwnFBuKrA/AukzA
mmvFx847KONxGiWeohKj87qlgdRPr2wpMhGWPnrTSodCv+1+gn87syds1YaefhNdTzO0GLkpOOLu
DOfTgK7FTEgKI/FIEUNIXjGemZY7zwr3fu/AyEFx69EIYaeSdYZtOSu4AmaVosYlRXVQM7PG3H8W
DgboukdfC34Mtf1epRX5crKfXKxeCOJ7CGwlJX83JHaXWOmg5CSY+8PNjWui/DVxuGBcyI/Mybyf
RqF4H0y0CV1DBDt4vK211agzXTPzdY/hUWWWVCzR0VQuFP1XPDiFzw/OH1MK/awuCfGuQFjTcO5O
DyIrG6RyrjJe8yT8dRZclzT0PWMvAKG7Ihg41mcaYRVOIvescTgCWzOFzE9uhXZqn9dXXGfkZJ90
+lZo7AmdpRy+jlwuER4qDgqekyc86yP2k5GUnvHktL/cRO5zw8xV06FbK5Cq0mj092j7dGfS3nVW
JTsAxUxjqtdgBD8WOfHzEUfgnx9l+jFkn36Dy0h3xXbbYTRd8rCwG9mgaCvDuKe+RbI2KZZb7Ex8
ZAe0zgP5gZGHgKc+yH8IE7DGoyTZD49f3NF47ZxoDUKdHtQmdr64nYQGJfw2LgZZHQrulcEB/pJV
RStjPKjNFyRQWqw0AbHdCEf3jPZNHL/Py1p1jpyDhl5lpGVTQokTl3RsfBmj/IeJxN1PGnOMPTWD
MwlblK/WhDkuxun3vXvDeOSdkKq7XeW4S+NhVw9CocFhn3fwtzK902PxAanofwo4zo+3Bgcph/Of
kM09bbqCeTr1jsNpenLi08mXIo/L39L5J5q0TDV1aMzxS0te+0MhBK0hr4wblODjsuLgRLEfTr7i
crtxKG9rYg1vDa3OsSSjzgu+ane8oDZJ2LE6kkeNWBZ+AP+aoQv59+vsHWQ6Vnx72G6LQIkWtP7K
B0prsnxdXz884Jwbx2CP0CFvvpkG4Tsevgu2rlxSpOdCu2ncCmt8nmt9citVv51+cpEKzyEg70fI
vq3BRsqN3CJ8lCHW9eKVKnSbcYrDgE7uGI1LQjyRR+hA3iVqEkYA1uHPdPb0lOCKFOPTSRLhULMF
MNsaPcaLdjuEOV+VXa8bb/8qdulMTn9cVSxThP5Gt42Y9wxiVRzXFtb0hid6FUaSAB5wJlJLouO9
m3vpckXL/DjXcxxcHeux3RuYVVF7Ltcv1JMAt01GALxNU6hWuDhaxupVShceVWdXsn5RMkgpggJa
ff8MuIuDw3SWZUk18RyFQSzOqqOVeDWFth0anwIlR19YfRqo0GnBCHa7Nv56EMZl3i739sNJP7yN
bgMEXDEGreynR2+NzGtZ/zskEKekh0f/ofH1qaJAZ4v9wLHbJR5oig++oDsHdCjczrNB+YAlXIfI
9hOsu17lkCKrxsZvoEUmzYaYe9ycqiUz/si2VkDWEhXRiT+/r7cOkYa9b8e4e8jk3P2iWD1kBd4V
F3s5DWN0icskfWFMpPH+ifsLun+7fCAEiYS9eRvA2dO8zyV0RQXUluy7vZaFteKOUhlhrwDrrzpz
ySeLHir1rnHE1psTWk7j+8046JtBNJNaWG3Ntos5/XrtHzq5uTyVp7h3unuSsr5LlxTGMXlv0gzb
kS99++WPgdiya+Y=
`protect end_protected
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    s_intf_0_ARVALID : in STD_LOGIC;
    rp_intf_0_ARVALID : out STD_LOGIC;
    s_intf_0_ARREADY : out STD_LOGIC;
    rp_intf_0_ARREADY : in STD_LOGIC;
    s_intf_0_AWVALID : in STD_LOGIC;
    rp_intf_0_AWVALID : out STD_LOGIC;
    s_intf_0_AWREADY : out STD_LOGIC;
    rp_intf_0_AWREADY : in STD_LOGIC;
    s_intf_0_BVALID : out STD_LOGIC;
    rp_intf_0_BVALID : in STD_LOGIC;
    s_intf_0_BREADY : in STD_LOGIC;
    rp_intf_0_BREADY : out STD_LOGIC;
    s_intf_0_RVALID : out STD_LOGIC;
    rp_intf_0_RVALID : in STD_LOGIC;
    s_intf_0_RREADY : in STD_LOGIC;
    rp_intf_0_RREADY : out STD_LOGIC;
    s_intf_0_WVALID : in STD_LOGIC;
    rp_intf_0_WVALID : out STD_LOGIC;
    s_intf_0_WREADY : out STD_LOGIC;
    rp_intf_0_WREADY : in STD_LOGIC;
    s_intf_0_AWADDR : in STD_LOGIC_VECTOR ( 30 downto 0 );
    rp_intf_0_AWADDR : out STD_LOGIC_VECTOR ( 30 downto 0 );
    s_intf_0_WDATA : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rp_intf_0_WDATA : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s_intf_0_WSTRB : in STD_LOGIC_VECTOR ( 3 downto 0 );
    rp_intf_0_WSTRB : out STD_LOGIC_VECTOR ( 3 downto 0 );
    s_intf_0_BRESP : out STD_LOGIC_VECTOR ( 1 downto 0 );
    rp_intf_0_BRESP : in STD_LOGIC_VECTOR ( 1 downto 0 );
    s_intf_0_ARADDR : in STD_LOGIC_VECTOR ( 30 downto 0 );
    rp_intf_0_ARADDR : out STD_LOGIC_VECTOR ( 30 downto 0 );
    s_intf_0_RDATA : out STD_LOGIC_VECTOR ( 31 downto 0 );
    rp_intf_0_RDATA : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s_intf_0_RRESP : out STD_LOGIC_VECTOR ( 1 downto 0 );
    rp_intf_0_RRESP : in STD_LOGIC_VECTOR ( 1 downto 0 );
    intf_0_aclk : in STD_LOGIC;
    intf_0_arstn : in STD_LOGIC;
    decouple : in STD_LOGIC;
    decouple_status : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "system_dfx_decoupler_0_1,dfx_decoupler_system_dfx_decoupler_0_1,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute x_core_info : string;
  attribute x_core_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "dfx_decoupler_system_dfx_decoupler_0_1,Vivado 2026.1";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute C_XDEVICEFAMILY : string;
  attribute C_XDEVICEFAMILY of U0 : label is "zynq";
  attribute downgradeipidentifiedwarnings of U0 : label is "yes";
  attribute is_du_within_envelope : string;
  attribute is_du_within_envelope of U0 : label is "true";
  attribute x_interface_info : string;
  attribute x_interface_info of intf_0_aclk : signal is "xilinx.com:signal:clock:1.0 intf_0_aclk_CLOCK CLK";
  attribute x_interface_mode : string;
  attribute x_interface_mode of intf_0_aclk : signal is "slave intf_0_aclk_CLOCK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of intf_0_aclk : signal is "XIL_INTERFACENAME intf_0_aclk_CLOCK, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, ASSOCIATED_BUSIF s_intf_0:rp_intf_0, ASSOCIATED_RESET intf_0_arstn, INSERT_VIP 0";
  attribute x_interface_info of intf_0_arstn : signal is "xilinx.com:signal:reset:1.0 intf_0_arstn RST";
  attribute x_interface_mode of intf_0_arstn : signal is "slave intf_0_arstn";
  attribute x_interface_parameter of intf_0_arstn : signal is "XIL_INTERFACENAME intf_0_arstn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of rp_intf_0_ARREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 ARREADY";
  attribute x_interface_info of rp_intf_0_ARVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 ARVALID";
  attribute x_interface_mode of rp_intf_0_ARVALID : signal is "master rp_intf_0";
  attribute x_interface_parameter of rp_intf_0_ARVALID : signal is "XIL_INTERFACENAME rp_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE";
  attribute x_interface_info of rp_intf_0_AWREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 AWREADY";
  attribute x_interface_info of rp_intf_0_AWVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 AWVALID";
  attribute x_interface_info of rp_intf_0_BREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 BREADY";
  attribute x_interface_info of rp_intf_0_BVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 BVALID";
  attribute x_interface_info of rp_intf_0_RREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 RREADY";
  attribute x_interface_info of rp_intf_0_RVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 RVALID";
  attribute x_interface_info of rp_intf_0_WREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 WREADY";
  attribute x_interface_info of rp_intf_0_WVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 WVALID";
  attribute x_interface_info of s_intf_0_ARREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 ARREADY";
  attribute x_interface_info of s_intf_0_ARVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 ARVALID";
  attribute x_interface_mode of s_intf_0_ARVALID : signal is "slave s_intf_0";
  attribute x_interface_parameter of s_intf_0_ARVALID : signal is "XIL_INTERFACENAME s_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE";
  attribute x_interface_info of s_intf_0_AWREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 AWREADY";
  attribute x_interface_info of s_intf_0_AWVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 AWVALID";
  attribute x_interface_info of s_intf_0_BREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 BREADY";
  attribute x_interface_info of s_intf_0_BVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 BVALID";
  attribute x_interface_info of s_intf_0_RREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 RREADY";
  attribute x_interface_info of s_intf_0_RVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 RVALID";
  attribute x_interface_info of s_intf_0_WREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 WREADY";
  attribute x_interface_info of s_intf_0_WVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 WVALID";
  attribute x_interface_info of rp_intf_0_ARADDR : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 ARADDR";
  attribute x_interface_info of rp_intf_0_AWADDR : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 AWADDR";
  attribute x_interface_info of rp_intf_0_BRESP : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 BRESP";
  attribute x_interface_info of rp_intf_0_RDATA : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 RDATA";
  attribute x_interface_info of rp_intf_0_RRESP : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 RRESP";
  attribute x_interface_info of rp_intf_0_WDATA : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 WDATA";
  attribute x_interface_info of rp_intf_0_WSTRB : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 WSTRB";
  attribute x_interface_info of s_intf_0_ARADDR : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 ARADDR";
  attribute x_interface_info of s_intf_0_AWADDR : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 AWADDR";
  attribute x_interface_info of s_intf_0_BRESP : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 BRESP";
  attribute x_interface_info of s_intf_0_RDATA : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 RDATA";
  attribute x_interface_info of s_intf_0_RRESP : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 RRESP";
  attribute x_interface_info of s_intf_0_WDATA : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 WDATA";
  attribute x_interface_info of s_intf_0_WSTRB : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 WSTRB";
begin
U0: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_dfx_decoupler_system_dfx_decoupler_0_1
     port map (
      decouple => decouple,
      decouple_status => decouple_status,
      intf_0_aclk => '0',
      intf_0_arstn => '0',
      rp_intf_0_ARADDR(30 downto 0) => rp_intf_0_ARADDR(30 downto 0),
      rp_intf_0_ARREADY => rp_intf_0_ARREADY,
      rp_intf_0_ARVALID => rp_intf_0_ARVALID,
      rp_intf_0_AWADDR(30 downto 0) => rp_intf_0_AWADDR(30 downto 0),
      rp_intf_0_AWREADY => rp_intf_0_AWREADY,
      rp_intf_0_AWVALID => rp_intf_0_AWVALID,
      rp_intf_0_BREADY => rp_intf_0_BREADY,
      rp_intf_0_BRESP(1 downto 0) => rp_intf_0_BRESP(1 downto 0),
      rp_intf_0_BVALID => rp_intf_0_BVALID,
      rp_intf_0_RDATA(31 downto 0) => rp_intf_0_RDATA(31 downto 0),
      rp_intf_0_RREADY => rp_intf_0_RREADY,
      rp_intf_0_RRESP(1 downto 0) => rp_intf_0_RRESP(1 downto 0),
      rp_intf_0_RVALID => rp_intf_0_RVALID,
      rp_intf_0_WDATA(31 downto 0) => rp_intf_0_WDATA(31 downto 0),
      rp_intf_0_WREADY => rp_intf_0_WREADY,
      rp_intf_0_WSTRB(3 downto 0) => rp_intf_0_WSTRB(3 downto 0),
      rp_intf_0_WVALID => rp_intf_0_WVALID,
      s_intf_0_ARADDR(30 downto 0) => s_intf_0_ARADDR(30 downto 0),
      s_intf_0_ARREADY => s_intf_0_ARREADY,
      s_intf_0_ARVALID => s_intf_0_ARVALID,
      s_intf_0_AWADDR(30 downto 0) => s_intf_0_AWADDR(30 downto 0),
      s_intf_0_AWREADY => s_intf_0_AWREADY,
      s_intf_0_AWVALID => s_intf_0_AWVALID,
      s_intf_0_BREADY => s_intf_0_BREADY,
      s_intf_0_BRESP(1 downto 0) => s_intf_0_BRESP(1 downto 0),
      s_intf_0_BVALID => s_intf_0_BVALID,
      s_intf_0_RDATA(31 downto 0) => s_intf_0_RDATA(31 downto 0),
      s_intf_0_RREADY => s_intf_0_RREADY,
      s_intf_0_RRESP(1 downto 0) => s_intf_0_RRESP(1 downto 0),
      s_intf_0_RVALID => s_intf_0_RVALID,
      s_intf_0_WDATA(31 downto 0) => s_intf_0_WDATA(31 downto 0),
      s_intf_0_WREADY => s_intf_0_WREADY,
      s_intf_0_WSTRB(3 downto 0) => s_intf_0_WSTRB(3 downto 0),
      s_intf_0_WVALID => s_intf_0_WVALID
    );
end STRUCTURE;
