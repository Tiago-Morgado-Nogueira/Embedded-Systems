vlib modelsim_lib/work
vlib modelsim_lib/msim

vlib modelsim_lib/msim/xilinx_vip
vlib modelsim_lib/msim/xpm
vlib modelsim_lib/msim/axi_infrastructure_v1_1_0
vlib modelsim_lib/msim/axi_vip_v1_1_23
vlib modelsim_lib/msim/processing_system7_vip_v1_0_25
vlib modelsim_lib/msim/xil_defaultlib
vlib modelsim_lib/msim/smartconnect_v1_0
vlib modelsim_lib/msim/proc_sys_reset_v5_0_17
vlib modelsim_lib/msim/axi_register_slice_v2_1_37
vlib modelsim_lib/msim/axis_infrastructure_v1_1_1
vlib modelsim_lib/msim/axis_register_slice_v1_1_35
vlib modelsim_lib/msim/dfx_decoupler_v1_0_15
vlib modelsim_lib/msim/axi_lite_ipif_v3_1_0
vlib modelsim_lib/msim/interrupt_control_v3_2_0
vlib modelsim_lib/msim/axi_gpio_v2_0_38

vmap xilinx_vip modelsim_lib/msim/xilinx_vip
vmap xpm modelsim_lib/msim/xpm
vmap axi_infrastructure_v1_1_0 modelsim_lib/msim/axi_infrastructure_v1_1_0
vmap axi_vip_v1_1_23 modelsim_lib/msim/axi_vip_v1_1_23
vmap processing_system7_vip_v1_0_25 modelsim_lib/msim/processing_system7_vip_v1_0_25
vmap xil_defaultlib modelsim_lib/msim/xil_defaultlib
vmap smartconnect_v1_0 modelsim_lib/msim/smartconnect_v1_0
vmap proc_sys_reset_v5_0_17 modelsim_lib/msim/proc_sys_reset_v5_0_17
vmap axi_register_slice_v2_1_37 modelsim_lib/msim/axi_register_slice_v2_1_37
vmap axis_infrastructure_v1_1_1 modelsim_lib/msim/axis_infrastructure_v1_1_1
vmap axis_register_slice_v1_1_35 modelsim_lib/msim/axis_register_slice_v1_1_35
vmap dfx_decoupler_v1_0_15 modelsim_lib/msim/dfx_decoupler_v1_0_15
vmap axi_lite_ipif_v3_1_0 modelsim_lib/msim/axi_lite_ipif_v3_1_0
vmap interrupt_control_v3_2_0 modelsim_lib/msim/interrupt_control_v3_2_0
vmap axi_gpio_v2_0_38 modelsim_lib/msim/axi_gpio_v2_0_38

vlog -work xilinx_vip -64 -incr -mfcu  -sv -L smartconnect_v1_0 -L axi_vip_v1_1_23 -L processing_system7_vip_v1_0_25 -L xilinx_vip "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"/tools/2026.1/data/xilinx_vip/hdl/axi4stream_vip_axi4streampc.sv" \
"/tools/2026.1/data/xilinx_vip/hdl/axi_vip_axi4pc.sv" \
"/tools/2026.1/data/xilinx_vip/hdl/xil_common_vip_pkg.sv" \
"/tools/2026.1/data/xilinx_vip/hdl/axi4stream_vip_pkg.sv" \
"/tools/2026.1/data/xilinx_vip/hdl/axi_vip_pkg.sv" \
"/tools/2026.1/data/xilinx_vip/hdl/axi4stream_vip_if.sv" \
"/tools/2026.1/data/xilinx_vip/hdl/axi_vip_if.sv" \
"/tools/2026.1/data/xilinx_vip/hdl/clk_vip_if.sv" \
"/tools/2026.1/data/xilinx_vip/hdl/rst_vip_if.sv" \

vlog -work xpm -64 -incr -mfcu  -sv -L smartconnect_v1_0 -L axi_vip_v1_1_23 -L processing_system7_vip_v1_0_25 -L xilinx_vip "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"/tools/2026.1/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \
"/tools/2026.1/data/ip/xpm/xpm_fifo/hdl/xpm_fifo.sv" \
"/tools/2026.1/data/ip/xpm/xpm_memory/hdl/xpm_memory.sv" \

vcom -work xpm -64 -93  \
"/tools/2026.1/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work axi_infrastructure_v1_1_0 -64 -incr -mfcu  "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl/axi_infrastructure_v1_1_vl_rfs.v" \

vlog -work axi_vip_v1_1_23 -64 -incr -mfcu  -sv -L smartconnect_v1_0 -L axi_vip_v1_1_23 -L processing_system7_vip_v1_0_25 -L xilinx_vip "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/4d28/hdl/axi_vip_v1_1_vl_rfs.sv" \

vlog -work processing_system7_vip_v1_0_25 -64 -incr -mfcu  -sv -L smartconnect_v1_0 -L axi_vip_v1_1_23 -L processing_system7_vip_v1_0_25 -L xilinx_vip "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl/processing_system7_vip_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../bd/system/ip/system_processing_system7_0_0/sim/system_processing_system7_0_0.v" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L smartconnect_v1_0 -L axi_vip_v1_1_23 -L processing_system7_vip_v1_0_25 -L xilinx_vip "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/sc_util_v1_0_vl_rfs.sv" \

vcom -work proc_sys_reset_v5_0_17 -64 -93  \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/9438/hdl/proc_sys_reset_v5_0_rfs.vhd" \

vcom -work smartconnect_v1_0 -64 -93  \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/21d5/hdl/sc_ultralite_v1_0_rfs.vhd" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L smartconnect_v1_0 -L axi_vip_v1_1_23 -L processing_system7_vip_v1_0_25 -L xilinx_vip "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/21d5/hdl/sc_ultralite_v1_0_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L smartconnect_v1_0 -L axi_vip_v1_1_23 -L processing_system7_vip_v1_0_25 -L xilinx_vip "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_0/sim/bd_44e3_sc_ul_0.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../bd/system/ip/system_axi_smc_0/bd_0/sim/bd_44e3.v" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L smartconnect_v1_0 -L axi_vip_v1_1_23 -L processing_system7_vip_v1_0_25 -L xilinx_vip "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/3d9a/hdl/sc_mmu_v1_0_vl_rfs.sv" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/7785/hdl/sc_transaction_regulator_v1_0_vl_rfs.sv" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/3051/hdl/sc_si_converter_v1_0_vl_rfs.sv" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/sc_node_v1_0_vl_rfs.sv" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/0848/hdl/sc_switchboard_v1_0_vl_rfs.sv" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/852f/hdl/sc_axi2sc_v1_0_vl_rfs.sv" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/fca9/hdl/sc_sc2axi_v1_0_vl_rfs.sv" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/c7d2/hdl/sc_exit_v1_0_vl_rfs.sv" \

vlog -work axi_register_slice_v2_1_37 -64 -incr -mfcu  "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/8c55/hdl/axi_register_slice_v2_1_rfs.v" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L smartconnect_v1_0 -L axi_vip_v1_1_23 -L processing_system7_vip_v1_0_25 -L xilinx_vip "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../bd/system/ip/system_axi_smc_0/sim/system_axi_smc_0.sv" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/system/ip/system_rst_ps7_0_100M_0/sim/system_rst_ps7_0_100M_0.vhd" \

vlog -work axis_infrastructure_v1_1_1 -64 -incr -mfcu  "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl/axis_infrastructure_v1_1_vl_rfs.v" \

vlog -work axis_register_slice_v1_1_35 -64 -incr -mfcu  "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/be12/hdl/axis_register_slice_v1_1_vl_rfs.v" \

vcom -work dfx_decoupler_v1_0_15 -64 -93  \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/5525/hdl/dfx_decoupler_v1_0_rfs.vhd" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/system/ip/system_dfx_decoupler_0_1/dfx_decoupler_system_dfx_decoupler_0_1.vhd" \
"../../../bd/system/ip/system_dfx_decoupler_0_1/sim/system_dfx_decoupler_0_1.vhd" \

vcom -work axi_lite_ipif_v3_1_0 -64 -93  \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/de33/hdl/axi_lite_ipif_v3_1_rfs.vhd" \

vcom -work interrupt_control_v3_2_0 -64 -93  \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/e2ca/hdl/interrupt_control_v3_2_rfs.vhd" \

vcom -work axi_gpio_v2_0_38 -64 -93  \
"../../../../assignment_2.gen/sources_1/bd/system/ipshared/6ccd/hdl/axi_gpio_v2_0_rfs.vhd" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/system/ip/system_axi_gpio_0_0/sim/system_axi_gpio_0_0.vhd" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/df05/hdl" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/00fe/hdl/verilog" "+incdir+../../../../assignment_2.gen/sources_1/bd/system/ipshared/434f/hdl" "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+/tools/2026.1/data/xilinx_vip/include" \
"../../../bd/system/sim/system.v" \

vlog -work xil_defaultlib \
"glbl.v"

