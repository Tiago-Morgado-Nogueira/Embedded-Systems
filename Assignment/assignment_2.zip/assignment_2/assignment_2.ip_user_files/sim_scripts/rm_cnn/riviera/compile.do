transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vlib riviera/xpm
vlib riviera/xil_defaultlib

vmap xpm riviera/xpm
vmap xil_defaultlib riviera/xil_defaultlib

vlog -work xpm  -incr "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+../../../../assignment_2.gen/sources_1/bd/rm_cnn/ip/rm_cnn_cnn_shape_0_0/drivers/shape_accel_v1_0/src" -l xpm -l xil_defaultlib \
"/tools/2026.1/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \
"/tools/2026.1/data/ip/xpm/xpm_fifo/hdl/xpm_fifo.sv" \
"/tools/2026.1/data/ip/xpm/xpm_memory/hdl/xpm_memory.sv" \

vcom -work xpm -93  -incr \
"/tools/2026.1/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work xil_defaultlib  -incr -v2k5 "+incdir+../../../../../../../../../../tools/2026.1/data/rsb/busdef" "+incdir+../../../../assignment_2.gen/sources_1/bd/rm_cnn/ip/rm_cnn_cnn_shape_0_0/drivers/shape_accel_v1_0/src" -l xpm -l xil_defaultlib \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_c1_RAM_AUTO_1R1W.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_c2_RAM_AUTO_1R1W.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_CTRL_s_axi.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_flow_control_loop_pipe_sequential_init.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_5ns_4ns_5ns_7_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_13ns_9ns_22ns_23_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_13ns_9ns_24s_24_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_13ns_10ns_21ns_22_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_13ns_10ns_23ns_24_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_13ns_10ns_24s_24_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_13ns_10ns_25s_26_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_13ns_10ns_26s_26_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_13ns_10s_24ns_25_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_10s_28s_28_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_10s_30s_30_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_10s_31s_31_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_11s_26s_27_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_11s_27s_28_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_11s_28s_28_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_11s_28s_29_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_11s_29s_29_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_11s_29s_30_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_11s_30s_30_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_11s_30s_31_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_11s_31s_31_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_12s_30s_30_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_12s_31s_31_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mac_muladd_16s_13s_32s_32_4_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mul_5ns_5ns_7_1_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mul_5ns_7ns_11_1_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mul_6ns_8ns_13_1_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mul_7s_5ns_7_1_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mul_13ns_9ns_21_1_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mul_16s_11s_26_1_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mul_20ns_22ns_41_1_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_mul_64ns_66ns_129_5_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_p1_RAM_AUTO_1R1W.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_p2_RAM_AUTO_1R1W.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_21_1_VITIS_LOOP_22_2.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Cbkb.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Ccud.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_CdEe.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_CeOg.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_CfYi.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Cg8j.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Chbi.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_Cibs.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_29_3_VITIS_LOOP_30_4_VITIS_LOOP_31_5_p_ZL7W_CjbC.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_51_8_VITIS_LOOP_52_9_VITIS_LOOP_53_10.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7Aem.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7Bew.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7kbM.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7lbW.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7mb6.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7ncg.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7ocq.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7pcA.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7qcK.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7rcU.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7sc4.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7tde.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7udo.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7vdy.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7wdI.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7xdS.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7yd2.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_63_11_VITIS_LOOP_64_12_VITIS_LOOP_65_13_p_ZL7zec.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_87_17_VITIS_LOOP_88_18_VITIS_LOOP_89_19.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VICeG.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_shape_accel_Pipeline_VITIS_LOOP_102_20_VITIS_LOOP_104_21_VITIS_LOOP_105_22_VITIS.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_sparsemux_7_2_13_1_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_sparsemux_7_2_16_1_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_urem_5ns_3ns_2_9_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_urem_6ns_3ns_2_10_1.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel_x_in_RAM_AUTO_1R1W.v" \
"../../../../assignment_2.gen/sources_1/bd/rm_cnn/ipshared/2c9e/hdl/verilog/shape_accel.v" \
"../../../bd/rm_cnn/ip/rm_cnn_cnn_shape_0_0/sim/rm_cnn_cnn_shape_0_0.v" \
"../../../bd/rm_cnn/sim/rm_cnn.v" \

vlog -work xil_defaultlib \
"glbl.v"

