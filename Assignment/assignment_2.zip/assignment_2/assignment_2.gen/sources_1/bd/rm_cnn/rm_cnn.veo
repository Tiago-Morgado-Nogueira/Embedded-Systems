// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// -------------------------------------------------------------------------------
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
//
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
//
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
//
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
//
// DO NOT MODIFY THIS FILE.

// MODULE VLNV: amd.com:blockdesign:rm_cnn:1.0

// The following must be inserted into your Verilog file for this
// module to be instantiated. Change the instance name and port connections
// (in parentheses) to your own signal names.

// INST_TAG     ------ Begin cut for INSTANTIATION Template ------
rm_cnn your_instance_name (
  .ap_clk(ap_clk), // input wire ap_clk
  .ap_rst_n(ap_rst_n), // input wire ap_rst_n
  .s_axi_CTRL_araddr(s_axi_CTRL_araddr), // input wire [10:0] s_axi_CTRL_araddr
  .s_axi_CTRL_arready(s_axi_CTRL_arready), // output wire s_axi_CTRL_arready
  .s_axi_CTRL_arvalid(s_axi_CTRL_arvalid), // input wire s_axi_CTRL_arvalid
  .s_axi_CTRL_awaddr(s_axi_CTRL_awaddr), // input wire [10:0] s_axi_CTRL_awaddr
  .s_axi_CTRL_awready(s_axi_CTRL_awready), // output wire s_axi_CTRL_awready
  .s_axi_CTRL_awvalid(s_axi_CTRL_awvalid), // input wire s_axi_CTRL_awvalid
  .s_axi_CTRL_bready(s_axi_CTRL_bready), // input wire s_axi_CTRL_bready
  .s_axi_CTRL_bresp(s_axi_CTRL_bresp), // output wire [1:0] s_axi_CTRL_bresp
  .s_axi_CTRL_bvalid(s_axi_CTRL_bvalid), // output wire s_axi_CTRL_bvalid
  .s_axi_CTRL_rdata(s_axi_CTRL_rdata), // output wire [31:0] s_axi_CTRL_rdata
  .s_axi_CTRL_rready(s_axi_CTRL_rready), // input wire s_axi_CTRL_rready
  .s_axi_CTRL_rresp(s_axi_CTRL_rresp), // output wire [1:0] s_axi_CTRL_rresp
  .s_axi_CTRL_rvalid(s_axi_CTRL_rvalid), // output wire s_axi_CTRL_rvalid
  .s_axi_CTRL_wdata(s_axi_CTRL_wdata), // input wire [31:0] s_axi_CTRL_wdata
  .s_axi_CTRL_wready(s_axi_CTRL_wready), // output wire s_axi_CTRL_wready
  .s_axi_CTRL_wstrb(s_axi_CTRL_wstrb), // input wire [3:0] s_axi_CTRL_wstrb
  .s_axi_CTRL_wvalid(s_axi_CTRL_wvalid) // input wire s_axi_CTRL_wvalid
);
// INST_TAG_END ------  End cut for INSTANTIATION Template  ------

// You must compile the wrapper file rm_cnn.v when simulating
// the module, rm_cnn. When compiling the wrapper file, be sure to
// reference the Verilog simulation library.
