-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2026.1 (lin64) Build 6511674 Tue Jun 16 11:01:26 MDT 2026
-- Date        : Sat Nov 21 16:15:53 2026
-- Host        : diogo-azevedo-Legion-Pro-7-16IAX10H running 64-bit Ubuntu 26.04.1 LTS
-- Command     : write_vhdl -force -mode funcsim
--               /home/diogo-azevedo/Robot_Systems_MSc/Embedded_Systems/Assignment_2/assignment_2/assignment_2.gen/sources_1/bd/system/bd/rm_cnn_inst_0/rm_cnn_inst_0_sim_netlist.vhdl
-- Design      : rm_cnn_inst_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity rm_cnn_inst_0 is
  port (
    ap_clk : in STD_LOGIC;
    ap_rst_n : in STD_LOGIC;
    s_axi_CTRL_araddr : in STD_LOGIC_VECTOR ( 10 downto 0 );
    s_axi_CTRL_arready : out STD_LOGIC;
    s_axi_CTRL_arvalid : in STD_LOGIC;
    s_axi_CTRL_awaddr : in STD_LOGIC_VECTOR ( 10 downto 0 );
    s_axi_CTRL_awready : out STD_LOGIC;
    s_axi_CTRL_awvalid : in STD_LOGIC;
    s_axi_CTRL_bready : in STD_LOGIC;
    s_axi_CTRL_bresp : out STD_LOGIC_VECTOR ( 1 downto 0 );
    s_axi_CTRL_bvalid : out STD_LOGIC;
    s_axi_CTRL_rdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s_axi_CTRL_rready : in STD_LOGIC;
    s_axi_CTRL_rresp : out STD_LOGIC_VECTOR ( 1 downto 0 );
    s_axi_CTRL_rvalid : out STD_LOGIC;
    s_axi_CTRL_wdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s_axi_CTRL_wready : out STD_LOGIC;
    s_axi_CTRL_wstrb : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s_axi_CTRL_wvalid : in STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of rm_cnn_inst_0 : entity is true;
  attribute HW_HANDOFF : string;
  attribute HW_HANDOFF of rm_cnn_inst_0 : entity is "rm_cnn_inst_0.hwdef";
end rm_cnn_inst_0;

architecture STRUCTURE of rm_cnn_inst_0 is
  component rm_cnn_inst_0_cnn_shape_0_0 is
  port (
    s_axi_CTRL_ARADDR : in STD_LOGIC_VECTOR ( 10 downto 0 );
    s_axi_CTRL_ARREADY : out STD_LOGIC;
    s_axi_CTRL_ARVALID : in STD_LOGIC;
    s_axi_CTRL_AWADDR : in STD_LOGIC_VECTOR ( 10 downto 0 );
    s_axi_CTRL_AWREADY : out STD_LOGIC;
    s_axi_CTRL_AWVALID : in STD_LOGIC;
    s_axi_CTRL_BREADY : in STD_LOGIC;
    s_axi_CTRL_BRESP : out STD_LOGIC_VECTOR ( 1 downto 0 );
    s_axi_CTRL_BVALID : out STD_LOGIC;
    s_axi_CTRL_RDATA : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s_axi_CTRL_RREADY : in STD_LOGIC;
    s_axi_CTRL_RRESP : out STD_LOGIC_VECTOR ( 1 downto 0 );
    s_axi_CTRL_RVALID : out STD_LOGIC;
    s_axi_CTRL_WDATA : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s_axi_CTRL_WREADY : out STD_LOGIC;
    s_axi_CTRL_WSTRB : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s_axi_CTRL_WVALID : in STD_LOGIC;
    ap_clk : in STD_LOGIC;
    ap_rst_n : in STD_LOGIC;
    interrupt : out STD_LOGIC
  );
  end component rm_cnn_inst_0_cnn_shape_0_0;
  signal NLW_cnn_shape_0_interrupt_UNCONNECTED : STD_LOGIC;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of cnn_shape_0 : label is "rm_cnn_inst_0_cnn_shape_0_0,shape_accel,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of cnn_shape_0 : label is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of cnn_shape_0 : label is "HLS";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of cnn_shape_0 : label is "shape_accel,Vivado 2026.1";
  attribute hls_module : string;
  attribute hls_module of cnn_shape_0 : label is "yes";
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of ap_clk : signal is "xilinx.com:signal:clock:1.0 CLK.AP_CLK CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of ap_clk : signal is "XIL_INTERFACENAME CLK.AP_CLK, ASSOCIATED_BUSIF s_axi_CTRL, ASSOCIATED_RESET ap_rst_n, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, FREQ_HZ 90909088, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0";
  attribute X_INTERFACE_INFO of ap_rst_n : signal is "xilinx.com:signal:reset:1.0 RST.AP_RST_N RST";
  attribute X_INTERFACE_PARAMETER of ap_rst_n : signal is "XIL_INTERFACENAME RST.AP_RST_N, INSERT_VIP 0, POLARITY ACTIVE_LOW";
  attribute X_INTERFACE_INFO of s_axi_CTRL_arready : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL ARREADY";
  attribute X_INTERFACE_INFO of s_axi_CTRL_arvalid : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL ARVALID";
  attribute X_INTERFACE_INFO of s_axi_CTRL_awready : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL AWREADY";
  attribute X_INTERFACE_INFO of s_axi_CTRL_awvalid : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL AWVALID";
  attribute X_INTERFACE_INFO of s_axi_CTRL_bready : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL BREADY";
  attribute X_INTERFACE_INFO of s_axi_CTRL_bvalid : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL BVALID";
  attribute X_INTERFACE_INFO of s_axi_CTRL_rready : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL RREADY";
  attribute X_INTERFACE_INFO of s_axi_CTRL_rvalid : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL RVALID";
  attribute X_INTERFACE_INFO of s_axi_CTRL_wready : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL WREADY";
  attribute X_INTERFACE_INFO of s_axi_CTRL_wvalid : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL WVALID";
  attribute X_INTERFACE_INFO of s_axi_CTRL_araddr : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL ARADDR";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of s_axi_CTRL_araddr : signal is "Slave";
  attribute X_INTERFACE_PARAMETER of s_axi_CTRL_araddr : signal is "XIL_INTERFACENAME s_axi_CTRL, ADDR_WIDTH 31, ARUSER_WIDTH 0, AWUSER_WIDTH 0, BUSER_WIDTH 0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, DATA_WIDTH 32, FREQ_HZ 90909088, HAS_BRESP 1, HAS_BURST 0, HAS_CACHE 0, HAS_LOCK 0, HAS_PROT 0, HAS_QOS 0, HAS_REGION 0, HAS_RRESP 1, HAS_WSTRB 1, ID_WIDTH 0, INSERT_VIP 0, MAX_BURST_LENGTH 1, NUM_READ_OUTSTANDING 1, NUM_READ_THREADS 1, NUM_WRITE_OUTSTANDING 1, NUM_WRITE_THREADS 1, PHASE 0.0, PROTOCOL AXI4LITE, READ_WRITE_MODE READ_WRITE, RUSER_BITS_PER_BYTE 0, RUSER_WIDTH 0, SUPPORTS_NARROW_BURST 0, WUSER_BITS_PER_BYTE 0, WUSER_WIDTH 0";
  attribute X_INTERFACE_INFO of s_axi_CTRL_awaddr : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL AWADDR";
  attribute X_INTERFACE_INFO of s_axi_CTRL_bresp : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL BRESP";
  attribute X_INTERFACE_INFO of s_axi_CTRL_rdata : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL RDATA";
  attribute X_INTERFACE_INFO of s_axi_CTRL_rresp : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL RRESP";
  attribute X_INTERFACE_INFO of s_axi_CTRL_wdata : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL WDATA";
  attribute X_INTERFACE_INFO of s_axi_CTRL_wstrb : signal is "xilinx.com:interface:aximm:1.0 s_axi_CTRL WSTRB";
begin
cnn_shape_0: component rm_cnn_inst_0_cnn_shape_0_0
     port map (
      ap_clk => ap_clk,
      ap_rst_n => ap_rst_n,
      interrupt => NLW_cnn_shape_0_interrupt_UNCONNECTED,
      s_axi_CTRL_ARADDR(10 downto 0) => s_axi_CTRL_araddr(10 downto 0),
      s_axi_CTRL_ARREADY => s_axi_CTRL_arready,
      s_axi_CTRL_ARVALID => s_axi_CTRL_arvalid,
      s_axi_CTRL_AWADDR(10 downto 0) => s_axi_CTRL_awaddr(10 downto 0),
      s_axi_CTRL_AWREADY => s_axi_CTRL_awready,
      s_axi_CTRL_AWVALID => s_axi_CTRL_awvalid,
      s_axi_CTRL_BREADY => s_axi_CTRL_bready,
      s_axi_CTRL_BRESP(1 downto 0) => s_axi_CTRL_bresp(1 downto 0),
      s_axi_CTRL_BVALID => s_axi_CTRL_bvalid,
      s_axi_CTRL_RDATA(31 downto 0) => s_axi_CTRL_rdata(31 downto 0),
      s_axi_CTRL_RREADY => s_axi_CTRL_rready,
      s_axi_CTRL_RRESP(1 downto 0) => s_axi_CTRL_rresp(1 downto 0),
      s_axi_CTRL_RVALID => s_axi_CTRL_rvalid,
      s_axi_CTRL_WDATA(31 downto 0) => s_axi_CTRL_wdata(31 downto 0),
      s_axi_CTRL_WREADY => s_axi_CTRL_wready,
      s_axi_CTRL_WSTRB(3 downto 0) => s_axi_CTRL_wstrb(3 downto 0),
      s_axi_CTRL_WVALID => s_axi_CTRL_wvalid
    );
end STRUCTURE;
