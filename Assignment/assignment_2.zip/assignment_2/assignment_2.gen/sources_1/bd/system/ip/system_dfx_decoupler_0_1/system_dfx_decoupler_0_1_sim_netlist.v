// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (lin64) Build 6511674 Tue Jun 16 11:01:26 MDT 2026
// Date        : Sat Nov 21 15:49:00 2026
// Host        : diogo-azevedo-Legion-Pro-7-16IAX10H running 64-bit Ubuntu 26.04.1 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/diogo-azevedo/Robot_Systems_MSc/Embedded_Systems/Assignment_2/assignment_2/assignment_2.gen/sources_1/bd/system/ip/system_dfx_decoupler_0_1/system_dfx_decoupler_0_1_sim_netlist.v
// Design      : system_dfx_decoupler_0_1
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "system_dfx_decoupler_0_1,dfx_decoupler_system_dfx_decoupler_0_1,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dfx_decoupler_system_dfx_decoupler_0_1,Vivado 2026.1" *) 
(* NotValidForBitStream *)
module system_dfx_decoupler_0_1
   (s_intf_0_ARVALID,
    rp_intf_0_ARVALID,
    s_intf_0_ARREADY,
    rp_intf_0_ARREADY,
    s_intf_0_AWVALID,
    rp_intf_0_AWVALID,
    s_intf_0_AWREADY,
    rp_intf_0_AWREADY,
    s_intf_0_BVALID,
    rp_intf_0_BVALID,
    s_intf_0_BREADY,
    rp_intf_0_BREADY,
    s_intf_0_RVALID,
    rp_intf_0_RVALID,
    s_intf_0_RREADY,
    rp_intf_0_RREADY,
    s_intf_0_WVALID,
    rp_intf_0_WVALID,
    s_intf_0_WREADY,
    rp_intf_0_WREADY,
    s_intf_0_AWADDR,
    rp_intf_0_AWADDR,
    s_intf_0_WDATA,
    rp_intf_0_WDATA,
    s_intf_0_WSTRB,
    rp_intf_0_WSTRB,
    s_intf_0_BRESP,
    rp_intf_0_BRESP,
    s_intf_0_ARADDR,
    rp_intf_0_ARADDR,
    s_intf_0_RDATA,
    rp_intf_0_RDATA,
    s_intf_0_RRESP,
    rp_intf_0_RRESP,
    intf_0_aclk,
    intf_0_arstn,
    decouple,
    decouple_status);
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 ARVALID" *) (* x_interface_mode = "slave s_intf_0" *) (* x_interface_parameter = "XIL_INTERFACENAME s_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE" *) input s_intf_0_ARVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 ARVALID" *) (* x_interface_mode = "master rp_intf_0" *) (* x_interface_parameter = "XIL_INTERFACENAME rp_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE" *) output rp_intf_0_ARVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 ARREADY" *) output s_intf_0_ARREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 ARREADY" *) input rp_intf_0_ARREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 AWVALID" *) input s_intf_0_AWVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 AWVALID" *) output rp_intf_0_AWVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 AWREADY" *) output s_intf_0_AWREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 AWREADY" *) input rp_intf_0_AWREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 BVALID" *) output s_intf_0_BVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 BVALID" *) input rp_intf_0_BVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 BREADY" *) input s_intf_0_BREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 BREADY" *) output rp_intf_0_BREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 RVALID" *) output s_intf_0_RVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 RVALID" *) input rp_intf_0_RVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 RREADY" *) input s_intf_0_RREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 RREADY" *) output rp_intf_0_RREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 WVALID" *) input s_intf_0_WVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 WVALID" *) output rp_intf_0_WVALID;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 WREADY" *) output s_intf_0_WREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 WREADY" *) input rp_intf_0_WREADY;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 AWADDR" *) input [30:0]s_intf_0_AWADDR;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 AWADDR" *) output [30:0]rp_intf_0_AWADDR;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 WDATA" *) input [31:0]s_intf_0_WDATA;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 WDATA" *) output [31:0]rp_intf_0_WDATA;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 WSTRB" *) input [3:0]s_intf_0_WSTRB;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 WSTRB" *) output [3:0]rp_intf_0_WSTRB;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 BRESP" *) output [1:0]s_intf_0_BRESP;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 BRESP" *) input [1:0]rp_intf_0_BRESP;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 ARADDR" *) input [30:0]s_intf_0_ARADDR;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 ARADDR" *) output [30:0]rp_intf_0_ARADDR;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 RDATA" *) output [31:0]s_intf_0_RDATA;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 RDATA" *) input [31:0]rp_intf_0_RDATA;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 s_intf_0 RRESP" *) output [1:0]s_intf_0_RRESP;
  (* x_interface_info = "xilinx.com:interface:aximm:1.0 rp_intf_0 RRESP" *) input [1:0]rp_intf_0_RRESP;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 intf_0_aclk_CLOCK CLK" *) (* x_interface_mode = "slave intf_0_aclk_CLOCK" *) (* x_interface_parameter = "XIL_INTERFACENAME intf_0_aclk_CLOCK, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, ASSOCIATED_BUSIF s_intf_0:rp_intf_0, ASSOCIATED_RESET intf_0_arstn, INSERT_VIP 0" *) input intf_0_aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 intf_0_arstn RST" *) (* x_interface_mode = "slave intf_0_arstn" *) (* x_interface_parameter = "XIL_INTERFACENAME intf_0_arstn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input intf_0_arstn;
  input decouple;
  output decouple_status;

  wire decouple;
  wire decouple_status;
  wire [30:0]rp_intf_0_ARADDR;
  wire rp_intf_0_ARREADY;
  wire rp_intf_0_ARVALID;
  wire [30:0]rp_intf_0_AWADDR;
  wire rp_intf_0_AWREADY;
  wire rp_intf_0_AWVALID;
  wire rp_intf_0_BREADY;
  wire [1:0]rp_intf_0_BRESP;
  wire rp_intf_0_BVALID;
  wire [31:0]rp_intf_0_RDATA;
  wire rp_intf_0_RREADY;
  wire [1:0]rp_intf_0_RRESP;
  wire rp_intf_0_RVALID;
  wire [31:0]rp_intf_0_WDATA;
  wire rp_intf_0_WREADY;
  wire [3:0]rp_intf_0_WSTRB;
  wire rp_intf_0_WVALID;
  wire [30:0]s_intf_0_ARADDR;
  wire s_intf_0_ARREADY;
  wire s_intf_0_ARVALID;
  wire [30:0]s_intf_0_AWADDR;
  wire s_intf_0_AWREADY;
  wire s_intf_0_AWVALID;
  wire s_intf_0_BREADY;
  wire [1:0]s_intf_0_BRESP;
  wire s_intf_0_BVALID;
  wire [31:0]s_intf_0_RDATA;
  wire s_intf_0_RREADY;
  wire [1:0]s_intf_0_RRESP;
  wire s_intf_0_RVALID;
  wire [31:0]s_intf_0_WDATA;
  wire s_intf_0_WREADY;
  wire [3:0]s_intf_0_WSTRB;
  wire s_intf_0_WVALID;

  (* C_XDEVICEFAMILY = "zynq" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  system_dfx_decoupler_0_1_dfx_decoupler_system_dfx_decoupler_0_1 U0
       (.decouple(decouple),
        .decouple_status(decouple_status),
        .intf_0_aclk(1'b0),
        .intf_0_arstn(1'b0),
        .rp_intf_0_ARADDR(rp_intf_0_ARADDR),
        .rp_intf_0_ARREADY(rp_intf_0_ARREADY),
        .rp_intf_0_ARVALID(rp_intf_0_ARVALID),
        .rp_intf_0_AWADDR(rp_intf_0_AWADDR),
        .rp_intf_0_AWREADY(rp_intf_0_AWREADY),
        .rp_intf_0_AWVALID(rp_intf_0_AWVALID),
        .rp_intf_0_BREADY(rp_intf_0_BREADY),
        .rp_intf_0_BRESP(rp_intf_0_BRESP),
        .rp_intf_0_BVALID(rp_intf_0_BVALID),
        .rp_intf_0_RDATA(rp_intf_0_RDATA),
        .rp_intf_0_RREADY(rp_intf_0_RREADY),
        .rp_intf_0_RRESP(rp_intf_0_RRESP),
        .rp_intf_0_RVALID(rp_intf_0_RVALID),
        .rp_intf_0_WDATA(rp_intf_0_WDATA),
        .rp_intf_0_WREADY(rp_intf_0_WREADY),
        .rp_intf_0_WSTRB(rp_intf_0_WSTRB),
        .rp_intf_0_WVALID(rp_intf_0_WVALID),
        .s_intf_0_ARADDR(s_intf_0_ARADDR),
        .s_intf_0_ARREADY(s_intf_0_ARREADY),
        .s_intf_0_ARVALID(s_intf_0_ARVALID),
        .s_intf_0_AWADDR(s_intf_0_AWADDR),
        .s_intf_0_AWREADY(s_intf_0_AWREADY),
        .s_intf_0_AWVALID(s_intf_0_AWVALID),
        .s_intf_0_BREADY(s_intf_0_BREADY),
        .s_intf_0_BRESP(s_intf_0_BRESP),
        .s_intf_0_BVALID(s_intf_0_BVALID),
        .s_intf_0_RDATA(s_intf_0_RDATA),
        .s_intf_0_RREADY(s_intf_0_RREADY),
        .s_intf_0_RRESP(s_intf_0_RRESP),
        .s_intf_0_RVALID(s_intf_0_RVALID),
        .s_intf_0_WDATA(s_intf_0_WDATA),
        .s_intf_0_WREADY(s_intf_0_WREADY),
        .s_intf_0_WSTRB(s_intf_0_WSTRB),
        .s_intf_0_WVALID(s_intf_0_WVALID));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2014"
`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ldf5+Eel1Xg47b67VCGO7Sn/f72qKUySSTqXHGLUuZMIEDbs8goxQH4jU4WCjayrQJlXUckjGK/R
+xpETivd1XBijlHOq+6pIPdNxud+uxsRiXFv/PdzNxLegGX1Kj+803vDsMZhyEcbEqAfwJ/XsMgx
gBB3b/e5gGbV3FjPatgl7u8g268mjOlSJ+kkpomjHLtQ4Gu3L/cmyf9qcuyuSXneKmTvfORpbdKD
F2KLnH12m21xCjsq1RyhG0/rX/tpSRtK/Cyjf1iBN1+CumcP4BnjhZF7HkN0/5fofc+trTwCugHq
lf092Cse0hMjT6qh6zRp7oOdPO/lo4YOrUsaFw==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
JYsc1i5wADC636qJkhtbbqI30icWri941gSqMjRHc1zAGxG/CxWqes1E6tM5X8S85ZYoCMqqUTCP
zPeYa7aQNirLk409DDiowqJ6IqZQrrY+fBMxexE4af4mFTcMnATbeJB7S3rwotwFuRjuxR1OtFsI
U+JiT0aqHwnIalXbGMgVkVNE1neFFQJ4ZBnrRdzj9e+1B6XJdQNQM6SBY9zmfPppe7wa0YnEgTyH
QGRyr+S4kNHnZaNGTz+0RM1hdPRC3HCjXOAGx1aJin9qks+nKaDyBD9iEacoGE1w3ZEEo37ZetHB
p0RnY3Iknk5a0/ghb1YeXW0NxGfKF6kEMI+etQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="cds_rsa_key", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=64)
`pragma protect key_block
WlaT7VStZV63t0DHLAK7130SPqtmORk3fcjLdtxvo7Zr8Vmf8RaEvpcsRYObgwUmUqVm2/hPKxJO
+gb5wmyLtA==

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YDObQ1NtkfjBlvUYh1vxXDdyFI4c395gslA2Nhvha9xfwbCxrCMC+Y4k3qcOISA8VnP3PtRnlSnk
gqsB5Z+NsTUYpVMwc9bR/xjzv465vByNc0VTPmks9o70hDTl3hTSVaGde5wXmpj23OoPZXXCeJFB
eOrulFJJZvgPwReJV3lqiSpMDZQk3SC43ps+uaG8ijNKNBZR+WjC12wPewpZ8VBZ7Hma6nHEqHW+
5ZR4xr6ue8/TRPL7q4G9HTfnnZ+ZvA6SE7rcmqTlc6Dkssv9CGfP9CCAQefaCaAHA0Awsm+GbusB
6jUiAQCL3UHrJtZ1RAuhk/TuaLwO45uK6dD1Aw==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
LQm8cJQoDLEdpDz42uCYcg02AxUSfKw1bk/grtDTdPuSzYtA9NwhjNJyIayYsCIaWAPtBxYRoip/
tybUgI9T3bbwD2ghc4BLznwa0plIbJkroT7Jrn58u/A2W26vreY2bp1xUZ+QSVZMyZnXNo9V+gLF
ayYkFh3bP6mbHfjwzA6hR4FcoZ2eepttevQF5DMpBLrLnVq/aIBFpwQ49lO68jNmijSgba7Ii7O5
K89AQ7slKWtr2ww3BC0tbqV3EyrBw3sCcw63cUrTmsEqXoBRku/H4GyxQPdJAdHGxYuDgsLFCh1Q
SuZHjhlxsijRsmFnMb0Fc2gajleiVE7C0MTBcA==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
JaH4Inem8lV8ECCJnQGn3skgvDGVe62ipkMWHHBP1li/NSo4EQlLZZiUL9vgkQBmrZ+36laWQaMM
CJnuIT0s3L3LFuo4mVHfooiTSkI4DUH9qY1JrG5kjxsSrUrrsHnxtddQ1+cLfpHI6hMbfxn1/Uwh
MGRFxX8DBuqBkg2zrXA=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
mC30iYh3XPktRMXUAIPhQauehS1OnX+FwBY8y1V9+O8M03GUPlifFt6HlwbZBlU8xApEI7PfOmTD
Wxo5PJIQ8uzfBJzImHSUGAxVym5w4F7A5B4FgkG6AOmZDycXBgE0QeFwBvV5Zddd6qm63Vt6kepz
OSI0urDhDBb/36e1gb+9JKsIHI9qxSWcvwP8Pky+fHrn+nNKQLF3/Bv0njiQX5coTnyuFflprHjh
wx9qx2jy/hqmwnsFAaRJqwtUAfyKY9TW/4cjVt/tLuVxyL9g2BOZvak4SSdO58UjmKfBBBxG1/US
hCIl5Qwlqc5VVeI/0Kv8UUY2jaTfzQkWUspPXg==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
0ibm5urUCFAbXqRlTOQ2X1ugmfvpVMrJXwV1fwuIH6ljvHrT1hKbxyH9X+apdZPsAzy0S6NLBFIX
mG+NMUOKGLZkpKIMGyx+U5BVD2jstq2+1JJ4z37sZUGIBV19IDn3+xnXVZZ9Tkh1z4LrSn/nyd3e
rbQztBLmUQCUPMDDEuqTAZP7R2qP4WFH4rOfmOe0w2+WtVkSeofom3SnI3YBdJ707uOZv0JBwTKk
TeDtpW7sGFHaRoWAQIK/9zTcHZR3gkAJVZKdxYbz2txR/+Gk+Jq5DVkqOtnSV8cMKL2uJDoHmQBG
+vtfs5jfvxdSu9g39cHe3i46F14roUnaEpM3MA==

`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
j+M6szjq7Dpktyj1Fx+ygOR028nRSqdhf0GrkmUbngYnh2jwZLUV9a9D5jfzs6E9iJZ5WkK5MkFt
ZFRvxLWzxwTvotagxsMch8IapGp9U8N1G6hb8BgErPeMxOA3sMjzhTVW667aYdQH83t8LVtKY/FR
k0pWRpkEgdfxJ2phO7o=

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2026.1-2030.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
CZKy7wRvWs9USNSXaYbUkn+cLRCzmixbqtpmXRaKrtVpPBhr3AlT8jO2yswKRl5svnmVAVBAOcw8
NiSfC6AJPyXUjxIIPT/2uVJC3kKf5d9lzg+dMWlP5CT3uo+I7vDPDwVkOT7qjLoiJ+VesOcOl0fr
P+E3qVmejpgM8/dBdSZ8maUV5QrLv/4nRufPppOE2eHSHbIF6Bi4VUWVGIo0dhEm5KiATz8VgKMQ
88yJ9p56YWHnyjysqF3dS4UihNxpRjtVtJkxiM9jC6bG8fWpmlDyHPVEiWbytqXY3tORjtqOWzRp
DqMHOPalje0P+n9Akox1jSWIsty/ZD8PW1L9wA==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 5056)
`pragma protect data_block
GZbPuNV7WK5OBPShWh169xeXKF0Y7xz/2LRekhcXftQqTBoBWBuFnVvJuYC2qDogMktdIgISPqW7
GdFuOQPvilA1Ti+zxRbwZWmFsb5mtr6qcP4k7ct1wjkMIYlt7t1Nk07xClVzn3MqaOZtt/GJh2Ry
sYcO1VdTWVpaZ2KPHHBB96Ib97SB4Es8yxXa/oDbZF7XSVEwF0EdjFbqjwEPNxwhK3txsm6Zgat0
ffcEZg3oEaHpj96UMoASK2fUjiGntyHLi+BqiTHrZ0YxCpDZKlbuMSPMjtQf0v5J4UBPTme3gSM+
Ualpj8rUh1YczUr3xEwBwxGrSy/sc9UQcFd29xpS318nixUAxL6okk0S/fXSsKmMQYBKO0Szlhng
3AlPIiUVkxMjIW7MOeJb9bsE7Cj5cDBDivOf0XCC+FdUB9d7/myeXCAjHHhQECVVROc+vG1Iw/I9
YGrZxiXPoxGGF3vVlsd7T5+o8r9qvd7cETEu1dRlRbAjM7zPeTnMbYDi58Otr3IdoXVphZwc12YP
EE0eZKGLWf0c2OVI/GCIjWWhl1B3i8+FrbrIsA4TMYSou1wk9/hjbhtfiOia+7GYpQhRYugsbejf
Ka0h9fNFcVcXw4obb55UlvAJzgqxB47p2rpOiTd+6n65JMl0FyD95eaatE8bnO52W23MoT8qKbvj
A9v7XMxlu52MaVqZdp/GpUNDquHVOQOdxufACaGm2PwDtDxvP2WhG+lLmqkZHmnhdEz9kSl61Lro
PQZhT2BR1jFQW97YjptFmryNYiLBdW0fmDXDNBpdmPP8AR3odsmE/7IewZ2Ehbm1VP8bIas01gbm
NoK/4P0ydVeTdXek1fEHpqtqdKcB22maC2sgmvyv3TVIHR3kuVPdwJOML+qHugXZLXK5an0WvtDO
CO0vwH8BoPIRb8F6icFQ4UXekrfqeMr4GSFLqRDGcLF5hBtMaZqw3ZN0KDQmew3ZJ/iWYyJi8gzO
5ynU68WTR2AIUyIT3ajEmzEcpipByB+LKzdrVju+zWGtyqGSM19srDJTt82MuTkXkWr1ytKJp7kz
Gu7P3AozY8SsuLBlHEV3fbJVIKbwPDW3ZrBETeoTinl5KxM66Zzgde7KRSluEGV7drr5Y4r3dHV+
PPpGRHxmXMBK+XTjWXaoHJQeSAu252L6Raiwamw36oU9wpLneXN7MkWHbOdBodS7oMtJ0Va7u7bu
uYPpTqgvBYo8lIMiwXx83xB3Sufq2qcfPoIMUoQhTevYqU3KNV5aDpZj6ys5EJhfw4RiLKQ8dR6J
F805zicG76nO6XwimHC8xwcqoPA7cou4SXLey514ywTD6NDlpuXd9jhjzuEhGMSuVGbGBTQYgOUB
CzD20tnbgLB9jsfqLmpg85Kju3GLKiLU8p/83AEhNe/9Hm8LKQI28XVsHLu5dn2OV76QhDnsHr9g
aYbOAdKHQRwPSkHqTpWapDKZaX7M2ghSbP5GrxBXUBs5GbFbuyqgPDGOT2xC3CWzvElLEzB3VxH2
7azAtnDj8+DcEZmwaUA2NfIu4umcGmx7OC3R9+vukFiyytQK/BQjD/Ec9ygo2CV0Yas/nBQ+qY6p
kBaIbNG7GCwraC1WZMlbl01b0SxinZFKgh9mGnWL8sz7brZb54UWEiyGt5vc2ExiLk8vqBbhzJqS
I1uWwZrkRlu9YJtVjT9GtAeQAxWCsE1pY9up93+UBxUBqsVnjNHN0g3EE6YjdEGH1hMUUoFTzcFq
QRyIkf17xh4MCPG9N37ZfTzfGrhhAs5qcjHklcW1Cn6vR92LNhu3QOcmGXNG8OW82HPkTvZ4zKLz
qYegWozaxUxi/RlNLhGQ/AKsKndXvLCvttzvPHY+lVoO3iNEU4zynYT+hZtKgFKY7+RcIJ+vo44U
04PaGMZGF9BErM/5C+nxKjtU8JXuIUA/8KmO3SvcmgtC+Vn5ygN/QYTpcLJMN2rDRWID3aH29GYk
eZ2AvlBLB75h7qLa7ec4Cw9YO28qjtZOQ0Rb2rB/6gWbnkZS5eI5A1s4G6LGyF33i4uDJOrzdY5L
Ke+PrpGdrmA7kpwojfdWw+KM3s7FQg1+1IPtcRODwX7AI8qSuyCsu1MabjVMp6ft/Vt3h2n4y4N8
jc9sBvM+ququO53M5AcRv6qKmdYFhEYWPVE0Ixgh5FO4OA2zuexyy5awlcupxtNJ7W6pfclZ54fk
fsDnWikQAd3nWv/VKJCi9/Fvq7E/Df2lXTOFHEHQ/DfO2abO/ASKuUexiz0db/QV2G9KoGtDJZlg
cjtvBwcrxEAi9yS91FH9wiMdkISjB8W2zDOj6LAe9OwKmSsmpKrQO3hy9CA3sIZ7aBzviYAU/PXa
uWPtnyYyL4FbIB6SMi2/YsUObvY0WuvpqQmiZjpfuFnukQK5GZu2Fd6RWReQJt6llBi1rEE+v03W
hACjUQSY1KskQiInXtIH8qNAfBFMkYHIPjk0VTQ3mUSG1scFdQhkP9LkI0OUEv+2s1Z+wCKjsKVa
3nU55WExNkeb3HBNSX91kTUuljlwlgFyxe9EiXK18vxyK02qQoywa7WPwGFN3qmQOHX1InkW0vYq
MgEIdinU8+Tu8EvKaB2Xyr3VR94OC9boySxw7XAxxym8/pb4USUXqzq70CMmQksklDK4VpQGt6eP
Cc5Hoyzond1epQalU1c17r6qB3czdt0usjFv4zL6wX4e6BZKVpWfPSOpD0ICxcEl3hJ01sJZWgGY
Kp+fWtd0jz8LSPP7NyyvbKX/n2CRIM77rxxeLXIQYymJeuIjE3i2jjaMWpkOeiBz7e2MOvjG7iDz
pc57oAXFGWQTCJeHhTiDK73BnTA7PiZMWIKjLxSU0f928he7AOItFa6NtrL+kzJZrbhWVWdg/qDk
0Sv5zWWPkytOdd9OKRFxHLC14d3bNcBuv1DSXrUmhgkxlEiRqMBImbrafNTZtB3eoZWtQn3rzSpX
XjHZvQn1ySWD9TeV9eaPeqKK3aklVm6DymAKxuYkdl80xPpe1/uqawjjoSIdh7/eR9gpD92+tXeo
b+Hi+17h9Bphb6jY3IE10zNiIl9TBS2ifd+4yCUShatIXnlfE+77ubip8Y/YTTBi+rRSZRDVS/Qy
ULor936egmye88WKcCTCoVWje5qcZ6Cmm41d6VXw6/5Ho7h1LgxsEVpExn+Y5pwEhTtLiDPHDOjN
onjLS676ygqgWx+OkmiR/WnuROiO6DlVAGEVYJeW1aJEK9p1feYN30TEI/vuSICJiHjjVaFrRBUy
2XwqhCEA8eEFBn2hPr5+coyRct00BfmPXM4CC0ddrlb7tKHs0rm6CmkNlNUV3D9xM6jl56Va4sAl
Nh9Pcltb+lrDB5ukBIAwv4xXwQdwRaY7dm8CyXMhkGgjYxsB5HjUGVhXv9OLvOk0XmNWc3zgwhBG
cztSzoxPH5tH7Utd8qFBSbsbybhTCOtCulZNRW4pl4Rh0Y9OcgsPVVX+1y8mSy0pDOkvplKT2QUn
v1B8FX70UfMIOBlzWTSmEAlBnU0TaQQc/+TWN3USB9gy6BT2aq+ACscxn0qf1WdZsV3oPvJDcMGt
QYvy1tFdJiPHwkP74+PPhO4r3i7tyzLRDyUagE6yRExFWlLlEibYS8R2YOkBhve0OlrLgAzrS1ch
ARPwo6FVr9FM1HLswqWNBFdBDVEIOHJ8loDEorwg4z2lioVpY2QcbeA1+Gr2CV0HAr+j/DHnLUzL
JZRPBlffR1SGd9bAhi7pSz1y/su9HjmCWdfZBk5E05ZnG4jH3L34vxHvGcSX9tjQPYrd6rAg2LL5
wo1zIQnDiS2sj7W/3Ry9E3n075L++E+hEOJcr1n8kuJEaoRlWBSqATZAc+RiSHSiaduTT6arkDsF
3FYLTd7fc+TFbSVBaLoxXiyLbxiFsw1El1PdxS/9HTLmJTCeG+mb/nvyh1gK9T/cvHvN5TKrlOzS
N2xYECW/3TWqAFs0PV8ddtEgbyi/SLHFuBx6JSLlyRZ85SpXb0B9O1RiaG5VwWM4Ha8UoYDXrY02
drpPEGqXRj9JCcCFCigcDlgDUJjmrknfAT0D1ATCco+ZYeAUGmyJMh5tbBistl8YvokFeQt9psJ9
LbLS+lKOdIKvIfAxN8u/Ps72iM+CWj4AQtv5ioQ5MaFWLRjVt78MCsiuQ5TL3UMj5Tl8IeiZxwza
n+RfGBXFnDsgkxF+gDScAFDD8CIfS68mBYZBOZGtbr/bk3pC4/AZPhbKS0KZRbgihAc8fJpNnbvg
uZb1pXFgGIu5+fu/NwGc88mKeN4IJSS9J+wXZZAoxMkfqpqOx6T9EVjxrpM09gdVQAtXzmuHnTKn
+qgSMy0uJi7UDR3FuTNzQO6tLE7BCrquwtl2FbJif0bxc5huZV3/7km4qhjSOItUZjKu5nf4bTti
RPgxomVhUW86pQ/ode4IrIaN7o5YNcmo3scUYJLNJZADfwUP4aLPteAHsNagi77QCSSiiEuzxBT/
lRhjgO4aaC5kTZuSLBuzctCYbx7tAzdCkAVBGhMMEkc6xavv2tiuVtsLHRhqFFOfG+o+mbgNoHPT
1ZG4+3F16Op1QvUsOml1rwQd55TZRUUjuHRAIvHU7GIFcYdSac1Ei9ZAU4B98rGnd2wwsqr9hjRw
5L/4YpCu0YIc5587Zk9OSE8JSlQAkwiEx8KGld5YBra1cR36nZIQ2qmg0vojSMdWpvPgnyVQBnb6
fjkmBz0QKZPXoK9CWLNr3fAzpg77auwEI3oek1/FdtYwyjiwZ7SpncsrjNeLLOCaPhQgPuWpnP0B
qGQfGLUQXeEA7SFcZjgaGDhspJ8STfgYqzHDlkvGurVKEYSFeVsW9e0RbcQhGwigTunjK9WK+kXY
pc8l8I+SlO8pPC+kC660FRCyfI5Y+qqib7c8KvY6ivpSfteimO+dKM4/fp4ktAtYqbxCbEcDBJBZ
V1sllxBbCWXeHh9NuFvWo+nEOCPjN9BslgGj8CARGNWQ2CnqLKs0TbN7pryqoTn+/8m/QOQ2q39C
9Ah4tc6Q11MYOQXnabJvZBE64F3yBXhpydhCGIuJA3X+WXzGsXua+Tas6rNK0Y08jzZpSXrgiSxs
t8xn3bB3UKlxd6RzHFpmc5unuOu6Rin0tfWvVNNRGZFnQ9i4dxZW5f2uswn6qOF9l/s1K8TvvCSL
ZKnawga0T+HhqKg+9tYvMvjFfd3eOPjEJWQ+6Z807X7S60BJ2+2inicz5t9LXRqJOv1sdAMgEWFW
9s48qLeVn93qetPZoc/AEb82ZOoUQwbc5xA8YXaFsDzBisnmaFEtHN2R+vUDY8JEIoRtqmKq2Sow
go7Gb3501gDrCe0zhLMHEPnxSXj1QdGq/rXVStUyxTSJrRzg05ThVgdGEUX0DwCVL73Y5ELOdN2K
OnZ0WOdTdQBEABIDntl8nL1iHldHxsKza0lZ1DrV9RGlfyu9nqqIA/8VL6ElkruMzpbx5EGe6qWD
knA287aC3Ed0Pzep+Q4dVomKxV2rFoPpO3EdB6bIgkaML69C/6mogCw44RnMl072MjW8NmPrgYvv
YhFaIDUCfamNE5Y8IJ70yI95aNQV9Wul6ssQC/oqGAKSg58gNXbZSJRDOjEAhbiflvssAZ/FVXVR
icboh6DpuF2X2KIx+6SQcZJUhoZfq560TKWOmW6ekNuym6efIS0yQgKVtK/1WxhXB/kBjQ0+145L
vUZs4dHfnDYvpjf9A2irQhAYH4LazfmiOeILZN66eHx5e687p9InPSavEgVQ0YZPFWqKzjaOiK1B
OUMQ+cLGOue313Du/SxfkWk/frZQqvMnpKz/ukP/TFDWbijBzRQ8UycVbyjZ/glHd/2Dsx299RxP
72E1pCZU6cfA1adwy/RxPyfiH5BJOYLjs13QTmLdZdLbqKKVrcKzZj3oXWPTRvJ5XjI8n/1F+dcI
gaO5vRAL3jnN7piQc7Ui6hsv62qq7gz9Yw3lClO4WJWWTzo/y/fiLuX0r5B+yopPGTJ5TbkiFLGk
OHkMPu+OW8IKy+5GyixY9gW/CKywA+HEzfdOweCm5gdZZQGFOAhckSDF+/ojaI0knmc9CuYxzVHQ
pmE0jAHvDlxJ5OCEfbJEHIc6mBaGyO4UcaN0wNqclP81Cfo8Dc9MkzD2DePRDpyD2tx/Ab2YjMeh
SdYun7bIA8pOaQMsWqGmbchyb7hYPIZF02I8es/yas9NjnXubiRrFIl78UPCQ8DGLfek/Etk0pmH
xnSuXkvc2T9TYgUIhFBBjTa7zOw063qAJuUTVTKkneh/BSycbNcCCdDsGoNFOOi/oyi8TRwHUT2c
8+jKyRa/8/01/UrPfPf7T981WY8ifIN3SVKskgObjRrJGwKyCxdGPqUF1LMimh/EoCPb0ocHPPjQ
30w9mBG0otlWpIZwStP11d7b0wxZpqE3BiU2TvAyXLCpIZNJgcPGigo7fsifmCm1mCIkkemqf3yD
dpraP1p3v7pJ7uO2yGJObJxAUGLtkWGAqP7oj+jz5T1zyGbfAzU9xrQXxvbaYZRqYPTazXHFuiYH
jmmreEYcTs3AXRPvGwbEtAu9Joz6bReQArc2FOW8HQ3/Hu3IjBE0Cs6BIdhwO8JilSE2py/cI/Jn
Cask8ZuaV/aGaCoEqw5KlPGG045DJxcGs2gmvJo5T3hBLCUHWflVcobbMHA4YZSJoFqswzblU7SU
2dhxGJuvLLKHsj5mdn+XrUB7WbzIfFBOGQU+I5o4L4/u4Z0J7Ez4pg==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
