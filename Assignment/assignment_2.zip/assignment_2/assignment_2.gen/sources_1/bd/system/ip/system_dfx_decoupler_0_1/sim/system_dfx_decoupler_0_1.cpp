// (c) Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// (c) Copyright 2022-2026 Advanced Micro Devices, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


#include "system_dfx_decoupler_0_1_sc.h"

#include "system_dfx_decoupler_0_1.h"

#include "system_dfx_decoupler_0_1_core.h"

#include <map>
#include <string>





#ifdef XILINX_SIMULATOR
system_dfx_decoupler_0_1::system_dfx_decoupler_0_1(const sc_core::sc_module_name& nm) : system_dfx_decoupler_0_1_sc(nm), s_intf_0_ARVALID("s_intf_0_ARVALID"), rp_intf_0_ARVALID("rp_intf_0_ARVALID"), s_intf_0_ARREADY("s_intf_0_ARREADY"), rp_intf_0_ARREADY("rp_intf_0_ARREADY"), s_intf_0_AWVALID("s_intf_0_AWVALID"), rp_intf_0_AWVALID("rp_intf_0_AWVALID"), s_intf_0_AWREADY("s_intf_0_AWREADY"), rp_intf_0_AWREADY("rp_intf_0_AWREADY"), s_intf_0_BVALID("s_intf_0_BVALID"), rp_intf_0_BVALID("rp_intf_0_BVALID"), s_intf_0_BREADY("s_intf_0_BREADY"), rp_intf_0_BREADY("rp_intf_0_BREADY"), s_intf_0_RVALID("s_intf_0_RVALID"), rp_intf_0_RVALID("rp_intf_0_RVALID"), s_intf_0_RREADY("s_intf_0_RREADY"), rp_intf_0_RREADY("rp_intf_0_RREADY"), s_intf_0_WVALID("s_intf_0_WVALID"), rp_intf_0_WVALID("rp_intf_0_WVALID"), s_intf_0_WREADY("s_intf_0_WREADY"), rp_intf_0_WREADY("rp_intf_0_WREADY"), s_intf_0_AWADDR("s_intf_0_AWADDR"), rp_intf_0_AWADDR("rp_intf_0_AWADDR"), s_intf_0_WDATA("s_intf_0_WDATA"), rp_intf_0_WDATA("rp_intf_0_WDATA"), s_intf_0_WSTRB("s_intf_0_WSTRB"), rp_intf_0_WSTRB("rp_intf_0_WSTRB"), s_intf_0_BRESP("s_intf_0_BRESP"), rp_intf_0_BRESP("rp_intf_0_BRESP"), s_intf_0_ARADDR("s_intf_0_ARADDR"), rp_intf_0_ARADDR("rp_intf_0_ARADDR"), s_intf_0_RDATA("s_intf_0_RDATA"), rp_intf_0_RDATA("rp_intf_0_RDATA"), s_intf_0_RRESP("s_intf_0_RRESP"), rp_intf_0_RRESP("rp_intf_0_RRESP"), intf_0_aclk("intf_0_aclk"), intf_0_arstn("intf_0_arstn"), decouple("decouple"), decouple_status("decouple_status")
{

  // initialize pins
  mp_impl->intf_0_aclk(intf_0_aclk);
  mp_impl->intf_0_arstn(intf_0_arstn);
  mp_impl->decouple(decouple);
  mp_impl->decouple_status(decouple_status);

  // initialize transactors
  mp_s_intf_0_transactor = NULL;
  mp_rp_intf_0_transactor = NULL;

  // initialize socket stubs

}

void system_dfx_decoupler_0_1::before_end_of_elaboration()
{
  // configure 's_intf_0' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("system_dfx_decoupler_0_1", "s_intf_0_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_intf_0' transactor parameters
    xsc::common_cpp::properties s_intf_0_transactor_param_props;
    s_intf_0_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_intf_0_transactor_param_props.addLong("FREQ_HZ", "90909088");
    s_intf_0_transactor_param_props.addLong("ID_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("ADDR_WIDTH", "31");
    s_intf_0_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("HAS_BURST", "0");
    s_intf_0_transactor_param_props.addLong("HAS_LOCK", "0");
    s_intf_0_transactor_param_props.addLong("HAS_PROT", "0");
    s_intf_0_transactor_param_props.addLong("HAS_CACHE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_QOS", "0");
    s_intf_0_transactor_param_props.addLong("HAS_REGION", "0");
    s_intf_0_transactor_param_props.addLong("HAS_WSTRB", "1");
    s_intf_0_transactor_param_props.addLong("HAS_BRESP", "1");
    s_intf_0_transactor_param_props.addLong("HAS_RRESP", "1");
    s_intf_0_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_intf_0_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_intf_0_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_intf_0_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_intf_0_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_intf_0_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_intf_0_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_intf_0_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_SIZE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_RESET", "1");
    s_intf_0_transactor_param_props.addFloat("PHASE", "0.0");
    s_intf_0_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_intf_0_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_intf_0_transactor_param_props.addString("CLK_DOMAIN", "system_processing_system7_0_0_FCLK_CLK0");
    s_intf_0_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_s_intf_0_transactor = new xtlm::xaximm_pin2xtlm_t<32,31,1,1,1,1,1,1>("s_intf_0_transactor", s_intf_0_transactor_param_props);

    // s_intf_0' transactor ports

    mp_s_intf_0_transactor->ARVALID(s_intf_0_ARVALID);
    mp_s_intf_0_transactor->ARREADY(s_intf_0_ARREADY);
    mp_s_intf_0_transactor->AWVALID(s_intf_0_AWVALID);
    mp_s_intf_0_transactor->AWREADY(s_intf_0_AWREADY);
    mp_s_intf_0_transactor->BVALID(s_intf_0_BVALID);
    mp_s_intf_0_transactor->BREADY(s_intf_0_BREADY);
    mp_s_intf_0_transactor->RVALID(s_intf_0_RVALID);
    mp_s_intf_0_transactor->RREADY(s_intf_0_RREADY);
    mp_s_intf_0_transactor->WVALID(s_intf_0_WVALID);
    mp_s_intf_0_transactor->WREADY(s_intf_0_WREADY);
    mp_s_intf_0_transactor->AWADDR(s_intf_0_AWADDR);
    mp_s_intf_0_transactor->WDATA(s_intf_0_WDATA);
    mp_s_intf_0_transactor->WSTRB(s_intf_0_WSTRB);
    mp_s_intf_0_transactor->BRESP(s_intf_0_BRESP);
    mp_s_intf_0_transactor->ARADDR(s_intf_0_ARADDR);
    mp_s_intf_0_transactor->RDATA(s_intf_0_RDATA);
    mp_s_intf_0_transactor->RRESP(s_intf_0_RRESP);
    mp_s_intf_0_transactor->CLK(intf_0_aclk);
    mp_s_intf_0_transactor->RST(intf_0_arstn);

    // s_intf_0' transactor sockets

    mp_impl->S00_AXIMM_TARGET_wr_SOCKET->bind(*(mp_s_intf_0_transactor->wr_socket));
    mp_impl->S00_AXIMM_TARGET_rd_SOCKET->bind(*(mp_s_intf_0_transactor->rd_socket));
  }
  else
  {
  }

  // configure 'rp_intf_0' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("system_dfx_decoupler_0_1", "rp_intf_0_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_intf_0' transactor parameters
    xsc::common_cpp::properties rp_intf_0_transactor_param_props;
    rp_intf_0_transactor_param_props.addLong("DATA_WIDTH", "32");
    rp_intf_0_transactor_param_props.addLong("FREQ_HZ", "90909088");
    rp_intf_0_transactor_param_props.addLong("ID_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("ADDR_WIDTH", "31");
    rp_intf_0_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("WUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("RUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("BUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_BURST", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_LOCK", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_PROT", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_CACHE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_QOS", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_REGION", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_WSTRB", "1");
    rp_intf_0_transactor_param_props.addLong("HAS_BRESP", "1");
    rp_intf_0_transactor_param_props.addLong("HAS_RRESP", "1");
    rp_intf_0_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    rp_intf_0_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    rp_intf_0_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    rp_intf_0_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    rp_intf_0_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_SIZE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_RESET", "1");
    rp_intf_0_transactor_param_props.addFloat("PHASE", "0.0");
    rp_intf_0_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    rp_intf_0_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    rp_intf_0_transactor_param_props.addString("CLK_DOMAIN", "system_processing_system7_0_0_FCLK_CLK0");
    rp_intf_0_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_rp_intf_0_transactor = new xtlm::xaximm_xtlm2pin_t<32,31,1,1,1,1,1,1>("rp_intf_0_transactor", rp_intf_0_transactor_param_props);

    // rp_intf_0' transactor ports

    mp_rp_intf_0_transactor->ARVALID(rp_intf_0_ARVALID);
    mp_rp_intf_0_transactor->ARREADY(rp_intf_0_ARREADY);
    mp_rp_intf_0_transactor->AWVALID(rp_intf_0_AWVALID);
    mp_rp_intf_0_transactor->AWREADY(rp_intf_0_AWREADY);
    mp_rp_intf_0_transactor->BVALID(rp_intf_0_BVALID);
    mp_rp_intf_0_transactor->BREADY(rp_intf_0_BREADY);
    mp_rp_intf_0_transactor->RVALID(rp_intf_0_RVALID);
    mp_rp_intf_0_transactor->RREADY(rp_intf_0_RREADY);
    mp_rp_intf_0_transactor->WVALID(rp_intf_0_WVALID);
    mp_rp_intf_0_transactor->WREADY(rp_intf_0_WREADY);
    mp_rp_intf_0_transactor->AWADDR(rp_intf_0_AWADDR);
    mp_rp_intf_0_transactor->WDATA(rp_intf_0_WDATA);
    mp_rp_intf_0_transactor->WSTRB(rp_intf_0_WSTRB);
    mp_rp_intf_0_transactor->BRESP(rp_intf_0_BRESP);
    mp_rp_intf_0_transactor->ARADDR(rp_intf_0_ARADDR);
    mp_rp_intf_0_transactor->RDATA(rp_intf_0_RDATA);
    mp_rp_intf_0_transactor->RRESP(rp_intf_0_RRESP);
    mp_rp_intf_0_transactor->CLK(intf_0_aclk);
    mp_rp_intf_0_transactor->RST(intf_0_arstn);

    // rp_intf_0' transactor sockets

    mp_impl->M00_AXIMM_INITIATOR_wr_SOCKET->bind(*(mp_rp_intf_0_transactor->wr_socket));
    mp_impl->M00_AXIMM_INITIATOR_rd_SOCKET->bind(*(mp_rp_intf_0_transactor->rd_socket));
  }
  else
  {
  }

}

#endif // XILINX_SIMULATOR




#ifdef XM_SYSTEMC
system_dfx_decoupler_0_1::system_dfx_decoupler_0_1(const sc_core::sc_module_name& nm) : system_dfx_decoupler_0_1_sc(nm), s_intf_0_ARVALID("s_intf_0_ARVALID"), rp_intf_0_ARVALID("rp_intf_0_ARVALID"), s_intf_0_ARREADY("s_intf_0_ARREADY"), rp_intf_0_ARREADY("rp_intf_0_ARREADY"), s_intf_0_AWVALID("s_intf_0_AWVALID"), rp_intf_0_AWVALID("rp_intf_0_AWVALID"), s_intf_0_AWREADY("s_intf_0_AWREADY"), rp_intf_0_AWREADY("rp_intf_0_AWREADY"), s_intf_0_BVALID("s_intf_0_BVALID"), rp_intf_0_BVALID("rp_intf_0_BVALID"), s_intf_0_BREADY("s_intf_0_BREADY"), rp_intf_0_BREADY("rp_intf_0_BREADY"), s_intf_0_RVALID("s_intf_0_RVALID"), rp_intf_0_RVALID("rp_intf_0_RVALID"), s_intf_0_RREADY("s_intf_0_RREADY"), rp_intf_0_RREADY("rp_intf_0_RREADY"), s_intf_0_WVALID("s_intf_0_WVALID"), rp_intf_0_WVALID("rp_intf_0_WVALID"), s_intf_0_WREADY("s_intf_0_WREADY"), rp_intf_0_WREADY("rp_intf_0_WREADY"), s_intf_0_AWADDR("s_intf_0_AWADDR"), rp_intf_0_AWADDR("rp_intf_0_AWADDR"), s_intf_0_WDATA("s_intf_0_WDATA"), rp_intf_0_WDATA("rp_intf_0_WDATA"), s_intf_0_WSTRB("s_intf_0_WSTRB"), rp_intf_0_WSTRB("rp_intf_0_WSTRB"), s_intf_0_BRESP("s_intf_0_BRESP"), rp_intf_0_BRESP("rp_intf_0_BRESP"), s_intf_0_ARADDR("s_intf_0_ARADDR"), rp_intf_0_ARADDR("rp_intf_0_ARADDR"), s_intf_0_RDATA("s_intf_0_RDATA"), rp_intf_0_RDATA("rp_intf_0_RDATA"), s_intf_0_RRESP("s_intf_0_RRESP"), rp_intf_0_RRESP("rp_intf_0_RRESP"), intf_0_aclk("intf_0_aclk"), intf_0_arstn("intf_0_arstn"), decouple("decouple"), decouple_status("decouple_status")
{

  // initialize pins
  mp_impl->intf_0_aclk(intf_0_aclk);
  mp_impl->intf_0_arstn(intf_0_arstn);
  mp_impl->decouple(decouple);
  mp_impl->decouple_status(decouple_status);

  // initialize transactors
  mp_s_intf_0_transactor = NULL;
  mp_rp_intf_0_transactor = NULL;

  // initialize socket stubs

}

void system_dfx_decoupler_0_1::before_end_of_elaboration()
{
  // configure 's_intf_0' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("system_dfx_decoupler_0_1", "s_intf_0_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_intf_0' transactor parameters
    xsc::common_cpp::properties s_intf_0_transactor_param_props;
    s_intf_0_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_intf_0_transactor_param_props.addLong("FREQ_HZ", "90909088");
    s_intf_0_transactor_param_props.addLong("ID_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("ADDR_WIDTH", "31");
    s_intf_0_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("HAS_BURST", "0");
    s_intf_0_transactor_param_props.addLong("HAS_LOCK", "0");
    s_intf_0_transactor_param_props.addLong("HAS_PROT", "0");
    s_intf_0_transactor_param_props.addLong("HAS_CACHE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_QOS", "0");
    s_intf_0_transactor_param_props.addLong("HAS_REGION", "0");
    s_intf_0_transactor_param_props.addLong("HAS_WSTRB", "1");
    s_intf_0_transactor_param_props.addLong("HAS_BRESP", "1");
    s_intf_0_transactor_param_props.addLong("HAS_RRESP", "1");
    s_intf_0_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_intf_0_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_intf_0_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_intf_0_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_intf_0_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_intf_0_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_intf_0_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_intf_0_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_SIZE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_RESET", "1");
    s_intf_0_transactor_param_props.addFloat("PHASE", "0.0");
    s_intf_0_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_intf_0_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_intf_0_transactor_param_props.addString("CLK_DOMAIN", "system_processing_system7_0_0_FCLK_CLK0");
    s_intf_0_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_s_intf_0_transactor = new xtlm::xaximm_pin2xtlm_t<32,31,1,1,1,1,1,1>("s_intf_0_transactor", s_intf_0_transactor_param_props);

    // s_intf_0' transactor ports

    mp_s_intf_0_transactor->ARVALID(s_intf_0_ARVALID);
    mp_s_intf_0_transactor->ARREADY(s_intf_0_ARREADY);
    mp_s_intf_0_transactor->AWVALID(s_intf_0_AWVALID);
    mp_s_intf_0_transactor->AWREADY(s_intf_0_AWREADY);
    mp_s_intf_0_transactor->BVALID(s_intf_0_BVALID);
    mp_s_intf_0_transactor->BREADY(s_intf_0_BREADY);
    mp_s_intf_0_transactor->RVALID(s_intf_0_RVALID);
    mp_s_intf_0_transactor->RREADY(s_intf_0_RREADY);
    mp_s_intf_0_transactor->WVALID(s_intf_0_WVALID);
    mp_s_intf_0_transactor->WREADY(s_intf_0_WREADY);
    mp_s_intf_0_transactor->AWADDR(s_intf_0_AWADDR);
    mp_s_intf_0_transactor->WDATA(s_intf_0_WDATA);
    mp_s_intf_0_transactor->WSTRB(s_intf_0_WSTRB);
    mp_s_intf_0_transactor->BRESP(s_intf_0_BRESP);
    mp_s_intf_0_transactor->ARADDR(s_intf_0_ARADDR);
    mp_s_intf_0_transactor->RDATA(s_intf_0_RDATA);
    mp_s_intf_0_transactor->RRESP(s_intf_0_RRESP);
    mp_s_intf_0_transactor->CLK(intf_0_aclk);
    mp_s_intf_0_transactor->RST(intf_0_arstn);

    // s_intf_0' transactor sockets

    mp_impl->S00_AXIMM_TARGET_wr_SOCKET->bind(*(mp_s_intf_0_transactor->wr_socket));
    mp_impl->S00_AXIMM_TARGET_rd_SOCKET->bind(*(mp_s_intf_0_transactor->rd_socket));
  }
  else
  {
  }

  // configure 'rp_intf_0' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("system_dfx_decoupler_0_1", "rp_intf_0_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_intf_0' transactor parameters
    xsc::common_cpp::properties rp_intf_0_transactor_param_props;
    rp_intf_0_transactor_param_props.addLong("DATA_WIDTH", "32");
    rp_intf_0_transactor_param_props.addLong("FREQ_HZ", "90909088");
    rp_intf_0_transactor_param_props.addLong("ID_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("ADDR_WIDTH", "31");
    rp_intf_0_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("WUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("RUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("BUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_BURST", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_LOCK", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_PROT", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_CACHE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_QOS", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_REGION", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_WSTRB", "1");
    rp_intf_0_transactor_param_props.addLong("HAS_BRESP", "1");
    rp_intf_0_transactor_param_props.addLong("HAS_RRESP", "1");
    rp_intf_0_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    rp_intf_0_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    rp_intf_0_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    rp_intf_0_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    rp_intf_0_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_SIZE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_RESET", "1");
    rp_intf_0_transactor_param_props.addFloat("PHASE", "0.0");
    rp_intf_0_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    rp_intf_0_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    rp_intf_0_transactor_param_props.addString("CLK_DOMAIN", "system_processing_system7_0_0_FCLK_CLK0");
    rp_intf_0_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_rp_intf_0_transactor = new xtlm::xaximm_xtlm2pin_t<32,31,1,1,1,1,1,1>("rp_intf_0_transactor", rp_intf_0_transactor_param_props);

    // rp_intf_0' transactor ports

    mp_rp_intf_0_transactor->ARVALID(rp_intf_0_ARVALID);
    mp_rp_intf_0_transactor->ARREADY(rp_intf_0_ARREADY);
    mp_rp_intf_0_transactor->AWVALID(rp_intf_0_AWVALID);
    mp_rp_intf_0_transactor->AWREADY(rp_intf_0_AWREADY);
    mp_rp_intf_0_transactor->BVALID(rp_intf_0_BVALID);
    mp_rp_intf_0_transactor->BREADY(rp_intf_0_BREADY);
    mp_rp_intf_0_transactor->RVALID(rp_intf_0_RVALID);
    mp_rp_intf_0_transactor->RREADY(rp_intf_0_RREADY);
    mp_rp_intf_0_transactor->WVALID(rp_intf_0_WVALID);
    mp_rp_intf_0_transactor->WREADY(rp_intf_0_WREADY);
    mp_rp_intf_0_transactor->AWADDR(rp_intf_0_AWADDR);
    mp_rp_intf_0_transactor->WDATA(rp_intf_0_WDATA);
    mp_rp_intf_0_transactor->WSTRB(rp_intf_0_WSTRB);
    mp_rp_intf_0_transactor->BRESP(rp_intf_0_BRESP);
    mp_rp_intf_0_transactor->ARADDR(rp_intf_0_ARADDR);
    mp_rp_intf_0_transactor->RDATA(rp_intf_0_RDATA);
    mp_rp_intf_0_transactor->RRESP(rp_intf_0_RRESP);
    mp_rp_intf_0_transactor->CLK(intf_0_aclk);
    mp_rp_intf_0_transactor->RST(intf_0_arstn);

    // rp_intf_0' transactor sockets

    mp_impl->M00_AXIMM_INITIATOR_wr_SOCKET->bind(*(mp_rp_intf_0_transactor->wr_socket));
    mp_impl->M00_AXIMM_INITIATOR_rd_SOCKET->bind(*(mp_rp_intf_0_transactor->rd_socket));
  }
  else
  {
  }

}

#endif // XM_SYSTEMC




#ifdef RIVIERA
system_dfx_decoupler_0_1::system_dfx_decoupler_0_1(const sc_core::sc_module_name& nm) : system_dfx_decoupler_0_1_sc(nm), s_intf_0_ARVALID("s_intf_0_ARVALID"), rp_intf_0_ARVALID("rp_intf_0_ARVALID"), s_intf_0_ARREADY("s_intf_0_ARREADY"), rp_intf_0_ARREADY("rp_intf_0_ARREADY"), s_intf_0_AWVALID("s_intf_0_AWVALID"), rp_intf_0_AWVALID("rp_intf_0_AWVALID"), s_intf_0_AWREADY("s_intf_0_AWREADY"), rp_intf_0_AWREADY("rp_intf_0_AWREADY"), s_intf_0_BVALID("s_intf_0_BVALID"), rp_intf_0_BVALID("rp_intf_0_BVALID"), s_intf_0_BREADY("s_intf_0_BREADY"), rp_intf_0_BREADY("rp_intf_0_BREADY"), s_intf_0_RVALID("s_intf_0_RVALID"), rp_intf_0_RVALID("rp_intf_0_RVALID"), s_intf_0_RREADY("s_intf_0_RREADY"), rp_intf_0_RREADY("rp_intf_0_RREADY"), s_intf_0_WVALID("s_intf_0_WVALID"), rp_intf_0_WVALID("rp_intf_0_WVALID"), s_intf_0_WREADY("s_intf_0_WREADY"), rp_intf_0_WREADY("rp_intf_0_WREADY"), s_intf_0_AWADDR("s_intf_0_AWADDR"), rp_intf_0_AWADDR("rp_intf_0_AWADDR"), s_intf_0_WDATA("s_intf_0_WDATA"), rp_intf_0_WDATA("rp_intf_0_WDATA"), s_intf_0_WSTRB("s_intf_0_WSTRB"), rp_intf_0_WSTRB("rp_intf_0_WSTRB"), s_intf_0_BRESP("s_intf_0_BRESP"), rp_intf_0_BRESP("rp_intf_0_BRESP"), s_intf_0_ARADDR("s_intf_0_ARADDR"), rp_intf_0_ARADDR("rp_intf_0_ARADDR"), s_intf_0_RDATA("s_intf_0_RDATA"), rp_intf_0_RDATA("rp_intf_0_RDATA"), s_intf_0_RRESP("s_intf_0_RRESP"), rp_intf_0_RRESP("rp_intf_0_RRESP"), intf_0_aclk("intf_0_aclk"), intf_0_arstn("intf_0_arstn"), decouple("decouple"), decouple_status("decouple_status")
{

  // initialize pins
  mp_impl->intf_0_aclk(intf_0_aclk);
  mp_impl->intf_0_arstn(intf_0_arstn);
  mp_impl->decouple(decouple);
  mp_impl->decouple_status(decouple_status);

  // initialize transactors
  mp_s_intf_0_transactor = NULL;
  mp_rp_intf_0_transactor = NULL;

  // initialize socket stubs

}

void system_dfx_decoupler_0_1::before_end_of_elaboration()
{
  // configure 's_intf_0' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("system_dfx_decoupler_0_1", "s_intf_0_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_intf_0' transactor parameters
    xsc::common_cpp::properties s_intf_0_transactor_param_props;
    s_intf_0_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_intf_0_transactor_param_props.addLong("FREQ_HZ", "90909088");
    s_intf_0_transactor_param_props.addLong("ID_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("ADDR_WIDTH", "31");
    s_intf_0_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("HAS_BURST", "0");
    s_intf_0_transactor_param_props.addLong("HAS_LOCK", "0");
    s_intf_0_transactor_param_props.addLong("HAS_PROT", "0");
    s_intf_0_transactor_param_props.addLong("HAS_CACHE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_QOS", "0");
    s_intf_0_transactor_param_props.addLong("HAS_REGION", "0");
    s_intf_0_transactor_param_props.addLong("HAS_WSTRB", "1");
    s_intf_0_transactor_param_props.addLong("HAS_BRESP", "1");
    s_intf_0_transactor_param_props.addLong("HAS_RRESP", "1");
    s_intf_0_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_intf_0_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_intf_0_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_intf_0_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_intf_0_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_intf_0_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_intf_0_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_intf_0_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_SIZE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_RESET", "1");
    s_intf_0_transactor_param_props.addFloat("PHASE", "0.0");
    s_intf_0_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_intf_0_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_intf_0_transactor_param_props.addString("CLK_DOMAIN", "system_processing_system7_0_0_FCLK_CLK0");
    s_intf_0_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_s_intf_0_transactor = new xtlm::xaximm_pin2xtlm_t<32,31,1,1,1,1,1,1>("s_intf_0_transactor", s_intf_0_transactor_param_props);

    // s_intf_0' transactor ports

    mp_s_intf_0_transactor->ARVALID(s_intf_0_ARVALID);
    mp_s_intf_0_transactor->ARREADY(s_intf_0_ARREADY);
    mp_s_intf_0_transactor->AWVALID(s_intf_0_AWVALID);
    mp_s_intf_0_transactor->AWREADY(s_intf_0_AWREADY);
    mp_s_intf_0_transactor->BVALID(s_intf_0_BVALID);
    mp_s_intf_0_transactor->BREADY(s_intf_0_BREADY);
    mp_s_intf_0_transactor->RVALID(s_intf_0_RVALID);
    mp_s_intf_0_transactor->RREADY(s_intf_0_RREADY);
    mp_s_intf_0_transactor->WVALID(s_intf_0_WVALID);
    mp_s_intf_0_transactor->WREADY(s_intf_0_WREADY);
    mp_s_intf_0_transactor->AWADDR(s_intf_0_AWADDR);
    mp_s_intf_0_transactor->WDATA(s_intf_0_WDATA);
    mp_s_intf_0_transactor->WSTRB(s_intf_0_WSTRB);
    mp_s_intf_0_transactor->BRESP(s_intf_0_BRESP);
    mp_s_intf_0_transactor->ARADDR(s_intf_0_ARADDR);
    mp_s_intf_0_transactor->RDATA(s_intf_0_RDATA);
    mp_s_intf_0_transactor->RRESP(s_intf_0_RRESP);
    mp_s_intf_0_transactor->CLK(intf_0_aclk);
    mp_s_intf_0_transactor->RST(intf_0_arstn);

    // s_intf_0' transactor sockets

    mp_impl->S00_AXIMM_TARGET_wr_SOCKET->bind(*(mp_s_intf_0_transactor->wr_socket));
    mp_impl->S00_AXIMM_TARGET_rd_SOCKET->bind(*(mp_s_intf_0_transactor->rd_socket));
  }
  else
  {
  }

  // configure 'rp_intf_0' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("system_dfx_decoupler_0_1", "rp_intf_0_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_intf_0' transactor parameters
    xsc::common_cpp::properties rp_intf_0_transactor_param_props;
    rp_intf_0_transactor_param_props.addLong("DATA_WIDTH", "32");
    rp_intf_0_transactor_param_props.addLong("FREQ_HZ", "90909088");
    rp_intf_0_transactor_param_props.addLong("ID_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("ADDR_WIDTH", "31");
    rp_intf_0_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("WUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("RUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("BUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_BURST", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_LOCK", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_PROT", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_CACHE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_QOS", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_REGION", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_WSTRB", "1");
    rp_intf_0_transactor_param_props.addLong("HAS_BRESP", "1");
    rp_intf_0_transactor_param_props.addLong("HAS_RRESP", "1");
    rp_intf_0_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    rp_intf_0_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    rp_intf_0_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    rp_intf_0_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    rp_intf_0_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_SIZE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_RESET", "1");
    rp_intf_0_transactor_param_props.addFloat("PHASE", "0.0");
    rp_intf_0_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    rp_intf_0_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    rp_intf_0_transactor_param_props.addString("CLK_DOMAIN", "system_processing_system7_0_0_FCLK_CLK0");
    rp_intf_0_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_rp_intf_0_transactor = new xtlm::xaximm_xtlm2pin_t<32,31,1,1,1,1,1,1>("rp_intf_0_transactor", rp_intf_0_transactor_param_props);

    // rp_intf_0' transactor ports

    mp_rp_intf_0_transactor->ARVALID(rp_intf_0_ARVALID);
    mp_rp_intf_0_transactor->ARREADY(rp_intf_0_ARREADY);
    mp_rp_intf_0_transactor->AWVALID(rp_intf_0_AWVALID);
    mp_rp_intf_0_transactor->AWREADY(rp_intf_0_AWREADY);
    mp_rp_intf_0_transactor->BVALID(rp_intf_0_BVALID);
    mp_rp_intf_0_transactor->BREADY(rp_intf_0_BREADY);
    mp_rp_intf_0_transactor->RVALID(rp_intf_0_RVALID);
    mp_rp_intf_0_transactor->RREADY(rp_intf_0_RREADY);
    mp_rp_intf_0_transactor->WVALID(rp_intf_0_WVALID);
    mp_rp_intf_0_transactor->WREADY(rp_intf_0_WREADY);
    mp_rp_intf_0_transactor->AWADDR(rp_intf_0_AWADDR);
    mp_rp_intf_0_transactor->WDATA(rp_intf_0_WDATA);
    mp_rp_intf_0_transactor->WSTRB(rp_intf_0_WSTRB);
    mp_rp_intf_0_transactor->BRESP(rp_intf_0_BRESP);
    mp_rp_intf_0_transactor->ARADDR(rp_intf_0_ARADDR);
    mp_rp_intf_0_transactor->RDATA(rp_intf_0_RDATA);
    mp_rp_intf_0_transactor->RRESP(rp_intf_0_RRESP);
    mp_rp_intf_0_transactor->CLK(intf_0_aclk);
    mp_rp_intf_0_transactor->RST(intf_0_arstn);

    // rp_intf_0' transactor sockets

    mp_impl->M00_AXIMM_INITIATOR_wr_SOCKET->bind(*(mp_rp_intf_0_transactor->wr_socket));
    mp_impl->M00_AXIMM_INITIATOR_rd_SOCKET->bind(*(mp_rp_intf_0_transactor->rd_socket));
  }
  else
  {
  }

}

#endif // RIVIERA




#ifdef VCSSYSTEMC
system_dfx_decoupler_0_1::system_dfx_decoupler_0_1(const sc_core::sc_module_name& nm) : system_dfx_decoupler_0_1_sc(nm),  s_intf_0_ARVALID("s_intf_0_ARVALID"), rp_intf_0_ARVALID("rp_intf_0_ARVALID"), s_intf_0_ARREADY("s_intf_0_ARREADY"), rp_intf_0_ARREADY("rp_intf_0_ARREADY"), s_intf_0_AWVALID("s_intf_0_AWVALID"), rp_intf_0_AWVALID("rp_intf_0_AWVALID"), s_intf_0_AWREADY("s_intf_0_AWREADY"), rp_intf_0_AWREADY("rp_intf_0_AWREADY"), s_intf_0_BVALID("s_intf_0_BVALID"), rp_intf_0_BVALID("rp_intf_0_BVALID"), s_intf_0_BREADY("s_intf_0_BREADY"), rp_intf_0_BREADY("rp_intf_0_BREADY"), s_intf_0_RVALID("s_intf_0_RVALID"), rp_intf_0_RVALID("rp_intf_0_RVALID"), s_intf_0_RREADY("s_intf_0_RREADY"), rp_intf_0_RREADY("rp_intf_0_RREADY"), s_intf_0_WVALID("s_intf_0_WVALID"), rp_intf_0_WVALID("rp_intf_0_WVALID"), s_intf_0_WREADY("s_intf_0_WREADY"), rp_intf_0_WREADY("rp_intf_0_WREADY"), s_intf_0_AWADDR("s_intf_0_AWADDR"), rp_intf_0_AWADDR("rp_intf_0_AWADDR"), s_intf_0_WDATA("s_intf_0_WDATA"), rp_intf_0_WDATA("rp_intf_0_WDATA"), s_intf_0_WSTRB("s_intf_0_WSTRB"), rp_intf_0_WSTRB("rp_intf_0_WSTRB"), s_intf_0_BRESP("s_intf_0_BRESP"), rp_intf_0_BRESP("rp_intf_0_BRESP"), s_intf_0_ARADDR("s_intf_0_ARADDR"), rp_intf_0_ARADDR("rp_intf_0_ARADDR"), s_intf_0_RDATA("s_intf_0_RDATA"), rp_intf_0_RDATA("rp_intf_0_RDATA"), s_intf_0_RRESP("s_intf_0_RRESP"), rp_intf_0_RRESP("rp_intf_0_RRESP"), intf_0_aclk("intf_0_aclk"), intf_0_arstn("intf_0_arstn"), decouple("decouple"), decouple_status("decouple_status")
{
  // initialize pins
  mp_impl->intf_0_aclk(intf_0_aclk);
  mp_impl->intf_0_arstn(intf_0_arstn);
  mp_impl->decouple(decouple);
  mp_impl->decouple_status(decouple_status);

  // initialize transactors
  mp_s_intf_0_transactor = NULL;
  mp_rp_intf_0_transactor = NULL;

  // Instantiate Socket Stubs

  // configure s_intf_0_transactor
    xsc::common_cpp::properties s_intf_0_transactor_param_props;
    s_intf_0_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_intf_0_transactor_param_props.addLong("FREQ_HZ", "90909088");
    s_intf_0_transactor_param_props.addLong("ID_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("ADDR_WIDTH", "31");
    s_intf_0_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("HAS_BURST", "0");
    s_intf_0_transactor_param_props.addLong("HAS_LOCK", "0");
    s_intf_0_transactor_param_props.addLong("HAS_PROT", "0");
    s_intf_0_transactor_param_props.addLong("HAS_CACHE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_QOS", "0");
    s_intf_0_transactor_param_props.addLong("HAS_REGION", "0");
    s_intf_0_transactor_param_props.addLong("HAS_WSTRB", "1");
    s_intf_0_transactor_param_props.addLong("HAS_BRESP", "1");
    s_intf_0_transactor_param_props.addLong("HAS_RRESP", "1");
    s_intf_0_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_intf_0_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_intf_0_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_intf_0_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_intf_0_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_intf_0_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_intf_0_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_intf_0_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_SIZE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_RESET", "1");
    s_intf_0_transactor_param_props.addFloat("PHASE", "0.0");
    s_intf_0_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_intf_0_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_intf_0_transactor_param_props.addString("CLK_DOMAIN", "system_processing_system7_0_0_FCLK_CLK0");
    s_intf_0_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_s_intf_0_transactor = new xtlm::xaximm_pin2xtlm_t<32,31,1,1,1,1,1,1>("s_intf_0_transactor", s_intf_0_transactor_param_props);
  mp_s_intf_0_transactor->ARVALID(s_intf_0_ARVALID);
  mp_s_intf_0_transactor->ARREADY(s_intf_0_ARREADY);
  mp_s_intf_0_transactor->AWVALID(s_intf_0_AWVALID);
  mp_s_intf_0_transactor->AWREADY(s_intf_0_AWREADY);
  mp_s_intf_0_transactor->BVALID(s_intf_0_BVALID);
  mp_s_intf_0_transactor->BREADY(s_intf_0_BREADY);
  mp_s_intf_0_transactor->RVALID(s_intf_0_RVALID);
  mp_s_intf_0_transactor->RREADY(s_intf_0_RREADY);
  mp_s_intf_0_transactor->WVALID(s_intf_0_WVALID);
  mp_s_intf_0_transactor->WREADY(s_intf_0_WREADY);
  mp_s_intf_0_transactor->AWADDR(s_intf_0_AWADDR);
  mp_s_intf_0_transactor->WDATA(s_intf_0_WDATA);
  mp_s_intf_0_transactor->WSTRB(s_intf_0_WSTRB);
  mp_s_intf_0_transactor->BRESP(s_intf_0_BRESP);
  mp_s_intf_0_transactor->ARADDR(s_intf_0_ARADDR);
  mp_s_intf_0_transactor->RDATA(s_intf_0_RDATA);
  mp_s_intf_0_transactor->RRESP(s_intf_0_RRESP);
  mp_s_intf_0_transactor->CLK(intf_0_aclk);
  mp_s_intf_0_transactor->RST(intf_0_arstn);
  // configure rp_intf_0_transactor
    xsc::common_cpp::properties rp_intf_0_transactor_param_props;
    rp_intf_0_transactor_param_props.addLong("DATA_WIDTH", "32");
    rp_intf_0_transactor_param_props.addLong("FREQ_HZ", "90909088");
    rp_intf_0_transactor_param_props.addLong("ID_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("ADDR_WIDTH", "31");
    rp_intf_0_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("WUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("RUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("BUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_BURST", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_LOCK", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_PROT", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_CACHE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_QOS", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_REGION", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_WSTRB", "1");
    rp_intf_0_transactor_param_props.addLong("HAS_BRESP", "1");
    rp_intf_0_transactor_param_props.addLong("HAS_RRESP", "1");
    rp_intf_0_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    rp_intf_0_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    rp_intf_0_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    rp_intf_0_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    rp_intf_0_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_SIZE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_RESET", "1");
    rp_intf_0_transactor_param_props.addFloat("PHASE", "0.0");
    rp_intf_0_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    rp_intf_0_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    rp_intf_0_transactor_param_props.addString("CLK_DOMAIN", "system_processing_system7_0_0_FCLK_CLK0");
    rp_intf_0_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_rp_intf_0_transactor = new xtlm::xaximm_xtlm2pin_t<32,31,1,1,1,1,1,1>("rp_intf_0_transactor", rp_intf_0_transactor_param_props);
  mp_rp_intf_0_transactor->ARVALID(rp_intf_0_ARVALID);
  mp_rp_intf_0_transactor->ARREADY(rp_intf_0_ARREADY);
  mp_rp_intf_0_transactor->AWVALID(rp_intf_0_AWVALID);
  mp_rp_intf_0_transactor->AWREADY(rp_intf_0_AWREADY);
  mp_rp_intf_0_transactor->BVALID(rp_intf_0_BVALID);
  mp_rp_intf_0_transactor->BREADY(rp_intf_0_BREADY);
  mp_rp_intf_0_transactor->RVALID(rp_intf_0_RVALID);
  mp_rp_intf_0_transactor->RREADY(rp_intf_0_RREADY);
  mp_rp_intf_0_transactor->WVALID(rp_intf_0_WVALID);
  mp_rp_intf_0_transactor->WREADY(rp_intf_0_WREADY);
  mp_rp_intf_0_transactor->AWADDR(rp_intf_0_AWADDR);
  mp_rp_intf_0_transactor->WDATA(rp_intf_0_WDATA);
  mp_rp_intf_0_transactor->WSTRB(rp_intf_0_WSTRB);
  mp_rp_intf_0_transactor->BRESP(rp_intf_0_BRESP);
  mp_rp_intf_0_transactor->ARADDR(rp_intf_0_ARADDR);
  mp_rp_intf_0_transactor->RDATA(rp_intf_0_RDATA);
  mp_rp_intf_0_transactor->RRESP(rp_intf_0_RRESP);
  mp_rp_intf_0_transactor->CLK(intf_0_aclk);
  mp_rp_intf_0_transactor->RST(intf_0_arstn);

  // initialize transactors stubs
  s_intf_0_transactor_target_wr_socket_stub = nullptr;
  s_intf_0_transactor_target_rd_socket_stub = nullptr;
  rp_intf_0_transactor_initiator_wr_socket_stub = nullptr;
  rp_intf_0_transactor_initiator_rd_socket_stub = nullptr;

}

void system_dfx_decoupler_0_1::before_end_of_elaboration()
{
  // configure 's_intf_0' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("system_dfx_decoupler_0_1", "s_intf_0_TLM_MODE") != 1)
  {
    mp_impl->S00_AXIMM_TARGET_wr_SOCKET->bind(*(mp_s_intf_0_transactor->wr_socket));
    mp_impl->S00_AXIMM_TARGET_rd_SOCKET->bind(*(mp_s_intf_0_transactor->rd_socket));
  
  }
  else
  {
    s_intf_0_transactor_target_wr_socket_stub = new xtlm::xtlm_aximm_target_stub("wr_socket",0);
    s_intf_0_transactor_target_wr_socket_stub->bind(*(mp_s_intf_0_transactor->wr_socket));
    s_intf_0_transactor_target_rd_socket_stub = new xtlm::xtlm_aximm_target_stub("rd_socket",0);
    s_intf_0_transactor_target_rd_socket_stub->bind(*(mp_s_intf_0_transactor->rd_socket));
    mp_s_intf_0_transactor->disable_transactor();
  }

  // configure 'rp_intf_0' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("system_dfx_decoupler_0_1", "rp_intf_0_TLM_MODE") != 1)
  {
    mp_impl->M00_AXIMM_INITIATOR_wr_SOCKET->bind(*(mp_rp_intf_0_transactor->wr_socket));
    mp_impl->M00_AXIMM_INITIATOR_rd_SOCKET->bind(*(mp_rp_intf_0_transactor->rd_socket));
  
  }
  else
  {
    rp_intf_0_transactor_initiator_wr_socket_stub = new xtlm::xtlm_aximm_initiator_stub("wr_socket",0);
    rp_intf_0_transactor_initiator_wr_socket_stub->bind(*(mp_rp_intf_0_transactor->wr_socket));
    rp_intf_0_transactor_initiator_rd_socket_stub = new xtlm::xtlm_aximm_initiator_stub("rd_socket",0);
    rp_intf_0_transactor_initiator_rd_socket_stub->bind(*(mp_rp_intf_0_transactor->rd_socket));
    mp_rp_intf_0_transactor->disable_transactor();
  }

}

#endif // VCSSYSTEMC




#ifdef MTI_SYSTEMC
system_dfx_decoupler_0_1::system_dfx_decoupler_0_1(const sc_core::sc_module_name& nm) : system_dfx_decoupler_0_1_sc(nm),  s_intf_0_ARVALID("s_intf_0_ARVALID"), rp_intf_0_ARVALID("rp_intf_0_ARVALID"), s_intf_0_ARREADY("s_intf_0_ARREADY"), rp_intf_0_ARREADY("rp_intf_0_ARREADY"), s_intf_0_AWVALID("s_intf_0_AWVALID"), rp_intf_0_AWVALID("rp_intf_0_AWVALID"), s_intf_0_AWREADY("s_intf_0_AWREADY"), rp_intf_0_AWREADY("rp_intf_0_AWREADY"), s_intf_0_BVALID("s_intf_0_BVALID"), rp_intf_0_BVALID("rp_intf_0_BVALID"), s_intf_0_BREADY("s_intf_0_BREADY"), rp_intf_0_BREADY("rp_intf_0_BREADY"), s_intf_0_RVALID("s_intf_0_RVALID"), rp_intf_0_RVALID("rp_intf_0_RVALID"), s_intf_0_RREADY("s_intf_0_RREADY"), rp_intf_0_RREADY("rp_intf_0_RREADY"), s_intf_0_WVALID("s_intf_0_WVALID"), rp_intf_0_WVALID("rp_intf_0_WVALID"), s_intf_0_WREADY("s_intf_0_WREADY"), rp_intf_0_WREADY("rp_intf_0_WREADY"), s_intf_0_AWADDR("s_intf_0_AWADDR"), rp_intf_0_AWADDR("rp_intf_0_AWADDR"), s_intf_0_WDATA("s_intf_0_WDATA"), rp_intf_0_WDATA("rp_intf_0_WDATA"), s_intf_0_WSTRB("s_intf_0_WSTRB"), rp_intf_0_WSTRB("rp_intf_0_WSTRB"), s_intf_0_BRESP("s_intf_0_BRESP"), rp_intf_0_BRESP("rp_intf_0_BRESP"), s_intf_0_ARADDR("s_intf_0_ARADDR"), rp_intf_0_ARADDR("rp_intf_0_ARADDR"), s_intf_0_RDATA("s_intf_0_RDATA"), rp_intf_0_RDATA("rp_intf_0_RDATA"), s_intf_0_RRESP("s_intf_0_RRESP"), rp_intf_0_RRESP("rp_intf_0_RRESP"), intf_0_aclk("intf_0_aclk"), intf_0_arstn("intf_0_arstn"), decouple("decouple"), decouple_status("decouple_status")
{
  // initialize pins
  mp_impl->intf_0_aclk(intf_0_aclk);
  mp_impl->intf_0_arstn(intf_0_arstn);
  mp_impl->decouple(decouple);
  mp_impl->decouple_status(decouple_status);

  // initialize transactors
  mp_s_intf_0_transactor = NULL;
  mp_rp_intf_0_transactor = NULL;

  // Instantiate Socket Stubs

  // configure s_intf_0_transactor
    xsc::common_cpp::properties s_intf_0_transactor_param_props;
    s_intf_0_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_intf_0_transactor_param_props.addLong("FREQ_HZ", "90909088");
    s_intf_0_transactor_param_props.addLong("ID_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("ADDR_WIDTH", "31");
    s_intf_0_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_intf_0_transactor_param_props.addLong("HAS_BURST", "0");
    s_intf_0_transactor_param_props.addLong("HAS_LOCK", "0");
    s_intf_0_transactor_param_props.addLong("HAS_PROT", "0");
    s_intf_0_transactor_param_props.addLong("HAS_CACHE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_QOS", "0");
    s_intf_0_transactor_param_props.addLong("HAS_REGION", "0");
    s_intf_0_transactor_param_props.addLong("HAS_WSTRB", "1");
    s_intf_0_transactor_param_props.addLong("HAS_BRESP", "1");
    s_intf_0_transactor_param_props.addLong("HAS_RRESP", "1");
    s_intf_0_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_intf_0_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_intf_0_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_intf_0_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_intf_0_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_intf_0_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_intf_0_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_intf_0_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_SIZE", "0");
    s_intf_0_transactor_param_props.addLong("HAS_RESET", "1");
    s_intf_0_transactor_param_props.addFloat("PHASE", "0.0");
    s_intf_0_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_intf_0_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_intf_0_transactor_param_props.addString("CLK_DOMAIN", "system_processing_system7_0_0_FCLK_CLK0");
    s_intf_0_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_s_intf_0_transactor = new xtlm::xaximm_pin2xtlm_t<32,31,1,1,1,1,1,1>("s_intf_0_transactor", s_intf_0_transactor_param_props);
  mp_s_intf_0_transactor->ARVALID(s_intf_0_ARVALID);
  mp_s_intf_0_transactor->ARREADY(s_intf_0_ARREADY);
  mp_s_intf_0_transactor->AWVALID(s_intf_0_AWVALID);
  mp_s_intf_0_transactor->AWREADY(s_intf_0_AWREADY);
  mp_s_intf_0_transactor->BVALID(s_intf_0_BVALID);
  mp_s_intf_0_transactor->BREADY(s_intf_0_BREADY);
  mp_s_intf_0_transactor->RVALID(s_intf_0_RVALID);
  mp_s_intf_0_transactor->RREADY(s_intf_0_RREADY);
  mp_s_intf_0_transactor->WVALID(s_intf_0_WVALID);
  mp_s_intf_0_transactor->WREADY(s_intf_0_WREADY);
  mp_s_intf_0_transactor->AWADDR(s_intf_0_AWADDR);
  mp_s_intf_0_transactor->WDATA(s_intf_0_WDATA);
  mp_s_intf_0_transactor->WSTRB(s_intf_0_WSTRB);
  mp_s_intf_0_transactor->BRESP(s_intf_0_BRESP);
  mp_s_intf_0_transactor->ARADDR(s_intf_0_ARADDR);
  mp_s_intf_0_transactor->RDATA(s_intf_0_RDATA);
  mp_s_intf_0_transactor->RRESP(s_intf_0_RRESP);
  mp_s_intf_0_transactor->CLK(intf_0_aclk);
  mp_s_intf_0_transactor->RST(intf_0_arstn);
  // configure rp_intf_0_transactor
    xsc::common_cpp::properties rp_intf_0_transactor_param_props;
    rp_intf_0_transactor_param_props.addLong("DATA_WIDTH", "32");
    rp_intf_0_transactor_param_props.addLong("FREQ_HZ", "90909088");
    rp_intf_0_transactor_param_props.addLong("ID_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("ADDR_WIDTH", "31");
    rp_intf_0_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("WUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("RUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("BUSER_WIDTH", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_BURST", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_LOCK", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_PROT", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_CACHE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_QOS", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_REGION", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_WSTRB", "1");
    rp_intf_0_transactor_param_props.addLong("HAS_BRESP", "1");
    rp_intf_0_transactor_param_props.addLong("HAS_RRESP", "1");
    rp_intf_0_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    rp_intf_0_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    rp_intf_0_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    rp_intf_0_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    rp_intf_0_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    rp_intf_0_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_SIZE", "0");
    rp_intf_0_transactor_param_props.addLong("HAS_RESET", "1");
    rp_intf_0_transactor_param_props.addFloat("PHASE", "0.0");
    rp_intf_0_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    rp_intf_0_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    rp_intf_0_transactor_param_props.addString("CLK_DOMAIN", "system_processing_system7_0_0_FCLK_CLK0");
    rp_intf_0_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_rp_intf_0_transactor = new xtlm::xaximm_xtlm2pin_t<32,31,1,1,1,1,1,1>("rp_intf_0_transactor", rp_intf_0_transactor_param_props);
  mp_rp_intf_0_transactor->ARVALID(rp_intf_0_ARVALID);
  mp_rp_intf_0_transactor->ARREADY(rp_intf_0_ARREADY);
  mp_rp_intf_0_transactor->AWVALID(rp_intf_0_AWVALID);
  mp_rp_intf_0_transactor->AWREADY(rp_intf_0_AWREADY);
  mp_rp_intf_0_transactor->BVALID(rp_intf_0_BVALID);
  mp_rp_intf_0_transactor->BREADY(rp_intf_0_BREADY);
  mp_rp_intf_0_transactor->RVALID(rp_intf_0_RVALID);
  mp_rp_intf_0_transactor->RREADY(rp_intf_0_RREADY);
  mp_rp_intf_0_transactor->WVALID(rp_intf_0_WVALID);
  mp_rp_intf_0_transactor->WREADY(rp_intf_0_WREADY);
  mp_rp_intf_0_transactor->AWADDR(rp_intf_0_AWADDR);
  mp_rp_intf_0_transactor->WDATA(rp_intf_0_WDATA);
  mp_rp_intf_0_transactor->WSTRB(rp_intf_0_WSTRB);
  mp_rp_intf_0_transactor->BRESP(rp_intf_0_BRESP);
  mp_rp_intf_0_transactor->ARADDR(rp_intf_0_ARADDR);
  mp_rp_intf_0_transactor->RDATA(rp_intf_0_RDATA);
  mp_rp_intf_0_transactor->RRESP(rp_intf_0_RRESP);
  mp_rp_intf_0_transactor->CLK(intf_0_aclk);
  mp_rp_intf_0_transactor->RST(intf_0_arstn);

  // initialize transactors stubs
  s_intf_0_transactor_target_wr_socket_stub = nullptr;
  s_intf_0_transactor_target_rd_socket_stub = nullptr;
  rp_intf_0_transactor_initiator_wr_socket_stub = nullptr;
  rp_intf_0_transactor_initiator_rd_socket_stub = nullptr;

}

void system_dfx_decoupler_0_1::before_end_of_elaboration()
{
  // configure 's_intf_0' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("system_dfx_decoupler_0_1", "s_intf_0_TLM_MODE") != 1)
  {
    mp_impl->S00_AXIMM_TARGET_wr_SOCKET->bind(*(mp_s_intf_0_transactor->wr_socket));
    mp_impl->S00_AXIMM_TARGET_rd_SOCKET->bind(*(mp_s_intf_0_transactor->rd_socket));
  
  }
  else
  {
    s_intf_0_transactor_target_wr_socket_stub = new xtlm::xtlm_aximm_target_stub("wr_socket",0);
    s_intf_0_transactor_target_wr_socket_stub->bind(*(mp_s_intf_0_transactor->wr_socket));
    s_intf_0_transactor_target_rd_socket_stub = new xtlm::xtlm_aximm_target_stub("rd_socket",0);
    s_intf_0_transactor_target_rd_socket_stub->bind(*(mp_s_intf_0_transactor->rd_socket));
    mp_s_intf_0_transactor->disable_transactor();
  }

  // configure 'rp_intf_0' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("system_dfx_decoupler_0_1", "rp_intf_0_TLM_MODE") != 1)
  {
    mp_impl->M00_AXIMM_INITIATOR_wr_SOCKET->bind(*(mp_rp_intf_0_transactor->wr_socket));
    mp_impl->M00_AXIMM_INITIATOR_rd_SOCKET->bind(*(mp_rp_intf_0_transactor->rd_socket));
  
  }
  else
  {
    rp_intf_0_transactor_initiator_wr_socket_stub = new xtlm::xtlm_aximm_initiator_stub("wr_socket",0);
    rp_intf_0_transactor_initiator_wr_socket_stub->bind(*(mp_rp_intf_0_transactor->wr_socket));
    rp_intf_0_transactor_initiator_rd_socket_stub = new xtlm::xtlm_aximm_initiator_stub("rd_socket",0);
    rp_intf_0_transactor_initiator_rd_socket_stub->bind(*(mp_rp_intf_0_transactor->rd_socket));
    mp_rp_intf_0_transactor->disable_transactor();
  }

}

#endif // MTI_SYSTEMC




system_dfx_decoupler_0_1::~system_dfx_decoupler_0_1()
{
  delete mp_s_intf_0_transactor;

  delete mp_rp_intf_0_transactor;

}

#ifdef MTI_SYSTEMC
SC_MODULE_EXPORT(system_dfx_decoupler_0_1);
#endif

#ifdef XM_SYSTEMC
XMSC_MODULE_EXPORT(system_dfx_decoupler_0_1);
#endif

#ifdef RIVIERA
SC_MODULE_EXPORT(system_dfx_decoupler_0_1);
#endif

