-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2026.1 (lin64) Build 6511674 Tue Jun 16 11:01:26 MDT 2026
-- Date        : Sat Nov 21 15:49:01 2026
-- Host        : diogo-azevedo-Legion-Pro-7-16IAX10H running 64-bit Ubuntu 26.04.1 LTS
-- Command     : write_vhdl -force -mode funcsim
--               /home/diogo-azevedo/Robot_Systems_MSc/Embedded_Systems/Assignment_2/assignment_2/assignment_2.gen/sources_1/bd/system/ip/system_dfx_decoupler_0_1/system_dfx_decoupler_0_1_sim_netlist.vhdl
-- Design      : system_dfx_decoupler_0_1
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
`protect begin_protected
`protect version = 1
`protect encrypt_agent = "XILINX"
`protect encrypt_agent_info = "Xilinx Encryption Tool 2014"
`protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
ldf5+Eel1Xg47b67VCGO7Sn/f72qKUySSTqXHGLUuZMIEDbs8goxQH4jU4WCjayrQJlXUckjGK/R
+xpETivd1XBijlHOq+6pIPdNxud+uxsRiXFv/PdzNxLegGX1Kj+803vDsMZhyEcbEqAfwJ/XsMgx
gBB3b/e5gGbV3FjPatgl7u8g268mjOlSJ+kkpomjHLtQ4Gu3L/cmyf9qcuyuSXneKmTvfORpbdKD
F2KLnH12m21xCjsq1RyhG0/rX/tpSRtK/Cyjf1iBN1+CumcP4BnjhZF7HkN0/5fofc+trTwCugHq
lf092Cse0hMjT6qh6zRp7oOdPO/lo4YOrUsaFw==

`protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`protect key_block
JYsc1i5wADC636qJkhtbbqI30icWri941gSqMjRHc1zAGxG/CxWqes1E6tM5X8S85ZYoCMqqUTCP
zPeYa7aQNirLk409DDiowqJ6IqZQrrY+fBMxexE4af4mFTcMnATbeJB7S3rwotwFuRjuxR1OtFsI
U+JiT0aqHwnIalXbGMgVkVNE1neFFQJ4ZBnrRdzj9e+1B6XJdQNQM6SBY9zmfPppe7wa0YnEgTyH
QGRyr+S4kNHnZaNGTz+0RM1hdPRC3HCjXOAGx1aJin9qks+nKaDyBD9iEacoGE1w3ZEEo37ZetHB
p0RnY3Iknk5a0/ghb1YeXW0NxGfKF6kEMI+etQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

`protect key_keyowner="Cadence Design Systems.", key_keyname="cds_rsa_key", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=64)
`protect key_block
WlaT7VStZV63t0DHLAK7130SPqtmORk3fcjLdtxvo7Zr8Vmf8RaEvpcsRYObgwUmUqVm2/hPKxJO
+gb5wmyLtA==

`protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
YDObQ1NtkfjBlvUYh1vxXDdyFI4c395gslA2Nhvha9xfwbCxrCMC+Y4k3qcOISA8VnP3PtRnlSnk
gqsB5Z+NsTUYpVMwc9bR/xjzv465vByNc0VTPmks9o70hDTl3hTSVaGde5wXmpj23OoPZXXCeJFB
eOrulFJJZvgPwReJV3lqiSpMDZQk3SC43ps+uaG8ijNKNBZR+WjC12wPewpZ8VBZ7Hma6nHEqHW+
5ZR4xr6ue8/TRPL7q4G9HTfnnZ+ZvA6SE7rcmqTlc6Dkssv9CGfP9CCAQefaCaAHA0Awsm+GbusB
6jUiAQCL3UHrJtZ1RAuhk/TuaLwO45uK6dD1Aw==

`protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
LQm8cJQoDLEdpDz42uCYcg02AxUSfKw1bk/grtDTdPuSzYtA9NwhjNJyIayYsCIaWAPtBxYRoip/
tybUgI9T3bbwD2ghc4BLznwa0plIbJkroT7Jrn58u/A2W26vreY2bp1xUZ+QSVZMyZnXNo9V+gLF
ayYkFh3bP6mbHfjwzA6hR4FcoZ2eepttevQF5DMpBLrLnVq/aIBFpwQ49lO68jNmijSgba7Ii7O5
K89AQ7slKWtr2ww3BC0tbqV3EyrBw3sCcw63cUrTmsEqXoBRku/H4GyxQPdJAdHGxYuDgsLFCh1Q
SuZHjhlxsijRsmFnMb0Fc2gajleiVE7C0MTBcA==

`protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`protect key_block
JaH4Inem8lV8ECCJnQGn3skgvDGVe62ipkMWHHBP1li/NSo4EQlLZZiUL9vgkQBmrZ+36laWQaMM
CJnuIT0s3L3LFuo4mVHfooiTSkI4DUH9qY1JrG5kjxsSrUrrsHnxtddQ1+cLfpHI6hMbfxn1/Uwh
MGRFxX8DBuqBkg2zrXA=

`protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
mC30iYh3XPktRMXUAIPhQauehS1OnX+FwBY8y1V9+O8M03GUPlifFt6HlwbZBlU8xApEI7PfOmTD
Wxo5PJIQ8uzfBJzImHSUGAxVym5w4F7A5B4FgkG6AOmZDycXBgE0QeFwBvV5Zddd6qm63Vt6kepz
OSI0urDhDBb/36e1gb+9JKsIHI9qxSWcvwP8Pky+fHrn+nNKQLF3/Bv0njiQX5coTnyuFflprHjh
wx9qx2jy/hqmwnsFAaRJqwtUAfyKY9TW/4cjVt/tLuVxyL9g2BOZvak4SSdO58UjmKfBBBxG1/US
hCIl5Qwlqc5VVeI/0Kv8UUY2jaTfzQkWUspPXg==

`protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
0ibm5urUCFAbXqRlTOQ2X1ugmfvpVMrJXwV1fwuIH6ljvHrT1hKbxyH9X+apdZPsAzy0S6NLBFIX
mG+NMUOKGLZkpKIMGyx+U5BVD2jstq2+1JJ4z37sZUGIBV19IDn3+xnXVZZ9Tkh1z4LrSn/nyd3e
rbQztBLmUQCUPMDDEuqTAZP7R2qP4WFH4rOfmOe0w2+WtVkSeofom3SnI3YBdJ707uOZv0JBwTKk
TeDtpW7sGFHaRoWAQIK/9zTcHZR3gkAJVZKdxYbz2txR/+Gk+Jq5DVkqOtnSV8cMKL2uJDoHmQBG
+vtfs5jfvxdSu9g39cHe3i46F14roUnaEpM3MA==

`protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`protect key_block
j+M6szjq7Dpktyj1Fx+ygOR028nRSqdhf0GrkmUbngYnh2jwZLUV9a9D5jfzs6E9iJZ5WkK5MkFt
ZFRvxLWzxwTvotagxsMch8IapGp9U8N1G6hb8BgErPeMxOA3sMjzhTVW667aYdQH83t8LVtKY/FR
k0pWRpkEgdfxJ2phO7o=

`protect key_keyowner="Xilinx", key_keyname="xilinxt_2026.1-2030.x", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
CZKy7wRvWs9USNSXaYbUkn+cLRCzmixbqtpmXRaKrtVpPBhr3AlT8jO2yswKRl5svnmVAVBAOcw8
NiSfC6AJPyXUjxIIPT/2uVJC3kKf5d9lzg+dMWlP5CT3uo+I7vDPDwVkOT7qjLoiJ+VesOcOl0fr
P+E3qVmejpgM8/dBdSZ8maUV5QrLv/4nRufPppOE2eHSHbIF6Bi4VUWVGIo0dhEm5KiATz8VgKMQ
88yJ9p56YWHnyjysqF3dS4UihNxpRjtVtJkxiM9jC6bG8fWpmlDyHPVEiWbytqXY3tORjtqOWzRp
DqMHOPalje0P+n9Akox1jSWIsty/ZD8PW1L9wA==

`protect data_method = "AES128-CBC"
`protect encoding = (enctype = "BASE64", line_length = 76, bytes = 7200)
`protect data_block
11MIx2LGj78We9X0dd5ErbZdjGRE9L+JtrDtArZ9pedKUUl4hwsbEqTeL0ZH6yL906fA4xyGJPp/
N1L14GRz+UKo1oN/xVQe/0ZLxfu1SboDBHPYt8TjdwDlOAMEkXwEgqDgWYbgSg2dM6J7ogkET52C
VzybB+kZ8EdFJmQvvXyqAAgCPbO3iKEo5nofOYFumjN/ugPViHKaqfeNxu18lPJ6V1+sf4fb6ODu
7lFVRIzJ9mU6GDpaW6XQ5+V3vt/tVmvVygt8yPSnHywbrpQxOPFvd2Xryb/gBBNPee+suQwfe1SZ
jX6Y3IlFM7/Yc+d5ldhEYtf8Q/ERuSDMotZzbCnxWe31E1uO9FG7rl/GCxocaKqXLgWAt0xXgaN3
fer+dMytRC7Z+UajH96dpfSzc4MPtBqSXn19f7aNuRAHjeoYSegwwPvjXOAGBELCVNC8+kEgAxf8
DfY4ug6LMHgIDhk1z80/VDwB38zTszhp75mzQO8cOvwqTZhCPAWVi5e+P+QUD/3tu17aLDG7KWvM
rJGiT1YG9/d+5pMGzTnjRbUkb+B4S6if5VVZFpn8SWwHrvx7flyrb//3sZIFX7Ys5/x/8WcuRICr
0sIQM8KqLFgOygxRJCoN/yi7DkWiRScTBTFQ/OMwod9fureKlAqmfHdaDlaLJuTfv8JGgcnZZbLX
HcvskFQAReEEXCGpImumFrQ+CtjZc4jM/mrH+Hex5vyrhQYm5C8J1UMH4JeXC8a73yHl2U/0dmu4
ePgODC5Yz3PYt2H/ST5mx3O45Wu1zAsfgAUFzWGLYcuBOMbt3YFrbC183uZhhnB+FRCGWkBfAgBh
5P06s4toLXf9cEJP7ewrFUuKfwiA4be9B16AVZ0gvbAZoPmh6s1xee2To8J01ihG47WKxGYrzhtH
uwMcdS/tdZvgzY3XLQ/iPLUsZ/CcZYhtOjKmHOu0o6iSBeB6P/LsseNdqpcdiULzG2UVujw+ZHDy
de+663iF6DPViVYlJkGDAy23q4xesdiGVNoZ40a1oimdFTTnpc602KdR9NylOFUqqUe1jQaGIG0Y
HDUhuGLdFLxTvzdsUN0ZWiCD8DS4XJRaD8uFkIeo/8c9ZTHt//UAjslKAcS70ztEEqEh/LaPrDZS
A1UATd8HCOH09I1EKGPaNrdYQypBr66eYgPHNlgyhTUhAPBUosl96B2gaA8OkHd64YihaqI0opW5
9qlfD3Ypl0aIMAAhYu1GtWMZoJ9v++/THaJ+vpafpVVgYpjXroP08KizdXsr62JaL8ThwXavTp+I
Aca8wXNQeoISWgaj06xpDQIcujfSUJaCsCfcwsaa0uyh7GKeV9vbpwnjmGRX50ROvAFVwOex7JCL
pTv8gx7UK6MTc8w0gLk8NZElwph+1ogrNKl/5y8SoD8zXeMDnhkx4nk2xh3tTRldOBPDlLoJLqYv
4NzfeQYwEbcLb38dUcv5mwpgptSKdMhDFE7cLKxad8/2nPzzB46aUIqzKCreNw8AV7+WhFq7WsLM
9M5rcYL8/ltnESDb/iAYmSZFp4eMUjDuM4+yhVNu+Hd4Mm7O+DlxB/r/vBm5bOSrPhEAzZPam5kl
VYSTtewieuSocP5WKU0H65XHsrQhMqo9SLQFmZF2QjqRX7kslJcjjNqqkfIrShKGhYTfcE0kpLj2
bbz+PF2ShRHz4DQ43A5hXCjYV++YBt9jDU4ueyBgmaMlgSX740ljvuykc3tXiEQpJNUfO8PffLGZ
zeMk7mdWiQp5P383VVJL3arkIjJAgXu10TiDN+xwyDZu1YZ7P2OmOQPUJuvm6PXgDXzTssp3Q8WA
WpPbQDhEycEUi1AQ3+5o9awICx3FwGMJeTCZU2j/2VydJJqhwjSzI2vzQc8+CPDDTCRBGvd2kC63
sNuKRmOkaguczB3orTD+wtbQJ6bM+nRWxjZEoI3PESQb0J6D16J7tP+dlVF6erRV5GRTpbK0JwBG
rSvpou7XgWY2ruRJwbDTUtdFFmKGJ+xfdmBg3HILIKfvfq89h4HFoEHGRTa4CjaKLXEk/yMuQfPv
gMl19GnrtQqUjRlgJBMJiQve/c64f1uZdbj7UtaK9AaRR1xEwYpyhzxiUYlkDaHigKHy9ZQZf778
ahqhsvNaTFHMFbh12rAdcbjV5u9Tm7XWFan2qWyiLRCGSybXwMgLINM+hqEQsGuxvltaFxHIpCko
cCw7Nt4+pEU+sI+cpgageLJRfXj1vidRUQciDQuHtSbGzFtQoDOIDbsBOrTuoxO38iMwMCsAPCX1
cFzLd9bG1/omH6BJtTAdASR1TnDzkrdnMWd1ltS9LROUzNXjNa3lcZGKiy7aSS+b2rhfROgrayHz
QmlfwZrnuPk3fqwn1SYLsrleYK53xmg4mWqXVLUKa+EMLlAJZOj+dJDYIZN/Bvr+jJ5Da1WgRLn0
gx7qEKyctVXsKaKuCox7zPFfLN/en8a90sts6o5OxPc9X/waXhHPXqRmiZvjctD+gSI7CPSLi2JH
n1guxGkVFYpEPf0gl9jpXMX2iPKUD5EY2wSqoUMcjzZCQ5NkNWDeqCQ2ZhfZiAPliu77aaNzDN++
GPmxG70w0I6m0/NFgQQ93TmCjLqLGeLAhsNGBMt8fbQRmg4Dnod08bG0/UBh/khgUiBPspoA23CB
DT5lu7nI9Ruzwm0qp6aEMj8oAR2x42SiSacIke+1B1soWTX20Uf0cUnYxlcxdqm5O/7trt7hk7Ce
JIQqBw/DEtIXrDwFtY+bB0AMdticQ9xgvD5DJIDlGAbLLvkC9KoLqkVZsMj/oDvrwA6vuFjXVFa+
w4LCXC6DbxNna6Iw8+NuO7fFiRpp7kcpz78x38tgLqAr3dZToDuZPJlowDpKjEBjZycAoD7i2Obl
abhe/jAMrJlkBN1QWqKAPXaPQOLAO4R3YBJPEujO2LMHp0UvsVfBeYUFluE3tvo45suhBXqHHziF
H6iSEXXWTnObHliBHNq9D8+yg64JwP7az4t/USmb0vJaR92015Ud7yswDx00W+BBplvJknzQuUDE
oe0GXrIf4Ow3uSBLu9+zNzRR6REJS2cSSZV40s9grD9SGGWSqu3miv/WuO80fvshLmj076JRBeiH
tCf9X9F6WX+IiUYh2punChN732FuMoKi5YWTG9/FDb9YuBO4Cq7urOFsD8i3Vq2vUBbSjNjbZRON
AsbUXHNbWutz7elfjJAPjakLcb7Wqn8FWk2dkK69JnxuG4ongLouFFFeY1V8ooux6Jh8JE1LXrmb
goU2v5+VX4LWoUXgTmtiMuyB73qJt25OE15d7t/wWVk7JP8QvzDqMNcU6D1iZWL7qkUeB9SR25Xk
nYjhnTY8yIjKr+s5unQUTWf32JgvHyOwmMcJeev5kkuQNKqQXszwbQvCGYpLBXIT3aPheRaaL9Gy
2/JBdWmIVbNqFL2EqJsLAlEhDgURWPFV1hXWHU/syi2Kjp4hmcdEusTGsQk/rB1BUrYlA6E9I9sb
t73+nm6UG4Arj3PUdXYWHogjFIQyJgXb91MvkgHEKCdu0Gd7ffMmQMcVmTjf2niJ2iF/5hNMRQbr
s5FvUm27LcTGN34JojCuMmfDsD4U/ykU39Z/xBXXYjbqFEYeT9OJfd8net3xQt3s0g5Q55E76eA3
+JySbpR3BS801zdOfSXRhhZv7y3Bjz5UIgPVxnCp7pa0ax4nb5180eExx+SU1NJjBqlsgaB+mS3L
DpbYR2bTWGE3a4qVOGwq6/AsmWfA4eDmbU7aJOGKiINpmT8/n32sLNmxVrahJlp/fplan+ujkrEt
RsaNf1iXOR8leEbyPwVmJ7aW0TQZnXNSTygP0FMid+AOJfOBODRqcLIHjLUfa+TMumgMTQrg6jj8
cljlCiPkDj7tKHAPEHFMTqtt61+Tmz+CKqXCLf0DIQOg1t4o6Ts/ESfZATKdJjH69ViWnwtwKh/N
BPXZyO9Vgdv+FaGiz4JLH9gvaI6mqVgAqPe3uwRdBve1z+QHp7hPOf1DG7ER2Bx8RmrfWK7UCMCB
yyidR0o4m74/OhwpSp5vpAAS69z8ZNwu6Fkc3qOr4n/qSegDOGk5Qbqv+26OawUbTQEPZHroOEKL
X9eaDb1MvuJ5azfQbHX8qaONxkngwKokpZBWoVHHJpw/oF5PUUXzHj4ueLlS9tGbDRrGtpUoR0aK
AnsjKZ9TemIkXheWO8E2KLuD217LHojxkMPIPxntA4nBBaDeThj0WmBcZcyjqGWlF6X6wrBf1Acd
eZJVhSbZF2C2BboEI2b6fNj6YtJDmSoO0Am0s8UEJkzEfbGdNMVohkDygZJjOskD/gEvRTFtsvDP
Ogykrefe26PLpH3TQYusX8t4DMI1Us3GciCvOd4AvS+JxulcMxood4tXihQTMu7mykIc7puO34t1
0yswFSLbvdligerpTDmlZD9roSjii9cGeqpSXCk5ex9DJG9sfohzmoZaU/mUHNtBpVe9IpayBH4Q
I1VpZWTqUFQXXDZgrlcRWc2uvrCxuURRpGnA72wsN1Tacl2IJA+o8h7Z5Sin/L467P1XWg7tCsyR
DC0h/PNlXCBitAExYSqDm99f8PilWbkh9OgUp8FQ8FzcO6M8vt6nI1o2qAe+Bz27yI/4aL7xGgSs
u/ci0CDoO5Fc1GQfDb1EhAzujZ1gd6soxSLEXgy6UsWPVFCD3Von+Qa5r5bZye15zDzeiJZu/rBY
scq2lW8EaPVFjALPolPLXLBxYclMnQgp6likygRzLt8C0B5PERrqwUcalmcx6npVnJnJmqI9a47a
BLX3HpYVDRACGZtBE57TkWwoDpFI0gFx5Wh7MhmVUnwRJFpP/rB1hHhcfbjnSGyJRKTSoF4bnI2C
jxZS7C0ND8PoAOPkyNRtDKoNbJSdK34bUVBllYaEqGpwFYvqi8ee1YqRGAzjpR/DC+m9plemdY2p
U7KW8oo+57/hbcnI9aQANF8gSUC4rvKx7J4vGZiuk7/sFvNJq467oqB8zlja+OfmrKdXSW7DLJ0e
Iiy2/5hGMEwEjx3ue8gr2Y1/9uPR0KIOffIMM+YeJ1Tlv7Gr7dPUKdisLwwXSmBWDOs1gZvxrozm
N5iIR08gJ6WrP+cYpoUU3CCBzojvWguTqlJSOZGwH0rqDpsAjJBwUqGrGcdrMq+LSaFj1OwxFafC
bmmWQpygHPB1tszD6E1gBlcXwXTEAOprheIryX+jfSrUTCi2wGRSSJr9Iqe5cHwxhlVYZ0ndSCJx
kh4ytUlsQLJUZ730CqMP/bA0cAD76NpPScmiutxw3efITTFSyatpDa2uVMLHvacLRYYCxP6vx48R
FmGFY8qWecmY6930ke4sgO2qUnCsftMdgBLDilyNHf0756NsDTTykHvd8BFKOGRXa0CCizAsTvh6
Kcv5J3b/ah98XgtFSDCu49rpCD0O0nHIlgnTvCMk8eO5nsbMQ/7teyl0EtibxoY686wr+aoGeDQm
+d+Fn0Og5BzRDiRRoU85PQIXOfn2XBjGVW+RdPrK6M3S9K9rpW5dubuMHTR+myYAnvR1dna8Dk2W
KGhXG0kiAQf5VKjfYZ9IZ/5qjQctZ2irQVtEMu0mfE01/nCsv2r4Ac00nIzwFWU1VIytSUX+qwcN
kjOBfea/pt4O4AcptyM9OqL0wkgngP5IRCP3VROqmPA7MaxSbsI7yCcRdxHXy3cLF355XCcJQPie
+Okwk3j48kX5jCAaoqGcUWD0Jb+roph/pBfdtb7Dh8ToNirSfS7MW8WeOFNNaHPXwRq2V1cavYEz
CeFZ/TdOTMCehlCLBGTUAiGrLqE/L3P7yqX7Sw5yazLzEAP/gAUoL+Y0a5I1SIAvct9Iic2z+THE
irPJo+2bpQ20MvZMC7v3GaOAgjKNeJWhRmUq/jsnI/xIECdDG6cFeKOwMmoHr1bPSeHvPOdqVxPz
sGVmGLVw5wptcT2z0aiR4paOnyonf4O24T919STyfeIA/DAWPwLBU0PTZ04fxDG+SnsXZmojh0I3
+nwlxYOhoSS6XCN5hpf9D1BBpShOLn6xGg08+tKFyP3OAjzc4PXDy+124yVyc0uCmh8blSVWJlRj
yhoQlnN6jWdBmsssz/l6BePljp4yG70aZ53bXVnWr/tNKPzxW7ALeA489ytRp3z+IcoP/YvvL3/M
jtdqetSgjB9KnDksIIlaavh+1/yx2Qzc3LZtPOU3MeSQ5hnGf0Up1JRvkrzZrQ06428Qihe//9R1
KmTAU9MdLPLZRq/9eEL2AUTptgpQYJ46mLt19fNjgxCxVb3ofaG8eiEmRwLiG/QWNLIunEh95KYs
jj8ftdNx+Gesq8t6+0o8KvtEy1wc9aqZtbEOwCakTD/9PCbfRKFdzM7pt15mFcThm/OiQDNx9aiU
vzDm834tWIARLDDB8j5sl5zg1CznPRqL+uZS5p7b8jiqGTvvu88H0U/P5G0PDpWMC1cc6VsClYS8
q6k0eKHUNi2tC8eI5pafzRcDzznU8HXWLeaJw1rTU7oYrNKPQsBaY82KyV/76Gw0jFGJLl+aB/vN
CQzUFRjaRjJPPBeJPxaLeP5ilbJEzHsQKlBu28/uGiWDwbcNa0PMYE3Gt1zvjfJN4v6+xgaIsLDr
IpLchXv+B+OrZ6BTbre9d2E02JbPaHsX8aNOHohkDC/1bgIuCj19OpzCBnQZ0caqBioEoH0Wmp+D
pqEjrbTGlVcPblZK2+Zy+Cg1kbo6Rywj9MljUyDUUtlwtvnP3s5sWNhkEgA7jxXv+Bq/OJWpivKD
qwVc+kdJX7USdNgKdMNoXNzbT+f20ftXTuwoIFbT+FYChPMibZe45+9eON/K1WXNoyriDtl7KUIo
EqzdVYDh1rBkbGK+MXVjPuBChAmCdo56ZBRTGL0wP3TyZPhelEZ19M5tWeQSqzucTvSBiYAh4p+j
dBEcvFg0HrwrRzuHHS0SSTxzCAx6B7MNOZ/aMaHXxi5jy5Y1csuL6sLITJ9ry55KIq5SAZwtI00s
DW2sJE9uxe351EWOjEJJ5BNvlED69Cg/rTMEmSFLWMC5plC0aOsmss14P09eLIZ1eeqM1jGIIoCd
Ei0/O4ABk6OsYSebMVwiuHq78ZmP9ajr1GaRVWI32B30RWE3Kqi/2luKpEZN64oewSHt/UKDRlQX
BXI+upGpLc1YrcM/WD8uCqjptMjO4jLNc9AVSrhG8fKPP9rL4O4Fy7IkoNGX2Nvpxvb1ToBMZ5oo
/WQcd1D1oVOKvQm82j2vM542LiD8EQVys5erwvgJbRphN++VHzEJ4aksHmKmcWh4TkqKSNGpBXsS
hfi882mIoIADZ0S4ulvSQhs8Xz9IymZgIe916xxNsEOSc8BSX5RWAMpwBgmfegooSVLfMwsOte5q
KdzoT+F8UGIIBU40kyU8O0j5c2LvNykicG7V+BWVR08y0DpAJBzi6sadyc9y347up45llPi+w1ho
+IZsw9I4heW/Qc1ZV0VnSedO4iUK58Q+P06JbWZIjQQj2Fk2RuuHUWaaJXFAfGHPHHexMx9iEHZ+
VOtWmTfojufr5j4wazRgXqGaszjqMXUlvai62AAyqr1t74OrhYZPayzE41DYg/eWl/VxScOPy26j
I/HERD4TW10/ld+5xOgC2sEQ0n0ksOXa2qKuHi4HEtYIBxW7KzrcpQCkh7nlyqSX+1PqTj6KpLIT
Bo8+1gwZPBWh6UQmrJ8vtscSlwUl6T9sNIIv8/en0g5r0erpQuhjqeletDj31OTSonQn6KzLpI1a
B0IV791hkNSGTZ70xfg5iTKPqTyextPWPmhhwTU4rGO4tb1XHptraeTR/dFh9drBSCLwWHmIHoPl
hSdkFb2Z5leoDOjR4YBOFKICVSa5wvr9LvTbJuReorRoDxIIamZlBXbLknxvZPAXbvxFlARUMikH
kEW7IB01Z8xjcrHGVAwMtI+SSjoqXSPzeIx1IJUUqTgD4pe08kaqfSVMakASLLxmOJ7MK0s1+6IU
NFOH0TxGO0z6ipCjrxQiKSz9YS0cEYQVfzS90h94e4AyAB7ChscAoLw04EQ0EdKwEdWDTnhYvQcU
Okxto45eW6ldQYO8MXp9dwDkLHO2lI9dVhpUtFnojCOBmbRF5ap3yLhrQZIXhsIvNyVi4yP6diIY
+NU/7WdW3oEEP91/cYAZgAeigr3vLfjPVID81JdJ+0kEENuHTFGCatw2rh5p3HuXduX5Y4bGKzw/
uth3aeWJDBtTwKXb4QfCz4FEk8U7JUuaCykBqVx44+EaOLEt159wvBLlRv0LBhHAlO1/OpZucP50
put4sdY4Wzf9FWFJVQPIWIDvrdenJN0zaee9tojLg81uuKHZZeQCD+qyIEhTiWFqOnCwo7+ZJGql
AOWLZ0/J5zB3dyguZN0bEq4OyzCywBBgEI9nDdgG3Kd1Kfq4BDjjGJu4cKCk05o+yPqrZgK0spPx
46mGXylL2Z667ywV4HxBvD/A+PhSAHLZln/+LR98gfgcBgadAjMPQMJsN/JRjRinAIuWVVV5DiJp
0FJpIcjDpJnoxq6ABfJhxk0MIRrQWLL/sNpRzk52FtYSRqngFjviU25zvcaFSCu4PkTHRZYzYxi4
xWkeqVMp5h58PClxdkzS4DecApwJ5pSHz/B+My6esBC4nHIskpE01IhE3bA4Evn0qDdMwdOEE1yQ
kkfn+LDhaTcKPn+zrJ7yuhSQmFWDlTZybjdZM+GhzGiV0D+8ZddXdqiavms1GoLWRDY4mOSePrjC
YdtDg2WxtbDgJGM4YRKAashQ7DzU339uUjtPglnmXMZ/OgoIeyche+8S3vg1UsVA7wbPPA0msRqb
yLMVjJm3LAt+MSCXZlOwNBzUaSxxOhYJTP03zY8WU2zqzFwZMQHPFW2vIL1jrHMGgNNpwXYYZl1X
Ax1XxNwoMCFvpolIMmdnOVBnub/L+YefRZco/6+ba1PRH3QLglYYDpbnXlQQhLdaFFf8gF1xP4ln
6v9yepVdzdLMH6TU9ucRlqtvLmms7VJ4dkqpBPbNxGywCKqEfaGlQSSsxDlRmf3yNj4zYzBLaBo+
4vtzHaUIHokvLYmJdDgGVCgUh8RJs4MdOt8tgNchthwJOI6dcmw69cTONQnkbx38joKl91fZBzc+
uyNfwp1n3/HsaRUJ7Ywe6n7NuEOUlbe7OgB+slnE5qAL2OUeV7DV00sCcC1aEQJNWEIl/zCoAkPx
RX0N5pVULLlddV9gSGXJxR6UYhb94xN45JDcyL4Cv8sgkCkg19YsV1TVslEJmeWzHTR0Bd8lzjGh
pso+Zc2V3qJ2hyqPtucYkkmoFnN17wDp6X+9WVFKjKtIMTDxGY3W0SkYSmw64FWONVceIcTQWrse
5w1mVM2x80qwpzNddYAwIwUnzekTImCKTDFlW5+8TpwIqGAiRn2PgNnyAfYrKZ6Ez0WbFbI5am2b
UwwufdKyH3Zk5OHyL8GZU6kkPNcEG0/vroBGgkqvd6fthOH0WVGGopjw8+DGC7Lf2UqFdHv8t4Ac
XXWtEs3DOOzhNoVzNrd4i8Mpdbs99UWR+3It/H34sc4+r++ZBLBLLsfX1IJSyOS5V78M/CRH4jer
iSNJ/V8NLHgdwvNfUxkJEx8j
`protect end_protected
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity system_dfx_decoupler_0_1 is
  port (
    s_intf_0_ARVALID : in STD_LOGIC;
    rp_intf_0_ARVALID : out STD_LOGIC;
    s_intf_0_ARREADY : out STD_LOGIC;
    rp_intf_0_ARREADY : in STD_LOGIC;
    s_intf_0_AWVALID : in STD_LOGIC;
    rp_intf_0_AWVALID : out STD_LOGIC;
    s_intf_0_AWREADY : out STD_LOGIC;
    rp_intf_0_AWREADY : in STD_LOGIC;
    s_intf_0_BVALID : out STD_LOGIC;
    rp_intf_0_BVALID : in STD_LOGIC;
    s_intf_0_BREADY : in STD_LOGIC;
    rp_intf_0_BREADY : out STD_LOGIC;
    s_intf_0_RVALID : out STD_LOGIC;
    rp_intf_0_RVALID : in STD_LOGIC;
    s_intf_0_RREADY : in STD_LOGIC;
    rp_intf_0_RREADY : out STD_LOGIC;
    s_intf_0_WVALID : in STD_LOGIC;
    rp_intf_0_WVALID : out STD_LOGIC;
    s_intf_0_WREADY : out STD_LOGIC;
    rp_intf_0_WREADY : in STD_LOGIC;
    s_intf_0_AWADDR : in STD_LOGIC_VECTOR ( 30 downto 0 );
    rp_intf_0_AWADDR : out STD_LOGIC_VECTOR ( 30 downto 0 );
    s_intf_0_WDATA : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rp_intf_0_WDATA : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s_intf_0_WSTRB : in STD_LOGIC_VECTOR ( 3 downto 0 );
    rp_intf_0_WSTRB : out STD_LOGIC_VECTOR ( 3 downto 0 );
    s_intf_0_BRESP : out STD_LOGIC_VECTOR ( 1 downto 0 );
    rp_intf_0_BRESP : in STD_LOGIC_VECTOR ( 1 downto 0 );
    s_intf_0_ARADDR : in STD_LOGIC_VECTOR ( 30 downto 0 );
    rp_intf_0_ARADDR : out STD_LOGIC_VECTOR ( 30 downto 0 );
    s_intf_0_RDATA : out STD_LOGIC_VECTOR ( 31 downto 0 );
    rp_intf_0_RDATA : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s_intf_0_RRESP : out STD_LOGIC_VECTOR ( 1 downto 0 );
    rp_intf_0_RRESP : in STD_LOGIC_VECTOR ( 1 downto 0 );
    intf_0_aclk : in STD_LOGIC;
    intf_0_arstn : in STD_LOGIC;
    decouple : in STD_LOGIC;
    decouple_status : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of system_dfx_decoupler_0_1 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of system_dfx_decoupler_0_1 : entity is "system_dfx_decoupler_0_1,dfx_decoupler_system_dfx_decoupler_0_1,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of system_dfx_decoupler_0_1 : entity is "yes";
  attribute x_core_info : string;
  attribute x_core_info of system_dfx_decoupler_0_1 : entity is "dfx_decoupler_system_dfx_decoupler_0_1,Vivado 2026.1";
end system_dfx_decoupler_0_1;

architecture STRUCTURE of system_dfx_decoupler_0_1 is
  attribute C_XDEVICEFAMILY : string;
  attribute C_XDEVICEFAMILY of U0 : label is "zynq";
  attribute downgradeipidentifiedwarnings of U0 : label is "yes";
  attribute is_du_within_envelope : string;
  attribute is_du_within_envelope of U0 : label is "true";
  attribute x_interface_info : string;
  attribute x_interface_info of intf_0_aclk : signal is "xilinx.com:signal:clock:1.0 intf_0_aclk_CLOCK CLK";
  attribute x_interface_mode : string;
  attribute x_interface_mode of intf_0_aclk : signal is "slave intf_0_aclk_CLOCK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of intf_0_aclk : signal is "XIL_INTERFACENAME intf_0_aclk_CLOCK, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, ASSOCIATED_BUSIF s_intf_0:rp_intf_0, ASSOCIATED_RESET intf_0_arstn, INSERT_VIP 0";
  attribute x_interface_info of intf_0_arstn : signal is "xilinx.com:signal:reset:1.0 intf_0_arstn RST";
  attribute x_interface_mode of intf_0_arstn : signal is "slave intf_0_arstn";
  attribute x_interface_parameter of intf_0_arstn : signal is "XIL_INTERFACENAME intf_0_arstn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of rp_intf_0_ARREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 ARREADY";
  attribute x_interface_info of rp_intf_0_ARVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 ARVALID";
  attribute x_interface_mode of rp_intf_0_ARVALID : signal is "master rp_intf_0";
  attribute x_interface_parameter of rp_intf_0_ARVALID : signal is "XIL_INTERFACENAME rp_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE";
  attribute x_interface_info of rp_intf_0_AWREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 AWREADY";
  attribute x_interface_info of rp_intf_0_AWVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 AWVALID";
  attribute x_interface_info of rp_intf_0_BREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 BREADY";
  attribute x_interface_info of rp_intf_0_BVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 BVALID";
  attribute x_interface_info of rp_intf_0_RREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 RREADY";
  attribute x_interface_info of rp_intf_0_RVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 RVALID";
  attribute x_interface_info of rp_intf_0_WREADY : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 WREADY";
  attribute x_interface_info of rp_intf_0_WVALID : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 WVALID";
  attribute x_interface_info of s_intf_0_ARREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 ARREADY";
  attribute x_interface_info of s_intf_0_ARVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 ARVALID";
  attribute x_interface_mode of s_intf_0_ARVALID : signal is "slave s_intf_0";
  attribute x_interface_parameter of s_intf_0_ARVALID : signal is "XIL_INTERFACENAME s_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE";
  attribute x_interface_info of s_intf_0_AWREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 AWREADY";
  attribute x_interface_info of s_intf_0_AWVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 AWVALID";
  attribute x_interface_info of s_intf_0_BREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 BREADY";
  attribute x_interface_info of s_intf_0_BVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 BVALID";
  attribute x_interface_info of s_intf_0_RREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 RREADY";
  attribute x_interface_info of s_intf_0_RVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 RVALID";
  attribute x_interface_info of s_intf_0_WREADY : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 WREADY";
  attribute x_interface_info of s_intf_0_WVALID : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 WVALID";
  attribute x_interface_info of rp_intf_0_ARADDR : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 ARADDR";
  attribute x_interface_info of rp_intf_0_AWADDR : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 AWADDR";
  attribute x_interface_info of rp_intf_0_BRESP : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 BRESP";
  attribute x_interface_info of rp_intf_0_RDATA : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 RDATA";
  attribute x_interface_info of rp_intf_0_RRESP : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 RRESP";
  attribute x_interface_info of rp_intf_0_WDATA : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 WDATA";
  attribute x_interface_info of rp_intf_0_WSTRB : signal is "xilinx.com:interface:aximm:1.0 rp_intf_0 WSTRB";
  attribute x_interface_info of s_intf_0_ARADDR : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 ARADDR";
  attribute x_interface_info of s_intf_0_AWADDR : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 AWADDR";
  attribute x_interface_info of s_intf_0_BRESP : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 BRESP";
  attribute x_interface_info of s_intf_0_RDATA : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 RDATA";
  attribute x_interface_info of s_intf_0_RRESP : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 RRESP";
  attribute x_interface_info of s_intf_0_WDATA : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 WDATA";
  attribute x_interface_info of s_intf_0_WSTRB : signal is "xilinx.com:interface:aximm:1.0 s_intf_0 WSTRB";
begin
U0: entity work.system_dfx_decoupler_0_1_dfx_decoupler_system_dfx_decoupler_0_1
     port map (
      decouple => decouple,
      decouple_status => decouple_status,
      intf_0_aclk => '0',
      intf_0_arstn => '0',
      rp_intf_0_ARADDR(30 downto 0) => rp_intf_0_ARADDR(30 downto 0),
      rp_intf_0_ARREADY => rp_intf_0_ARREADY,
      rp_intf_0_ARVALID => rp_intf_0_ARVALID,
      rp_intf_0_AWADDR(30 downto 0) => rp_intf_0_AWADDR(30 downto 0),
      rp_intf_0_AWREADY => rp_intf_0_AWREADY,
      rp_intf_0_AWVALID => rp_intf_0_AWVALID,
      rp_intf_0_BREADY => rp_intf_0_BREADY,
      rp_intf_0_BRESP(1 downto 0) => rp_intf_0_BRESP(1 downto 0),
      rp_intf_0_BVALID => rp_intf_0_BVALID,
      rp_intf_0_RDATA(31 downto 0) => rp_intf_0_RDATA(31 downto 0),
      rp_intf_0_RREADY => rp_intf_0_RREADY,
      rp_intf_0_RRESP(1 downto 0) => rp_intf_0_RRESP(1 downto 0),
      rp_intf_0_RVALID => rp_intf_0_RVALID,
      rp_intf_0_WDATA(31 downto 0) => rp_intf_0_WDATA(31 downto 0),
      rp_intf_0_WREADY => rp_intf_0_WREADY,
      rp_intf_0_WSTRB(3 downto 0) => rp_intf_0_WSTRB(3 downto 0),
      rp_intf_0_WVALID => rp_intf_0_WVALID,
      s_intf_0_ARADDR(30 downto 0) => s_intf_0_ARADDR(30 downto 0),
      s_intf_0_ARREADY => s_intf_0_ARREADY,
      s_intf_0_ARVALID => s_intf_0_ARVALID,
      s_intf_0_AWADDR(30 downto 0) => s_intf_0_AWADDR(30 downto 0),
      s_intf_0_AWREADY => s_intf_0_AWREADY,
      s_intf_0_AWVALID => s_intf_0_AWVALID,
      s_intf_0_BREADY => s_intf_0_BREADY,
      s_intf_0_BRESP(1 downto 0) => s_intf_0_BRESP(1 downto 0),
      s_intf_0_BVALID => s_intf_0_BVALID,
      s_intf_0_RDATA(31 downto 0) => s_intf_0_RDATA(31 downto 0),
      s_intf_0_RREADY => s_intf_0_RREADY,
      s_intf_0_RRESP(1 downto 0) => s_intf_0_RRESP(1 downto 0),
      s_intf_0_RVALID => s_intf_0_RVALID,
      s_intf_0_WDATA(31 downto 0) => s_intf_0_WDATA(31 downto 0),
      s_intf_0_WREADY => s_intf_0_WREADY,
      s_intf_0_WSTRB(3 downto 0) => s_intf_0_WSTRB(3 downto 0),
      s_intf_0_WVALID => s_intf_0_WVALID
    );
end STRUCTURE;
