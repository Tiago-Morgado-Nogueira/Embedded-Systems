// (c) Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// (c) Copyright 2022-2026 Advanced Micro Devices, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


//------------------------------------------------------------------------------------
// Filename:    system_dfx_decoupler_0_1_stub.sv
// Description: This HDL file is intended to be used with following simulators only:
//
//   Vivado Simulator (XSim)
//   Cadence Xcelium Simulator
//
//------------------------------------------------------------------------------------
`timescale 1ps/1ps

`ifdef XILINX_SIMULATOR

`ifndef XILINX_SIMULATOR_BITASBOOL
`define XILINX_SIMULATOR_BITASBOOL
typedef bit bit_as_bool;
`endif

(* SC_MODULE_EXPORT *)
module system_dfx_decoupler_0_1 (
  input bit_as_bool s_intf_0_ARVALID,
  output bit_as_bool rp_intf_0_ARVALID,
  output bit_as_bool s_intf_0_ARREADY,
  input bit_as_bool rp_intf_0_ARREADY,
  input bit_as_bool s_intf_0_AWVALID,
  output bit_as_bool rp_intf_0_AWVALID,
  output bit_as_bool s_intf_0_AWREADY,
  input bit_as_bool rp_intf_0_AWREADY,
  output bit_as_bool s_intf_0_BVALID,
  input bit_as_bool rp_intf_0_BVALID,
  input bit_as_bool s_intf_0_BREADY,
  output bit_as_bool rp_intf_0_BREADY,
  output bit_as_bool s_intf_0_RVALID,
  input bit_as_bool rp_intf_0_RVALID,
  input bit_as_bool s_intf_0_RREADY,
  output bit_as_bool rp_intf_0_RREADY,
  input bit_as_bool s_intf_0_WVALID,
  output bit_as_bool rp_intf_0_WVALID,
  output bit_as_bool s_intf_0_WREADY,
  input bit_as_bool rp_intf_0_WREADY,
  input bit [30 : 0] s_intf_0_AWADDR,
  output bit [30 : 0] rp_intf_0_AWADDR,
  input bit [31 : 0] s_intf_0_WDATA,
  output bit [31 : 0] rp_intf_0_WDATA,
  input bit [3 : 0] s_intf_0_WSTRB,
  output bit [3 : 0] rp_intf_0_WSTRB,
  output bit [1 : 0] s_intf_0_BRESP,
  input bit [1 : 0] rp_intf_0_BRESP,
  input bit [30 : 0] s_intf_0_ARADDR,
  output bit [30 : 0] rp_intf_0_ARADDR,
  output bit [31 : 0] s_intf_0_RDATA,
  input bit [31 : 0] rp_intf_0_RDATA,
  output bit [1 : 0] s_intf_0_RRESP,
  input bit [1 : 0] rp_intf_0_RRESP,
  input bit_as_bool intf_0_aclk,
  input bit_as_bool intf_0_arstn,
  input bit_as_bool decouple,
  output bit_as_bool decouple_status
);
endmodule
`endif

`ifdef XCELIUM
(* XMSC_MODULE_EXPORT *)
module system_dfx_decoupler_0_1 (s_intf_0_ARVALID,rp_intf_0_ARVALID,s_intf_0_ARREADY,rp_intf_0_ARREADY,s_intf_0_AWVALID,rp_intf_0_AWVALID,s_intf_0_AWREADY,rp_intf_0_AWREADY,s_intf_0_BVALID,rp_intf_0_BVALID,s_intf_0_BREADY,rp_intf_0_BREADY,s_intf_0_RVALID,rp_intf_0_RVALID,s_intf_0_RREADY,rp_intf_0_RREADY,s_intf_0_WVALID,rp_intf_0_WVALID,s_intf_0_WREADY,rp_intf_0_WREADY,s_intf_0_AWADDR,rp_intf_0_AWADDR,s_intf_0_WDATA,rp_intf_0_WDATA,s_intf_0_WSTRB,rp_intf_0_WSTRB,s_intf_0_BRESP,rp_intf_0_BRESP,s_intf_0_ARADDR,rp_intf_0_ARADDR,s_intf_0_RDATA,rp_intf_0_RDATA,s_intf_0_RRESP,rp_intf_0_RRESP,intf_0_aclk,intf_0_arstn,decouple,decouple_status)
(* integer foreign = "SystemC";
*);
  input bit s_intf_0_ARVALID;
  output wire rp_intf_0_ARVALID;
  output wire s_intf_0_ARREADY;
  input bit rp_intf_0_ARREADY;
  input bit s_intf_0_AWVALID;
  output wire rp_intf_0_AWVALID;
  output wire s_intf_0_AWREADY;
  input bit rp_intf_0_AWREADY;
  output wire s_intf_0_BVALID;
  input bit rp_intf_0_BVALID;
  input bit s_intf_0_BREADY;
  output wire rp_intf_0_BREADY;
  output wire s_intf_0_RVALID;
  input bit rp_intf_0_RVALID;
  input bit s_intf_0_RREADY;
  output wire rp_intf_0_RREADY;
  input bit s_intf_0_WVALID;
  output wire rp_intf_0_WVALID;
  output wire s_intf_0_WREADY;
  input bit rp_intf_0_WREADY;
  input bit [30 : 0] s_intf_0_AWADDR;
  output wire [30 : 0] rp_intf_0_AWADDR;
  input bit [31 : 0] s_intf_0_WDATA;
  output wire [31 : 0] rp_intf_0_WDATA;
  input bit [3 : 0] s_intf_0_WSTRB;
  output wire [3 : 0] rp_intf_0_WSTRB;
  output wire [1 : 0] s_intf_0_BRESP;
  input bit [1 : 0] rp_intf_0_BRESP;
  input bit [30 : 0] s_intf_0_ARADDR;
  output wire [30 : 0] rp_intf_0_ARADDR;
  output wire [31 : 0] s_intf_0_RDATA;
  input bit [31 : 0] rp_intf_0_RDATA;
  output wire [1 : 0] s_intf_0_RRESP;
  input bit [1 : 0] rp_intf_0_RRESP;
  input bit intf_0_aclk;
  input bit intf_0_arstn;
  input bit decouple;
  output wire decouple_status;
endmodule
`endif
