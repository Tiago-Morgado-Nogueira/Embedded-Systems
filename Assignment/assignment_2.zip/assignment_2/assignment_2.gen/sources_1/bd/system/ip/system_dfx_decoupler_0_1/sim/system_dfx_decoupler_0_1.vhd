-- (c) Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- (c) Copyright 2022-2026 Advanced Micro Devices, Inc. All rights reserved.
-- 
-- This file contains confidential and proprietary information
-- of AMD and is protected under U.S. and international copyright
-- and other intellectual property laws.
-- 
-- DISCLAIMER
-- This disclaimer is not a license and does not grant any
-- rights to the materials distributed herewith. Except as
-- otherwise provided in a valid license issued to you by
-- AMD, and to the maximum extent permitted by applicable
-- law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
-- WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
-- AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
-- BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
-- INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
-- (2) AMD shall not be liable (whether in contract or tort,
-- including negligence, or under any other theory of
-- liability) for any loss or damage of any kind or nature
-- related to, arising under or in connection with these
-- materials, including for any direct, or any indirect,
-- special, incidental, or consequential loss or damage
-- (including loss of data, profits, goodwill, or any type of
-- loss or damage suffered as a result of any action brought
-- by a third party) even if such damage or loss was
-- reasonably foreseeable or AMD had been advised of the
-- possibility of the same.
-- 
-- CRITICAL APPLICATIONS
-- AMD products are not designed or intended to be fail-
-- safe, or for use in any application requiring fail-safe
-- performance, such as life-support or safety devices or
-- systems, Class III medical devices, nuclear facilities,
-- applications related to the deployment of airbags, or any
-- other applications that could lead to death, personal
-- injury, or severe property or environmental damage
-- (individually and collectively, "Critical
-- Applications"). Customer assumes the sole risk and
-- liability of any use of AMD products in Critical
-- Applications, subject only to applicable laws and
-- regulations governing limitations on product liability.
-- 
-- THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
-- PART OF THIS FILE AT ALL TIMES.
-- 
-- DO NOT MODIFY THIS FILE.

-- IP VLNV: xilinx.com:ip:dfx_decoupler:1.0
-- IP Revision: 15

LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
USE ieee.numeric_std.ALL;

ENTITY system_dfx_decoupler_0_1 IS
  PORT (
    s_intf_0_ARVALID : IN STD_LOGIC;
    rp_intf_0_ARVALID : OUT STD_LOGIC;
    s_intf_0_ARREADY : OUT STD_LOGIC;
    rp_intf_0_ARREADY : IN STD_LOGIC;
    s_intf_0_AWVALID : IN STD_LOGIC;
    rp_intf_0_AWVALID : OUT STD_LOGIC;
    s_intf_0_AWREADY : OUT STD_LOGIC;
    rp_intf_0_AWREADY : IN STD_LOGIC;
    s_intf_0_BVALID : OUT STD_LOGIC;
    rp_intf_0_BVALID : IN STD_LOGIC;
    s_intf_0_BREADY : IN STD_LOGIC;
    rp_intf_0_BREADY : OUT STD_LOGIC;
    s_intf_0_RVALID : OUT STD_LOGIC;
    rp_intf_0_RVALID : IN STD_LOGIC;
    s_intf_0_RREADY : IN STD_LOGIC;
    rp_intf_0_RREADY : OUT STD_LOGIC;
    s_intf_0_WVALID : IN STD_LOGIC;
    rp_intf_0_WVALID : OUT STD_LOGIC;
    s_intf_0_WREADY : OUT STD_LOGIC;
    rp_intf_0_WREADY : IN STD_LOGIC;
    s_intf_0_AWADDR : IN STD_LOGIC_VECTOR(30 DOWNTO 0);
    rp_intf_0_AWADDR : OUT STD_LOGIC_VECTOR(30 DOWNTO 0);
    s_intf_0_WDATA : IN STD_LOGIC_VECTOR(31 DOWNTO 0);
    rp_intf_0_WDATA : OUT STD_LOGIC_VECTOR(31 DOWNTO 0);
    s_intf_0_WSTRB : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
    rp_intf_0_WSTRB : OUT STD_LOGIC_VECTOR(3 DOWNTO 0);
    s_intf_0_BRESP : OUT STD_LOGIC_VECTOR(1 DOWNTO 0);
    rp_intf_0_BRESP : IN STD_LOGIC_VECTOR(1 DOWNTO 0);
    s_intf_0_ARADDR : IN STD_LOGIC_VECTOR(30 DOWNTO 0);
    rp_intf_0_ARADDR : OUT STD_LOGIC_VECTOR(30 DOWNTO 0);
    s_intf_0_RDATA : OUT STD_LOGIC_VECTOR(31 DOWNTO 0);
    rp_intf_0_RDATA : IN STD_LOGIC_VECTOR(31 DOWNTO 0);
    s_intf_0_RRESP : OUT STD_LOGIC_VECTOR(1 DOWNTO 0);
    rp_intf_0_RRESP : IN STD_LOGIC_VECTOR(1 DOWNTO 0);
    intf_0_aclk : IN STD_LOGIC;
    intf_0_arstn : IN STD_LOGIC;
    decouple : IN STD_LOGIC;
    decouple_status : OUT STD_LOGIC
  );
END system_dfx_decoupler_0_1;

ARCHITECTURE system_dfx_decoupler_0_1_arch OF system_dfx_decoupler_0_1 IS
  ATTRIBUTE DowngradeIPIdentifiedWarnings : STRING;
  ATTRIBUTE DowngradeIPIdentifiedWarnings OF system_dfx_decoupler_0_1_arch: ARCHITECTURE IS "yes";
  COMPONENT dfx_decoupler_system_dfx_decoupler_0_1 IS
    GENERIC (
      C_XDEVICEFAMILY : STRING
    );
    PORT (
      s_intf_0_ARVALID : IN STD_LOGIC;
      rp_intf_0_ARVALID : OUT STD_LOGIC;
      s_intf_0_ARREADY : OUT STD_LOGIC;
      rp_intf_0_ARREADY : IN STD_LOGIC;
      s_intf_0_AWVALID : IN STD_LOGIC;
      rp_intf_0_AWVALID : OUT STD_LOGIC;
      s_intf_0_AWREADY : OUT STD_LOGIC;
      rp_intf_0_AWREADY : IN STD_LOGIC;
      s_intf_0_BVALID : OUT STD_LOGIC;
      rp_intf_0_BVALID : IN STD_LOGIC;
      s_intf_0_BREADY : IN STD_LOGIC;
      rp_intf_0_BREADY : OUT STD_LOGIC;
      s_intf_0_RVALID : OUT STD_LOGIC;
      rp_intf_0_RVALID : IN STD_LOGIC;
      s_intf_0_RREADY : IN STD_LOGIC;
      rp_intf_0_RREADY : OUT STD_LOGIC;
      s_intf_0_WVALID : IN STD_LOGIC;
      rp_intf_0_WVALID : OUT STD_LOGIC;
      s_intf_0_WREADY : OUT STD_LOGIC;
      rp_intf_0_WREADY : IN STD_LOGIC;
      s_intf_0_AWADDR : IN STD_LOGIC_VECTOR(30 DOWNTO 0);
      rp_intf_0_AWADDR : OUT STD_LOGIC_VECTOR(30 DOWNTO 0);
      s_intf_0_WDATA : IN STD_LOGIC_VECTOR(31 DOWNTO 0);
      rp_intf_0_WDATA : OUT STD_LOGIC_VECTOR(31 DOWNTO 0);
      s_intf_0_WSTRB : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
      rp_intf_0_WSTRB : OUT STD_LOGIC_VECTOR(3 DOWNTO 0);
      s_intf_0_BRESP : OUT STD_LOGIC_VECTOR(1 DOWNTO 0);
      rp_intf_0_BRESP : IN STD_LOGIC_VECTOR(1 DOWNTO 0);
      s_intf_0_ARADDR : IN STD_LOGIC_VECTOR(30 DOWNTO 0);
      rp_intf_0_ARADDR : OUT STD_LOGIC_VECTOR(30 DOWNTO 0);
      s_intf_0_RDATA : OUT STD_LOGIC_VECTOR(31 DOWNTO 0);
      rp_intf_0_RDATA : IN STD_LOGIC_VECTOR(31 DOWNTO 0);
      s_intf_0_RRESP : OUT STD_LOGIC_VECTOR(1 DOWNTO 0);
      rp_intf_0_RRESP : IN STD_LOGIC_VECTOR(1 DOWNTO 0);
      intf_0_aclk : IN STD_LOGIC;
      intf_0_arstn : IN STD_LOGIC;
      decouple : IN STD_LOGIC;
      decouple_status : OUT STD_LOGIC
    );
  END COMPONENT dfx_decoupler_system_dfx_decoupler_0_1;
  ATTRIBUTE X_INTERFACE_INFO : STRING;
  ATTRIBUTE X_INTERFACE_MODE : STRING;
  ATTRIBUTE X_INTERFACE_PARAMETER : STRING;
  ATTRIBUTE X_INTERFACE_INFO OF intf_0_aclk: SIGNAL IS "xilinx.com:signal:clock:1.0 intf_0_aclk_CLOCK CLK";
  ATTRIBUTE X_INTERFACE_MODE OF intf_0_aclk: SIGNAL IS "slave intf_0_aclk_CLOCK";
  ATTRIBUTE X_INTERFACE_PARAMETER OF intf_0_aclk: SIGNAL IS "XIL_INTERFACENAME intf_0_aclk_CLOCK, FREQ_HZ 90909088, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, ASSOCIATED_BUSIF s_intf_0:rp_intf_0, ASSOCIATED_RESET intf_0_arstn, INSERT_VIP 0";
  ATTRIBUTE X_INTERFACE_INFO OF intf_0_arstn: SIGNAL IS "xilinx.com:signal:reset:1.0 intf_0_arstn RST";
  ATTRIBUTE X_INTERFACE_MODE OF intf_0_arstn: SIGNAL IS "slave intf_0_arstn";
  ATTRIBUTE X_INTERFACE_PARAMETER OF intf_0_arstn: SIGNAL IS "XIL_INTERFACENAME intf_0_arstn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_ARADDR: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 ARADDR";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_ARREADY: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 ARREADY";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_ARVALID: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 ARVALID";
  ATTRIBUTE X_INTERFACE_MODE OF rp_intf_0_ARVALID: SIGNAL IS "master rp_intf_0";
  ATTRIBUTE X_INTERFACE_PARAMETER OF rp_intf_0_ARVALID: SIGNAL IS "XIL_INTERFACENAME rp_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 90909088, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS" & 
" 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_AWADDR: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 AWADDR";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_AWREADY: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 AWREADY";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_AWVALID: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 AWVALID";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_BREADY: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 BREADY";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_BRESP: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 BRESP";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_BVALID: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 BVALID";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_RDATA: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 RDATA";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_RREADY: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 RREADY";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_RRESP: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 RRESP";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_RVALID: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 RVALID";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_WDATA: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 WDATA";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_WREADY: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 WREADY";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_WSTRB: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 WSTRB";
  ATTRIBUTE X_INTERFACE_INFO OF rp_intf_0_WVALID: SIGNAL IS "xilinx.com:interface:aximm:1.0 rp_intf_0 WVALID";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_ARADDR: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 ARADDR";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_ARREADY: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 ARREADY";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_ARVALID: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 ARVALID";
  ATTRIBUTE X_INTERFACE_MODE OF s_intf_0_ARVALID: SIGNAL IS "slave s_intf_0";
  ATTRIBUTE X_INTERFACE_PARAMETER OF s_intf_0_ARVALID: SIGNAL IS "XIL_INTERFACENAME s_intf_0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 90909088, ID_WIDTH 0, ADDR_WIDTH 31, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS " & 
"1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0, MISC.CLK_REQUIRED FALSE";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_AWADDR: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 AWADDR";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_AWREADY: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 AWREADY";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_AWVALID: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 AWVALID";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_BREADY: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 BREADY";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_BRESP: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 BRESP";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_BVALID: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 BVALID";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_RDATA: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 RDATA";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_RREADY: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 RREADY";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_RRESP: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 RRESP";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_RVALID: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 RVALID";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_WDATA: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 WDATA";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_WREADY: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 WREADY";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_WSTRB: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 WSTRB";
  ATTRIBUTE X_INTERFACE_INFO OF s_intf_0_WVALID: SIGNAL IS "xilinx.com:interface:aximm:1.0 s_intf_0 WVALID";
BEGIN
  U0 : dfx_decoupler_system_dfx_decoupler_0_1
    GENERIC MAP (
      C_XDEVICEFAMILY => "zynq"
    )
    PORT MAP (
      s_intf_0_ARVALID => s_intf_0_ARVALID,
      rp_intf_0_ARVALID => rp_intf_0_ARVALID,
      s_intf_0_ARREADY => s_intf_0_ARREADY,
      rp_intf_0_ARREADY => rp_intf_0_ARREADY,
      s_intf_0_AWVALID => s_intf_0_AWVALID,
      rp_intf_0_AWVALID => rp_intf_0_AWVALID,
      s_intf_0_AWREADY => s_intf_0_AWREADY,
      rp_intf_0_AWREADY => rp_intf_0_AWREADY,
      s_intf_0_BVALID => s_intf_0_BVALID,
      rp_intf_0_BVALID => rp_intf_0_BVALID,
      s_intf_0_BREADY => s_intf_0_BREADY,
      rp_intf_0_BREADY => rp_intf_0_BREADY,
      s_intf_0_RVALID => s_intf_0_RVALID,
      rp_intf_0_RVALID => rp_intf_0_RVALID,
      s_intf_0_RREADY => s_intf_0_RREADY,
      rp_intf_0_RREADY => rp_intf_0_RREADY,
      s_intf_0_WVALID => s_intf_0_WVALID,
      rp_intf_0_WVALID => rp_intf_0_WVALID,
      s_intf_0_WREADY => s_intf_0_WREADY,
      rp_intf_0_WREADY => rp_intf_0_WREADY,
      s_intf_0_AWADDR => s_intf_0_AWADDR,
      rp_intf_0_AWADDR => rp_intf_0_AWADDR,
      s_intf_0_WDATA => s_intf_0_WDATA,
      rp_intf_0_WDATA => rp_intf_0_WDATA,
      s_intf_0_WSTRB => s_intf_0_WSTRB,
      rp_intf_0_WSTRB => rp_intf_0_WSTRB,
      s_intf_0_BRESP => s_intf_0_BRESP,
      rp_intf_0_BRESP => rp_intf_0_BRESP,
      s_intf_0_ARADDR => s_intf_0_ARADDR,
      rp_intf_0_ARADDR => rp_intf_0_ARADDR,
      s_intf_0_RDATA => s_intf_0_RDATA,
      rp_intf_0_RDATA => rp_intf_0_RDATA,
      s_intf_0_RRESP => s_intf_0_RRESP,
      rp_intf_0_RRESP => rp_intf_0_RRESP,
      intf_0_aclk => intf_0_aclk,
      intf_0_arstn => intf_0_arstn,
      decouple => decouple,
      decouple_status => decouple_status
    );
END system_dfx_decoupler_0_1_arch;
