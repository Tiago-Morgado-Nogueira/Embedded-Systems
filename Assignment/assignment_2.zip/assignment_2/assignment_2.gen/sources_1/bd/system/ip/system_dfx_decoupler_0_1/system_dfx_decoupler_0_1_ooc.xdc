



# Processing interface intf_0
#     vlnv        : xilinx.com:interface:aximm_rtl:1.0
#     intf_mode   : slave
#     static_mode : slave
#     cdc_stages  : 0


# Processing interface intf_0 ...done


# End of File


