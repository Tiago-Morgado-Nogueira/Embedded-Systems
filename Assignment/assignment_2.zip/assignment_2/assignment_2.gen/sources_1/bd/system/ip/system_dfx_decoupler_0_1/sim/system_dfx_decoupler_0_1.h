#ifndef IP_SYSTEM_DFX_DECOUPLER_0_1_H_
#define IP_SYSTEM_DFX_DECOUPLER_0_1_H_

// (c) Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// (c) Copyright 2022-2026 Advanced Micro Devices, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


#ifndef XTLM
#include "xtlm.h"
#endif
#ifndef SYSTEMC_INCLUDED
#include <systemc>
#endif

#if defined(_MSC_VER)
#define DllExport __declspec(dllexport)
#elif defined(__GNUC__)
#define DllExport __attribute__ ((visibility("default")))
#else
#define DllExport
#endif

#include "system_dfx_decoupler_0_1_sc.h"




#ifdef XILINX_SIMULATOR
class DllExport system_dfx_decoupler_0_1 : public system_dfx_decoupler_0_1_sc
{
public:

  system_dfx_decoupler_0_1(const sc_core::sc_module_name& nm);
  virtual ~system_dfx_decoupler_0_1();

  // module pin-to-pin RTL interface

  sc_core::sc_in< bool > s_intf_0_ARVALID;
  sc_core::sc_out< bool > rp_intf_0_ARVALID;
  sc_core::sc_out< bool > s_intf_0_ARREADY;
  sc_core::sc_in< bool > rp_intf_0_ARREADY;
  sc_core::sc_in< bool > s_intf_0_AWVALID;
  sc_core::sc_out< bool > rp_intf_0_AWVALID;
  sc_core::sc_out< bool > s_intf_0_AWREADY;
  sc_core::sc_in< bool > rp_intf_0_AWREADY;
  sc_core::sc_out< bool > s_intf_0_BVALID;
  sc_core::sc_in< bool > rp_intf_0_BVALID;
  sc_core::sc_in< bool > s_intf_0_BREADY;
  sc_core::sc_out< bool > rp_intf_0_BREADY;
  sc_core::sc_out< bool > s_intf_0_RVALID;
  sc_core::sc_in< bool > rp_intf_0_RVALID;
  sc_core::sc_in< bool > s_intf_0_RREADY;
  sc_core::sc_out< bool > rp_intf_0_RREADY;
  sc_core::sc_in< bool > s_intf_0_WVALID;
  sc_core::sc_out< bool > rp_intf_0_WVALID;
  sc_core::sc_out< bool > s_intf_0_WREADY;
  sc_core::sc_in< bool > rp_intf_0_WREADY;
  sc_core::sc_in< sc_dt::sc_bv<31> > s_intf_0_AWADDR;
  sc_core::sc_out< sc_dt::sc_bv<31> > rp_intf_0_AWADDR;
  sc_core::sc_in< sc_dt::sc_bv<32> > s_intf_0_WDATA;
  sc_core::sc_out< sc_dt::sc_bv<32> > rp_intf_0_WDATA;
  sc_core::sc_in< sc_dt::sc_bv<4> > s_intf_0_WSTRB;
  sc_core::sc_out< sc_dt::sc_bv<4> > rp_intf_0_WSTRB;
  sc_core::sc_out< sc_dt::sc_bv<2> > s_intf_0_BRESP;
  sc_core::sc_in< sc_dt::sc_bv<2> > rp_intf_0_BRESP;
  sc_core::sc_in< sc_dt::sc_bv<31> > s_intf_0_ARADDR;
  sc_core::sc_out< sc_dt::sc_bv<31> > rp_intf_0_ARADDR;
  sc_core::sc_out< sc_dt::sc_bv<32> > s_intf_0_RDATA;
  sc_core::sc_in< sc_dt::sc_bv<32> > rp_intf_0_RDATA;
  sc_core::sc_out< sc_dt::sc_bv<2> > s_intf_0_RRESP;
  sc_core::sc_in< sc_dt::sc_bv<2> > rp_intf_0_RRESP;
  sc_core::sc_in< bool > intf_0_aclk;
  sc_core::sc_in< bool > intf_0_arstn;
  sc_core::sc_in< bool > decouple;
  sc_core::sc_out< bool > decouple_status;

  // Dummy Signals for IP Ports


protected:

  virtual void before_end_of_elaboration();

private:

  xtlm::xaximm_pin2xtlm_t<32,31,1,1,1,1,1,1>* mp_s_intf_0_transactor;
  xtlm::xaximm_xtlm2pin_t<32,31,1,1,1,1,1,1>* mp_rp_intf_0_transactor;

};
#endif // XILINX_SIMULATOR




#ifdef XM_SYSTEMC
class DllExport system_dfx_decoupler_0_1 : public system_dfx_decoupler_0_1_sc
{
public:

  system_dfx_decoupler_0_1(const sc_core::sc_module_name& nm);
  virtual ~system_dfx_decoupler_0_1();

  // module pin-to-pin RTL interface

  sc_core::sc_in< bool > s_intf_0_ARVALID;
  sc_core::sc_out< bool > rp_intf_0_ARVALID;
  sc_core::sc_out< bool > s_intf_0_ARREADY;
  sc_core::sc_in< bool > rp_intf_0_ARREADY;
  sc_core::sc_in< bool > s_intf_0_AWVALID;
  sc_core::sc_out< bool > rp_intf_0_AWVALID;
  sc_core::sc_out< bool > s_intf_0_AWREADY;
  sc_core::sc_in< bool > rp_intf_0_AWREADY;
  sc_core::sc_out< bool > s_intf_0_BVALID;
  sc_core::sc_in< bool > rp_intf_0_BVALID;
  sc_core::sc_in< bool > s_intf_0_BREADY;
  sc_core::sc_out< bool > rp_intf_0_BREADY;
  sc_core::sc_out< bool > s_intf_0_RVALID;
  sc_core::sc_in< bool > rp_intf_0_RVALID;
  sc_core::sc_in< bool > s_intf_0_RREADY;
  sc_core::sc_out< bool > rp_intf_0_RREADY;
  sc_core::sc_in< bool > s_intf_0_WVALID;
  sc_core::sc_out< bool > rp_intf_0_WVALID;
  sc_core::sc_out< bool > s_intf_0_WREADY;
  sc_core::sc_in< bool > rp_intf_0_WREADY;
  sc_core::sc_in< sc_dt::sc_bv<31> > s_intf_0_AWADDR;
  sc_core::sc_out< sc_dt::sc_bv<31> > rp_intf_0_AWADDR;
  sc_core::sc_in< sc_dt::sc_bv<32> > s_intf_0_WDATA;
  sc_core::sc_out< sc_dt::sc_bv<32> > rp_intf_0_WDATA;
  sc_core::sc_in< sc_dt::sc_bv<4> > s_intf_0_WSTRB;
  sc_core::sc_out< sc_dt::sc_bv<4> > rp_intf_0_WSTRB;
  sc_core::sc_out< sc_dt::sc_bv<2> > s_intf_0_BRESP;
  sc_core::sc_in< sc_dt::sc_bv<2> > rp_intf_0_BRESP;
  sc_core::sc_in< sc_dt::sc_bv<31> > s_intf_0_ARADDR;
  sc_core::sc_out< sc_dt::sc_bv<31> > rp_intf_0_ARADDR;
  sc_core::sc_out< sc_dt::sc_bv<32> > s_intf_0_RDATA;
  sc_core::sc_in< sc_dt::sc_bv<32> > rp_intf_0_RDATA;
  sc_core::sc_out< sc_dt::sc_bv<2> > s_intf_0_RRESP;
  sc_core::sc_in< sc_dt::sc_bv<2> > rp_intf_0_RRESP;
  sc_core::sc_in< bool > intf_0_aclk;
  sc_core::sc_in< bool > intf_0_arstn;
  sc_core::sc_in< bool > decouple;
  sc_core::sc_out< bool > decouple_status;

  // Dummy Signals for IP Ports


protected:

  virtual void before_end_of_elaboration();

private:

  xtlm::xaximm_pin2xtlm_t<32,31,1,1,1,1,1,1>* mp_s_intf_0_transactor;
  xtlm::xaximm_xtlm2pin_t<32,31,1,1,1,1,1,1>* mp_rp_intf_0_transactor;

};
#endif // XM_SYSTEMC




#ifdef RIVIERA
class DllExport system_dfx_decoupler_0_1 : public system_dfx_decoupler_0_1_sc
{
public:

  system_dfx_decoupler_0_1(const sc_core::sc_module_name& nm);
  virtual ~system_dfx_decoupler_0_1();

  // module pin-to-pin RTL interface

  sc_core::sc_in< bool > s_intf_0_ARVALID;
  sc_core::sc_out< bool > rp_intf_0_ARVALID;
  sc_core::sc_out< bool > s_intf_0_ARREADY;
  sc_core::sc_in< bool > rp_intf_0_ARREADY;
  sc_core::sc_in< bool > s_intf_0_AWVALID;
  sc_core::sc_out< bool > rp_intf_0_AWVALID;
  sc_core::sc_out< bool > s_intf_0_AWREADY;
  sc_core::sc_in< bool > rp_intf_0_AWREADY;
  sc_core::sc_out< bool > s_intf_0_BVALID;
  sc_core::sc_in< bool > rp_intf_0_BVALID;
  sc_core::sc_in< bool > s_intf_0_BREADY;
  sc_core::sc_out< bool > rp_intf_0_BREADY;
  sc_core::sc_out< bool > s_intf_0_RVALID;
  sc_core::sc_in< bool > rp_intf_0_RVALID;
  sc_core::sc_in< bool > s_intf_0_RREADY;
  sc_core::sc_out< bool > rp_intf_0_RREADY;
  sc_core::sc_in< bool > s_intf_0_WVALID;
  sc_core::sc_out< bool > rp_intf_0_WVALID;
  sc_core::sc_out< bool > s_intf_0_WREADY;
  sc_core::sc_in< bool > rp_intf_0_WREADY;
  sc_core::sc_in< sc_dt::sc_bv<31> > s_intf_0_AWADDR;
  sc_core::sc_out< sc_dt::sc_bv<31> > rp_intf_0_AWADDR;
  sc_core::sc_in< sc_dt::sc_bv<32> > s_intf_0_WDATA;
  sc_core::sc_out< sc_dt::sc_bv<32> > rp_intf_0_WDATA;
  sc_core::sc_in< sc_dt::sc_bv<4> > s_intf_0_WSTRB;
  sc_core::sc_out< sc_dt::sc_bv<4> > rp_intf_0_WSTRB;
  sc_core::sc_out< sc_dt::sc_bv<2> > s_intf_0_BRESP;
  sc_core::sc_in< sc_dt::sc_bv<2> > rp_intf_0_BRESP;
  sc_core::sc_in< sc_dt::sc_bv<31> > s_intf_0_ARADDR;
  sc_core::sc_out< sc_dt::sc_bv<31> > rp_intf_0_ARADDR;
  sc_core::sc_out< sc_dt::sc_bv<32> > s_intf_0_RDATA;
  sc_core::sc_in< sc_dt::sc_bv<32> > rp_intf_0_RDATA;
  sc_core::sc_out< sc_dt::sc_bv<2> > s_intf_0_RRESP;
  sc_core::sc_in< sc_dt::sc_bv<2> > rp_intf_0_RRESP;
  sc_core::sc_in< bool > intf_0_aclk;
  sc_core::sc_in< bool > intf_0_arstn;
  sc_core::sc_in< bool > decouple;
  sc_core::sc_out< bool > decouple_status;

  // Dummy Signals for IP Ports


protected:

  virtual void before_end_of_elaboration();

private:

  xtlm::xaximm_pin2xtlm_t<32,31,1,1,1,1,1,1>* mp_s_intf_0_transactor;
  xtlm::xaximm_xtlm2pin_t<32,31,1,1,1,1,1,1>* mp_rp_intf_0_transactor;

};
#endif // RIVIERA




#ifdef VCSSYSTEMC
#include "utils/xtlm_aximm_initiator_stub.h"

#include "utils/xtlm_aximm_target_stub.h"

class DllExport system_dfx_decoupler_0_1 : public system_dfx_decoupler_0_1_sc
{
public:

  system_dfx_decoupler_0_1(const sc_core::sc_module_name& nm);
  virtual ~system_dfx_decoupler_0_1();

  // module pin-to-pin RTL interface

  sc_core::sc_in< bool > s_intf_0_ARVALID;
  sc_core::sc_out< bool > rp_intf_0_ARVALID;
  sc_core::sc_out< bool > s_intf_0_ARREADY;
  sc_core::sc_in< bool > rp_intf_0_ARREADY;
  sc_core::sc_in< bool > s_intf_0_AWVALID;
  sc_core::sc_out< bool > rp_intf_0_AWVALID;
  sc_core::sc_out< bool > s_intf_0_AWREADY;
  sc_core::sc_in< bool > rp_intf_0_AWREADY;
  sc_core::sc_out< bool > s_intf_0_BVALID;
  sc_core::sc_in< bool > rp_intf_0_BVALID;
  sc_core::sc_in< bool > s_intf_0_BREADY;
  sc_core::sc_out< bool > rp_intf_0_BREADY;
  sc_core::sc_out< bool > s_intf_0_RVALID;
  sc_core::sc_in< bool > rp_intf_0_RVALID;
  sc_core::sc_in< bool > s_intf_0_RREADY;
  sc_core::sc_out< bool > rp_intf_0_RREADY;
  sc_core::sc_in< bool > s_intf_0_WVALID;
  sc_core::sc_out< bool > rp_intf_0_WVALID;
  sc_core::sc_out< bool > s_intf_0_WREADY;
  sc_core::sc_in< bool > rp_intf_0_WREADY;
  sc_core::sc_in< sc_dt::sc_bv<31> > s_intf_0_AWADDR;
  sc_core::sc_out< sc_dt::sc_bv<31> > rp_intf_0_AWADDR;
  sc_core::sc_in< sc_dt::sc_bv<32> > s_intf_0_WDATA;
  sc_core::sc_out< sc_dt::sc_bv<32> > rp_intf_0_WDATA;
  sc_core::sc_in< sc_dt::sc_bv<4> > s_intf_0_WSTRB;
  sc_core::sc_out< sc_dt::sc_bv<4> > rp_intf_0_WSTRB;
  sc_core::sc_out< sc_dt::sc_bv<2> > s_intf_0_BRESP;
  sc_core::sc_in< sc_dt::sc_bv<2> > rp_intf_0_BRESP;
  sc_core::sc_in< sc_dt::sc_bv<31> > s_intf_0_ARADDR;
  sc_core::sc_out< sc_dt::sc_bv<31> > rp_intf_0_ARADDR;
  sc_core::sc_out< sc_dt::sc_bv<32> > s_intf_0_RDATA;
  sc_core::sc_in< sc_dt::sc_bv<32> > rp_intf_0_RDATA;
  sc_core::sc_out< sc_dt::sc_bv<2> > s_intf_0_RRESP;
  sc_core::sc_in< sc_dt::sc_bv<2> > rp_intf_0_RRESP;
  sc_core::sc_in< bool > intf_0_aclk;
  sc_core::sc_in< bool > intf_0_arstn;
  sc_core::sc_in< bool > decouple;
  sc_core::sc_out< bool > decouple_status;

  // Dummy Signals for IP Ports


protected:

  virtual void before_end_of_elaboration();

private:

  xtlm::xaximm_pin2xtlm_t<32,31,1,1,1,1,1,1>* mp_s_intf_0_transactor;
  xtlm::xaximm_xtlm2pin_t<32,31,1,1,1,1,1,1>* mp_rp_intf_0_transactor;

  // Transactor stubs
  xtlm::xtlm_aximm_initiator_stub * rp_intf_0_transactor_initiator_rd_socket_stub;
  xtlm::xtlm_aximm_initiator_stub * rp_intf_0_transactor_initiator_wr_socket_stub;
  xtlm::xtlm_aximm_target_stub * s_intf_0_transactor_target_rd_socket_stub;
  xtlm::xtlm_aximm_target_stub * s_intf_0_transactor_target_wr_socket_stub;

  // Socket stubs

};
#endif // VCSSYSTEMC




#ifdef MTI_SYSTEMC
#include "utils/xtlm_aximm_initiator_stub.h"

#include "utils/xtlm_aximm_target_stub.h"

class DllExport system_dfx_decoupler_0_1 : public system_dfx_decoupler_0_1_sc
{
public:

  system_dfx_decoupler_0_1(const sc_core::sc_module_name& nm);
  virtual ~system_dfx_decoupler_0_1();

  // module pin-to-pin RTL interface

  sc_core::sc_in< bool > s_intf_0_ARVALID;
  sc_core::sc_out< bool > rp_intf_0_ARVALID;
  sc_core::sc_out< bool > s_intf_0_ARREADY;
  sc_core::sc_in< bool > rp_intf_0_ARREADY;
  sc_core::sc_in< bool > s_intf_0_AWVALID;
  sc_core::sc_out< bool > rp_intf_0_AWVALID;
  sc_core::sc_out< bool > s_intf_0_AWREADY;
  sc_core::sc_in< bool > rp_intf_0_AWREADY;
  sc_core::sc_out< bool > s_intf_0_BVALID;
  sc_core::sc_in< bool > rp_intf_0_BVALID;
  sc_core::sc_in< bool > s_intf_0_BREADY;
  sc_core::sc_out< bool > rp_intf_0_BREADY;
  sc_core::sc_out< bool > s_intf_0_RVALID;
  sc_core::sc_in< bool > rp_intf_0_RVALID;
  sc_core::sc_in< bool > s_intf_0_RREADY;
  sc_core::sc_out< bool > rp_intf_0_RREADY;
  sc_core::sc_in< bool > s_intf_0_WVALID;
  sc_core::sc_out< bool > rp_intf_0_WVALID;
  sc_core::sc_out< bool > s_intf_0_WREADY;
  sc_core::sc_in< bool > rp_intf_0_WREADY;
  sc_core::sc_in< sc_dt::sc_bv<31> > s_intf_0_AWADDR;
  sc_core::sc_out< sc_dt::sc_bv<31> > rp_intf_0_AWADDR;
  sc_core::sc_in< sc_dt::sc_bv<32> > s_intf_0_WDATA;
  sc_core::sc_out< sc_dt::sc_bv<32> > rp_intf_0_WDATA;
  sc_core::sc_in< sc_dt::sc_bv<4> > s_intf_0_WSTRB;
  sc_core::sc_out< sc_dt::sc_bv<4> > rp_intf_0_WSTRB;
  sc_core::sc_out< sc_dt::sc_bv<2> > s_intf_0_BRESP;
  sc_core::sc_in< sc_dt::sc_bv<2> > rp_intf_0_BRESP;
  sc_core::sc_in< sc_dt::sc_bv<31> > s_intf_0_ARADDR;
  sc_core::sc_out< sc_dt::sc_bv<31> > rp_intf_0_ARADDR;
  sc_core::sc_out< sc_dt::sc_bv<32> > s_intf_0_RDATA;
  sc_core::sc_in< sc_dt::sc_bv<32> > rp_intf_0_RDATA;
  sc_core::sc_out< sc_dt::sc_bv<2> > s_intf_0_RRESP;
  sc_core::sc_in< sc_dt::sc_bv<2> > rp_intf_0_RRESP;
  sc_core::sc_in< bool > intf_0_aclk;
  sc_core::sc_in< bool > intf_0_arstn;
  sc_core::sc_in< bool > decouple;
  sc_core::sc_out< bool > decouple_status;

  // Dummy Signals for IP Ports


protected:

  virtual void before_end_of_elaboration();

private:

  xtlm::xaximm_pin2xtlm_t<32,31,1,1,1,1,1,1>* mp_s_intf_0_transactor;
  xtlm::xaximm_xtlm2pin_t<32,31,1,1,1,1,1,1>* mp_rp_intf_0_transactor;

  // Transactor stubs
  xtlm::xtlm_aximm_initiator_stub * rp_intf_0_transactor_initiator_rd_socket_stub;
  xtlm::xtlm_aximm_initiator_stub * rp_intf_0_transactor_initiator_wr_socket_stub;
  xtlm::xtlm_aximm_target_stub * s_intf_0_transactor_target_rd_socket_stub;
  xtlm::xtlm_aximm_target_stub * s_intf_0_transactor_target_wr_socket_stub;

  // Socket stubs

};
#endif // MTI_SYSTEMC
#endif // IP_SYSTEM_DFX_DECOUPLER_0_1_H_
